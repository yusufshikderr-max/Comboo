package com.example.ui.screens.files

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.DriveFileMove
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.files.FileCategory
import com.example.data.files.FileRepository
import com.example.data.files.ManagedFileItem
import com.example.data.files.StorageStats
import com.example.data.local.AppSettings
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.navigation.AppRoute
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.RoseAccent
import com.example.ui.theme.SkyBlueAccent
import com.example.ui.theme.VioletAccent
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class FileSortBy { NAME, SIZE, DATE }

@Composable
fun FileManagerScreen(
    initialCategory: String,
    settings: AppSettings,
    fileRepository: FileRepository,
    onAddTreeUri: (Uri) -> Unit,
    onNavigate: (AppRoute) -> Unit,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedCategory by remember {
        mutableStateOf(runCatching { FileCategory.valueOf(initialCategory) }.getOrDefault(FileCategory.ALL))
    }
    var currentLocalDir by remember { mutableStateOf(fileRepository.rootWorkspaceDir) }
    var currentSafUri by remember { mutableStateOf<Uri?>(null) }
    var files by remember { mutableStateOf<List<ManagedFileItem>>(emptyList()) }
    var storageStats by remember { mutableStateOf<StorageStats?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var sortBy by remember { mutableStateOf(FileSortBy.NAME) }
    var showSortMenu by remember { mutableStateOf(false) }

    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<ManagedFileItem?>(null) }
    var deleteTarget by remember { mutableStateOf<ManagedFileItem?>(null) }
    var transferTarget by remember { mutableStateOf<Pair<ManagedFileItem, Boolean>?>(null) } // item to isMove

    fun refresh() {
        scope.launch {
            storageStats = fileRepository.getStorageStats()
            files = when {
                currentSafUri != null -> fileRepository.listSafDirectory(currentSafUri!!)
                selectedCategory == FileCategory.ALL -> fileRepository.listLocalDirectory(currentLocalDir)
                else -> fileRepository.collectCategoryFiles(selectedCategory, settings.persistedTreeUris)
            }
        }
    }

    LaunchedEffect(selectedCategory, currentLocalDir, currentSafUri, settings.persistedTreeUris) {
        refresh()
    }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            onAddTreeUri(uri)
            currentSafUri = uri
            selectedCategory = FileCategory.ALL
        }
    }

    val fileImporter = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = fileRepository.importUriToWorkspace(uri, "Downloads")
                if (imported != null) {
                    Toast.makeText(context, "Imported ${imported.name}", Toast.LENGTH_SHORT).show()
                    refresh()
                }
            }
        }
    }

    val displayed = remember(files, searchQuery, sortBy) {
        val searched = if (searchQuery.isBlank()) files
        else files.filter { it.name.contains(searchQuery, ignoreCase = true) }

        val sorted = when (sortBy) {
            FileSortBy.NAME -> searched.sortedWith(compareByDescending<ManagedFileItem> { it.isDirectory }.thenBy { it.name.lowercase() })
            FileSortBy.SIZE -> searched.sortedWith(compareByDescending<ManagedFileItem> { it.isDirectory }.thenByDescending { it.sizeBytes })
            FileSortBy.DATE -> searched.sortedWith(compareByDescending<ManagedFileItem> { it.isDirectory }.thenByDescending { it.lastModified })
        }
        sorted
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolFileManager,
                subtitle = when {
                    currentSafUri != null -> "SAF Mounted Folder"
                    selectedCategory != FileCategory.ALL -> selectedCategory.name
                    else -> currentLocalDir.name
                },
                onBack = {
                    if (currentSafUri != null) {
                        currentSafUri = null
                    } else if (selectedCategory == FileCategory.ALL && currentLocalDir.absolutePath != fileRepository.rootWorkspaceDir.absolutePath) {
                        currentLocalDir = currentLocalDir.parentFile ?: fileRepository.rootWorkspaceDir
                    } else {
                        onBack()
                    }
                },
                actions = {
                    IconButton(onClick = { showSortMenu = true }) {
                        Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = "Sort", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                        DropdownMenuItem(text = { Text("Sort by Name") }, onClick = { sortBy = FileSortBy.NAME; showSortMenu = false })
                        DropdownMenuItem(text = { Text("Sort by Size") }, onClick = { sortBy = FileSortBy.SIZE; showSortMenu = false })
                        DropdownMenuItem(text = { Text("Sort by Date") }, onClick = { sortBy = FileSortBy.DATE; showSortMenu = false })
                    }
                }
            )
        },
        floatingActionButton = {
            if (selectedCategory == FileCategory.ALL && currentSafUri == null) {
                FloatingActionButton(
                    onClick = { showCreateFolderDialog = true },
                    modifier = Modifier.testTag("create_folder_fab")
                ) {
                    Icon(Icons.Rounded.CreateNewFolder, contentDescription = "Create Folder")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Storage Usage Banner
            storageStats?.let { stats ->
                val ratio = if (stats.totalBytes > 0) (stats.usedBytes.toFloat() / stats.totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Internal Storage", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${FileRepository.formatSize(stats.freeBytes)} free / ${FileRepository.formatSize(stats.totalBytes)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { ratio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "App Workspace: ${FileRepository.formatSize(stats.appStorageBytes)} • Mounted SAF Folders: ${settings.persistedTreeUris.size}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // SAF & Import Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { folderPicker.launch(null) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.grantFolderAccess, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Button(
                    onClick = { fileImporter.launch(arrayOf("*/*")) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Import File", maxLines = 1)
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search files & folders...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("file_manager_search")
            )

            // Category Filter Chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(FileCategory.entries) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat && currentSafUri == null,
                        onClick = {
                            currentSafUri = null
                            selectedCategory = cat
                        },
                        label = { Text(cat.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
                settings.persistedTreeUris.forEachIndexed { idx, uriStr ->
                    item(key = "saf_$idx") {
                        val u = Uri.parse(uriStr)
                        FilterChip(
                            selected = currentSafUri?.toString() == uriStr,
                            onClick = { currentSafUri = u },
                            label = { Text("SAF #${idx + 1}") }
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            if (displayed.isEmpty()) {
                EmptyStatePanel(
                    icon = Icons.Rounded.FolderOpen,
                    title = "No files in this view",
                    subtitle = "Import a file or tap 'Add Storage Folder' to browse Downloads, Documents, or SD card."
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 84.dp)
                ) {
                    items(displayed, key = { it.id }) { item ->
                        FileRowItem(
                            item = item,
                            onClick = {
                                when {
                                    item.isDirectory && item.localFile != null -> {
                                        currentLocalDir = item.localFile
                                    }
                                    item.isDirectory && item.isSafDocument -> {
                                        currentSafUri = item.uri
                                    }
                                    item.mimeType == "application/pdf" || item.name.lowercase().endsWith(".pdf") -> {
                                        onNavigate(AppRoute.PdfViewer(item.uri.toString(), item.name))
                                    }
                                    item.mimeType.startsWith("audio/") -> {
                                        onNavigate(AppRoute.Media(initialTab = 0, initialUri = item.uri.toString()))
                                    }
                                    item.mimeType.startsWith("video/") -> {
                                        onNavigate(AppRoute.Media(initialTab = 1, initialUri = item.uri.toString()))
                                    }
                                    item.mimeType.startsWith("image/") -> {
                                        onNavigate(AppRoute.Gallery)
                                    }
                                    else -> {
                                        val openIntent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(fileRepository.getShareUri(item), item.mimeType)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        runCatching { context.startActivity(openIntent) }
                                            .onFailure {
                                                Toast.makeText(context, "No viewer installed for ${item.name}", Toast.LENGTH_SHORT).show()
                                            }
                                    }
                                }
                            },
                            onRename = { renameTarget = item },
                            onCopy = { transferTarget = item to false },
                            onMove = { transferTarget = item to true },
                            onShare = {
                                val shareUri = fileRepository.getShareUri(item)
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = item.mimeType
                                    putExtra(Intent.EXTRA_STREAM, shareUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share ${item.name}"))
                            },
                            onDelete = { deleteTarget = item }
                        )
                    }
                }
            }
        }
    }

    if (showCreateFolderDialog) {
        var folderName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateFolderDialog = false },
            title = { Text("Create New Folder") },
            text = {
                OutlinedTextField(
                    value = folderName,
                    onValueChange = { folderName = it },
                    label = { Text("Folder name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        fileRepository.createFolder(currentLocalDir, folderName)
                        showCreateFolderDialog = false
                        refresh()
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateFolderDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    renameTarget?.let { target ->
        var newName by remember(target) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(strings.rename) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        fileRepository.renameItem(target, newName)
                        renameTarget = null
                        refresh()
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text(strings.cancel) }
            }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete ${target.name}?") },
            text = { Text("This action permanently removes the selected item.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        fileRepository.deleteItem(target)
                        deleteTarget = null
                        refresh()
                    }
                }) { Text(strings.delete, color = RoseAccent) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(strings.cancel) }
            }
        )
    }

    transferTarget?.let { (target, isMove) ->
        val subDirs = remember {
            fileRepository.rootWorkspaceDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
        }
        AlertDialog(
            onDismissRequest = { transferTarget = null },
            title = { Text(if (isMove) "Move to Folder" else "Copy to Folder") },
            text = {
                Column {
                    subDirs.forEach { dir ->
                        ListItem(
                            headlineContent = { Text(dir.name) },
                            leadingContent = { Icon(Icons.Rounded.Folder, contentDescription = null) },
                            modifier = Modifier.clickable {
                                scope.launch {
                                    val ok = if (isMove) fileRepository.moveLocalFile(target, dir)
                                    else fileRepository.copyLocalFile(target, dir)
                                    transferTarget = null
                                    if (ok) refresh()
                                }
                            }
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { transferTarget = null }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
private fun FileRowItem(
    item: ManagedFileItem,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    val (icon, tint) = when {
        item.isDirectory -> Icons.Rounded.Folder to SkyBlueAccent
        item.mimeType == "application/pdf" || item.name.endsWith(".pdf", true) -> Icons.Rounded.PictureAsPdf to RoseAccent
        item.mimeType.startsWith("image/") -> Icons.Rounded.Image to EmeraldAccent
        item.mimeType.startsWith("video/") -> Icons.Rounded.VideoFile to IndigoAccent
        item.mimeType.startsWith("audio/") -> Icons.Rounded.AudioFile to VioletAccent
        else -> Icons.Rounded.Description to NavyPrimary
    }

    ListItem(
        headlineContent = { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold) },
        supportingContent = {
            val sizePart = if (item.isDirectory) "Folder" else FileRepository.formatSize(item.sizeBytes)
            val datePart = if (item.lastModified > 0L) dateFmt.format(Date(item.lastModified)) else ""
            Text("$sizePart • ${item.locationLabel}${if (datePart.isNotEmpty()) " • $datePart" else ""}")
        },
        leadingContent = {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(30.dp))
        },
        trailingContent = {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Options")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Rename") },
                    leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, null) },
                    onClick = { menuOpen = false; onRename() }
                )
                if (!item.isDirectory) {
                    DropdownMenuItem(
                        text = { Text("Copy") },
                        leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) },
                        onClick = { menuOpen = false; onCopy() }
                    )
                    DropdownMenuItem(
                        text = { Text("Move") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Rounded.DriveFileMove, null) },
                        onClick = { menuOpen = false; onMove() }
                    )
                    DropdownMenuItem(
                        text = { Text("Share") },
                        leadingIcon = { Icon(Icons.Rounded.Share, null) },
                        onClick = { menuOpen = false; onShare() }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Delete", color = RoseAccent) },
                    leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = RoseAccent) },
                    onClick = { menuOpen = false; onDelete() }
                )
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
