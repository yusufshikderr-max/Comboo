package com.example.ui.screens.utilities

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.calendar.ReminderScheduler
import com.example.ui.components.ModuleTopBar
import com.example.ui.components.TrilingualDateClockCard
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyBlueAccent
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun ClockToolsScreen(
    initialTab: Int,
    hijriOffsetDays: Int,
    onOpenCalendar: () -> Unit,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    var tab by remember { mutableIntStateOf(initialTab.coerceIn(0, 2)) }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = when (tab) {
                    1 -> strings.toolStopwatch
                    2 -> strings.toolTimer
                    else -> strings.toolClock
                },
                onBack = onBack
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(strings.toolClock) }, icon = { Icon(Icons.Rounded.Schedule, null) })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(strings.toolStopwatch) }, icon = { Icon(Icons.Rounded.Timer, null) })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text(strings.toolTimer) }, icon = { Icon(Icons.Rounded.Alarm, null) })
            }
            when (tab) {
                0 -> DigitalClockTab(hijriOffsetDays, onOpenCalendar)
                1 -> StopwatchTab()
                2 -> TimerTab()
            }
        }
    }
}

@Composable
private fun DigitalClockTab(hijriOffsetDays: Int, onOpenCalendar: () -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val worldZones = listOf(
        "Dhaka" to "Asia/Dhaka",
        "London" to "Europe/London",
        "New York" to "America/New_York",
        "Makkah" to "Asia/Riyadh",
        "Tokyo" to "Asia/Tokyo"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TrilingualDateClockCard(
                hijriOffsetDays = hijriOffsetDays,
                onOpenCalendar = onOpenCalendar,
                onOpenClock = {}
            )
        }
        item {
            Text("World Clocks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(worldZones) { (city, tzId) ->
            val fmt = remember(tzId) {
                SimpleDateFormat("hh:mm:ss a • EEE, dd MMM", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone(tzId)
                }
            }
            Surface(shape = RoundedCornerShape(14.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(city, fontWeight = FontWeight.Bold) },
                    supportingContent = { Text(tzId) },
                    trailingContent = {
                        Text(fmt.format(Date(now)), fontFamily = MonoFontFamily, fontWeight = FontWeight.SemiBold)
                    }
                )
            }
        }
    }
}

@Composable
private fun StopwatchTab() {
    var running by remember { mutableStateOf(false) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    val laps = remember { mutableStateListOf<Long>() }

    LaunchedEffect(running) {
        var lastTick = System.currentTimeMillis()
        while (running) {
            delay(50L)
            val now = System.currentTimeMillis()
            elapsedMs += (now - lastTick)
            lastTick = now
        }
    }

    val mins = (elapsedMs / 60_000L)
    val secs = (elapsedMs / 1000L) % 60
    val centis = (elapsedMs / 10L) % 100

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            text = "%02d:%02d.%02d".format(mins, secs, centis),
            fontFamily = MonoFontFamily,
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { running = !running }, modifier = Modifier.testTag("stopwatch_toggle")) {
                Icon(if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text(if (running) "Pause" else "Start")
            }
            OutlinedButton(
                onClick = { if (elapsedMs > 0L) laps.add(0, elapsedMs) },
                enabled = running
            ) { Text("Lap") }
            OutlinedButton(
                onClick = {
                    running = false
                    elapsedMs = 0L
                    laps.clear()
                }
            ) {
                Icon(Icons.Rounded.Refresh, null)
                Spacer(Modifier.width(4.dp))
                Text("Reset")
            }
        }
        Spacer(Modifier.height(20.dp))
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
            itemsIndexed(laps) { idx, lapMs ->
                val m = lapMs / 60_000L
                val s = (lapMs / 1000L) % 60
                val c = (lapMs / 10L) % 100
                ListItem(
                    headlineContent = { Text("Lap ${laps.size - idx}") },
                    trailingContent = { Text("%02d:%02d.%02d".format(m, s, c), fontFamily = MonoFontFamily) }
                )
            }
        }
    }
}

@Composable
private fun TimerTab() {
    val context = LocalContext.current
    var totalSeconds by remember { mutableIntStateOf(60) }
    var remainingSeconds by remember { mutableIntStateOf(60) }
    var running by remember { mutableStateOf(false) }
    var customMinInput by remember { mutableStateOf("5") }

    LaunchedEffect(running) {
        while (running && remainingSeconds > 0) {
            delay(1000L)
            remainingSeconds--
            if (remainingSeconds == 0) {
                running = false
                ReminderScheduler.showImmediateNotification(context, "Timer Complete", "Your countdown timer has finished!", 9100)
                val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                }
                Toast.makeText(context, "Timer finished!", Toast.LENGTH_LONG).show()
            }
        }
    }

    val progress = if (totalSeconds > 0) remainingSeconds.toFloat() / totalSeconds.toFloat() else 0f
    val m = remainingSeconds / 60
    val s = remainingSeconds % 60

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { progress },
                modifier = Modifier.size(190.dp),
                strokeWidth = 10.dp
            )
            Text(
                text = "%02d:%02d".format(m, s),
                fontFamily = MonoFontFamily,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(20.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf(60 to "1 min", 300 to "5 min", 600 to "10 min", 1500 to "25 min")) { (sec, label) ->
                FilterChip(
                    selected = totalSeconds == sec && !running,
                    onClick = {
                        running = false
                        totalSeconds = sec
                        remainingSeconds = sec
                    },
                    label = { Text(label) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = customMinInput,
                onValueChange = { customMinInput = it.filter { c -> c.isDigit() } },
                label = { Text("Minutes") },
                singleLine = true,
                modifier = Modifier.width(120.dp)
            )
            OutlinedButton(onClick = {
                val mins = (customMinInput.toIntOrNull() ?: 1).coerceIn(1, 360)
                running = false
                totalSeconds = mins * 60
                remainingSeconds = mins * 60
            }) { Text("Set") }
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { running = !running },
                enabled = remainingSeconds > 0,
                modifier = Modifier.testTag("timer_toggle")
            ) {
                Icon(if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text(if (running) "Pause" else "Start")
            }
            OutlinedButton(onClick = {
                running = false
                remainingSeconds = totalSeconds
            }) { Text("Reset") }
        }
    }
}

@androidx.annotation.OptIn(ExperimentalGetImage::class)
@Composable
fun QrScannerScreen(onBack: () -> Unit) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { hasCameraPerm = it }

    var scannedValue by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val img = InputImage.fromFilePath(context, uri)
                BarcodeScanning.getClient().process(img).addOnSuccessListener { barcodes ->
                    val raw = barcodes.firstOrNull()?.rawValue
                    if (!raw.isNullOrBlank()) scannedValue = raw
                    else Toast.makeText(context, "No QR/Barcode found in image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            ModuleTopBar(title = strings.toolQrScanner, subtitle = "ML Kit Barcode & QR", onBack = onBack)
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (hasCameraPerm) {
                    var boundProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
                    val scanner = remember { BarcodeScanning.getClient() }
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx).apply {
                                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                            }
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val provider = cameraProviderFuture.get()
                                boundProvider = provider
                                val preview = Preview.Builder().build().also {
                                    it.surfaceProvider = previewView.surfaceProvider
                                }
                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                analysis.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                                    val mediaImage = imageProxy.image
                                    if (mediaImage != null) {
                                        val inputImage = InputImage.fromMediaImage(
                                            mediaImage,
                                            imageProxy.imageInfo.rotationDegrees
                                        )
                                        scanner.process(inputImage)
                                            .addOnSuccessListener { barcodes ->
                                                val code = barcodes.firstOrNull()?.rawValue
                                                if (!code.isNullOrBlank()) scannedValue = code
                                            }
                                            .addOnCompleteListener { imageProxy.close() }
                                    } else {
                                        imageProxy.close()
                                    }
                                }
                                runCatching {
                                    provider.unbindAll()
                                    provider.bindToLifecycle(
                                        lifecycleOwner,
                                        CameraSelector.DEFAULT_BACK_CAMERA,
                                        preview,
                                        analysis
                                    )
                                }
                            }, ContextCompat.getMainExecutor(ctx))
                            previewView
                        },
                        onRelease = {
                            runCatching { boundProvider?.unbindAll() }
                            runCatching { scanner.close() }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Rounded.QrCodeScanner, null, tint = SkyBlueAccent, modifier = Modifier.size(56.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Camera permission is needed for live QR & Barcode scanning.")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) {
                            Text("Allow Camera")
                        }
                    }
                }
            }

            Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedButton(
                        onClick = {
                            imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.ImageSearch, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Scan QR from Gallery Image")
                    }
                    if (scannedValue != null) {
                        Spacer(Modifier.height(10.dp))
                        Text("Scanned Result:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(scannedValue!!, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (scannedValue!!.startsWith("http://") || scannedValue!!.startsWith("https://")) {
                                Button(onClick = {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(scannedValue!!)))
                                }) { Text("Open Link") }
                            }
                            OutlinedButton(onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("QR", scannedValue))
                                Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Rounded.ContentCopy, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Copy")
                            }
                            OutlinedButton(onClick = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, scannedValue)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share QR"))
                            }) {
                                Icon(Icons.Rounded.Share, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Share")
                            }
                        }
                    }
                }
            }
        }
    }
}

private enum class UnitCategory(val label: String, val units: List<Pair<String, Double>>) {
    LENGTH("Length", listOf("Meter (m)" to 1.0, "Kilometer (km)" to 1000.0, "Centimeter (cm)" to 0.01, "Mile (mi)" to 1609.344, "Foot (ft)" to 0.3048, "Inch (in)" to 0.0254)),
    WEIGHT("Weight", listOf("Kilogram (kg)" to 1.0, "Gram (g)" to 0.001, "Pound (lb)" to 0.453592, "Ounce (oz)" to 0.0283495, "Ton (t)" to 1000.0)),
    TEMPERATURE("Temp", listOf("Celsius (°C)" to 1.0, "Fahrenheit (°F)" to 2.0, "Kelvin (K)" to 3.0)),
    DATA("Data", listOf("Megabyte (MB)" to 1.0, "Kilobyte (KB)" to 1.0 / 1024.0, "Gigabyte (GB)" to 1024.0, "Terabyte (TB)" to 1024.0 * 1024.0)),
    SPEED("Speed", listOf("km/h" to 1.0, "m/s" to 3.6, "mph" to 1.60934)),
    AREA("Area", listOf("Sq Meter (m²)" to 1.0, "Sq Foot (ft²)" to 0.092903, "Acre" to 4046.86, "Hectare" to 10000.0))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    val strings = LocalAppStrings.current
    var category by remember { mutableStateOf(UnitCategory.LENGTH) }
    var inputStr by remember { mutableStateOf("1") }
    var fromIdx by remember { mutableIntStateOf(0) }
    var toIdx by remember { mutableIntStateOf(1) }
    var fromExpanded by remember { mutableStateOf(false) }
    var toExpanded by remember { mutableStateOf(false) }

    val inputVal = inputStr.toDoubleOrNull() ?: 0.0
    val units = category.units
    val safeFrom = fromIdx.coerceIn(0, units.lastIndex)
    val safeTo = toIdx.coerceIn(0, units.lastIndex)

    val result = remember(category, inputVal, safeFrom, safeTo) {
        if (category == UnitCategory.TEMPERATURE) {
            val celsius = when (safeFrom) {
                1 -> (inputVal - 32.0) * 5.0 / 9.0
                2 -> inputVal - 273.15
                else -> inputVal
            }
            when (safeTo) {
                1 -> celsius * 9.0 / 5.0 + 32.0
                2 -> celsius + 273.15
                else -> celsius
            }
        } else {
            val base = inputVal * units[safeFrom].second
            base / units[safeTo].second
        }
    }

    Scaffold(
        topBar = {
            ModuleTopBar(title = strings.toolUnitConverter, onBack = onBack)
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(UnitCategory.entries) { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat; fromIdx = 0; toIdx = 1.coerceAtMost(cat.units.lastIndex) },
                        label = { Text(cat.label) }
                    )
                }
            }

            OutlinedTextField(
                value = inputStr,
                onValueChange = { inputStr = it },
                label = { Text("Value") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("converter_input")
            )

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(
                    expanded = fromExpanded,
                    onExpandedChange = { fromExpanded = !fromExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = units[safeFrom].first,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("From") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(fromExpanded) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = fromExpanded, onDismissRequest = { fromExpanded = false }) {
                        units.forEachIndexed { idx, (name, _) ->
                            DropdownMenuItem(text = { Text(name) }, onClick = { fromIdx = idx; fromExpanded = false })
                        }
                    }
                }

                IconButton(onClick = { val tmp = safeFrom; fromIdx = safeTo; toIdx = tmp }) {
                    Icon(Icons.Rounded.SwapHoriz, "Swap Units")
                }

                ExposedDropdownMenuBox(
                    expanded = toExpanded,
                    onExpandedChange = { toExpanded = !toExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = units[safeTo].first,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("To") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(toExpanded) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = toExpanded, onDismissRequest = { toExpanded = false }) {
                        units.forEachIndexed { idx, (name, _) ->
                            DropdownMenuItem(text = { Text(name) }, onClick = { toIdx = idx; toExpanded = false })
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NavyPrimary,
                contentColor = PureWhite,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Converted Value", style = MaterialTheme.typography.labelMedium, color = SkyBlueAccent)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "%.6f".format(result).trimEnd('0').trimEnd('.') + " ${units[safeTo].first}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
