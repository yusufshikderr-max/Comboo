package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyBlueAccent
import kotlinx.coroutines.delay

@Composable
fun SplashScreenOverlay(
    visible: Boolean,
    onFinished: () -> Unit
) {
    var animStarted by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (animStarted) 1f else 0.78f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "splash_logo_scale"
    )

    LaunchedEffect(visible) {
        if (visible) {
            animStarted = true
            delay(950L)
            onFinished()
        }
    }

    AnimatedVisibility(
        visible = visible,
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(NavyDeep, NavyPrimary, NavyContainer)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    shadowElevation = 16.dp,
                    modifier = Modifier
                        .size(110.dp)
                        .scale(scale)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.smart_combo_icon_fg_1795020987438),
                        contentDescription = "Smart All-in-One Logo",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(28.dp))
                    )
                }
                Spacer(Modifier.height(22.dp))
                Text(
                    text = "Smart All-in-One",
                    style = MaterialTheme.typography.headlineMedium,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Files • PDF • Calendar • Media • Utilities",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SkyBlueAccent
                )
                Spacer(Modifier.height(28.dp))
                LinearProgressIndicator(
                    color = SkyBlueAccent,
                    trackColor = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                )
            }
        }
    }
}
