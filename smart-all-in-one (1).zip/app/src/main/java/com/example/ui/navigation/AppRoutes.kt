package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.LightBlueBright
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.RoseAccent
import com.example.ui.theme.SkyBlueAccent
import com.example.ui.theme.VioletAccent
import kotlinx.serialization.Serializable

@Serializable
sealed interface AppRoute {
    @Serializable data object Home : AppRoute
    @Serializable data object Tools : AppRoute
    @Serializable data class Media(val initialTab: Int = 0, val initialUri: String? = null) : AppRoute
    @Serializable data object Calendar : AppRoute
    @Serializable data object Settings : AppRoute

    // Module Destinations
    @Serializable data class FileManager(val initialCategory: String = "ALL") : AppRoute
    @Serializable data object Gallery : AppRoute
    @Serializable data object Contacts : AppRoute
    @Serializable data object Calculator : AppRoute
    @Serializable data object PdfLibrary : AppRoute
    @Serializable data class PdfViewer(val uriString: String, val title: String = "Document") : AppRoute
    @Serializable data object DocumentScanner : AppRoute
    @Serializable data object Gmail : AppRoute
    @Serializable data object Notes : AppRoute
    @Serializable data object Todo : AppRoute
    @Serializable data object YouTube : AppRoute
    @Serializable data object Maps : AppRoute
    @Serializable data object GoogleSearch : AppRoute
    @Serializable data object AiAssistant : AppRoute
    @Serializable data object QrScanner : AppRoute
    @Serializable data class ClockTools(val initialTab: Int = 0) : AppRoute // 0=Clock, 1=Stopwatch, 2=Timer
    @Serializable data object UnitConverter : AppRoute
}

enum class ToolCategory {
    ESSENTIAL,
    PRODUCTIVITY,
    ENTERTAINMENT,
    NAV_SEARCH,
    AI_ASSISTANT,
    EXTRA_UTILITIES
}

data class ToolDescriptor(
    val id: String,
    val title: (AppStrings) -> String,
    val icon: ImageVector,
    val accentColor: Color,
    val category: ToolCategory,
    val route: AppRoute? = null // null for instant action like Flashlight
)

object ToolCatalog {
    val allTools: List<ToolDescriptor> = listOf(
        // Essential Tools
        ToolDescriptor("file_manager", { it.toolFileManager }, Icons.Rounded.FolderOpen, Color(0xFF2563EB), ToolCategory.ESSENTIAL, AppRoute.FileManager()),
        ToolDescriptor("gallery", { it.toolGallery }, Icons.Rounded.PhotoLibrary, Color(0xFF0EA5E9), ToolCategory.ESSENTIAL, AppRoute.Gallery),
        ToolDescriptor("contacts", { it.toolContacts }, Icons.Rounded.AccountCircle, EmeraldAccent, ToolCategory.ESSENTIAL, AppRoute.Contacts),
        ToolDescriptor("calculator", { it.toolCalculator }, Icons.Rounded.Calculate, IndigoAccent, ToolCategory.ESSENTIAL, AppRoute.Calculator),
        ToolDescriptor("pdf_reader", { it.toolPdfReader }, Icons.Rounded.PictureAsPdf, RoseAccent, ToolCategory.ESSENTIAL, AppRoute.PdfLibrary),

        // Productivity
        ToolDescriptor("calendar", { it.toolCalendar }, Icons.Rounded.CalendarMonth, NavyPrimary, ToolCategory.PRODUCTIVITY, AppRoute.Calendar),
        ToolDescriptor("scanner", { it.toolScanner }, Icons.Rounded.DocumentScanner, Color(0xFF0284C7), ToolCategory.PRODUCTIVITY, AppRoute.DocumentScanner),
        ToolDescriptor("gmail", { it.toolGmail }, Icons.Rounded.Mail, Color(0xFFDC2626), ToolCategory.PRODUCTIVITY, AppRoute.Gmail),
        ToolDescriptor("notes", { it.toolNotes }, Icons.Rounded.EditNote, AmberAccent, ToolCategory.PRODUCTIVITY, AppRoute.Notes),
        ToolDescriptor("todo", { it.toolTodo }, Icons.Rounded.Checklist, EmeraldAccent, ToolCategory.PRODUCTIVITY, AppRoute.Todo),

        // Entertainment
        ToolDescriptor("audio_player", { it.toolAudioPlayer }, Icons.Rounded.MusicNote, VioletAccent, ToolCategory.ENTERTAINMENT, AppRoute.Media(initialTab = 0)),
        ToolDescriptor("video_player", { it.toolVideoPlayer }, Icons.Rounded.VideoLibrary, Color(0xFF2563EB), ToolCategory.ENTERTAINMENT, AppRoute.Media(initialTab = 1)),
        ToolDescriptor("youtube", { it.toolYouTube }, Icons.Rounded.PlayCircle, Color(0xFFEF4444), ToolCategory.ENTERTAINMENT, AppRoute.YouTube),

        // Navigation & Search
        ToolDescriptor("maps", { it.toolMaps }, Icons.Rounded.Map, EmeraldAccent, ToolCategory.NAV_SEARCH, AppRoute.Maps),
        ToolDescriptor("google_search", { it.toolGoogleSearch }, Icons.Rounded.Search, LightBlueBright, ToolCategory.NAV_SEARCH, AppRoute.GoogleSearch),

        // AI Assistant
        ToolDescriptor("chatgpt", { it.toolChatGpt }, Icons.Rounded.AutoAwesome, CyanAccent, ToolCategory.AI_ASSISTANT, AppRoute.AiAssistant),

        // Extra Utilities
        ToolDescriptor("qr_scanner", { it.toolQrScanner }, Icons.Rounded.QrCodeScanner, NavyPrimary, ToolCategory.EXTRA_UTILITIES, AppRoute.QrScanner),
        ToolDescriptor("clock", { it.toolClock }, Icons.Rounded.Schedule, SkyBlueAccent, ToolCategory.EXTRA_UTILITIES, AppRoute.ClockTools(0)),
        ToolDescriptor("stopwatch", { it.toolStopwatch }, Icons.Rounded.Timer, IndigoAccent, ToolCategory.EXTRA_UTILITIES, AppRoute.ClockTools(1)),
        ToolDescriptor("timer", { it.toolTimer }, Icons.Rounded.Alarm, AmberAccent, ToolCategory.EXTRA_UTILITIES, AppRoute.ClockTools(2)),
        ToolDescriptor("unit_converter", { it.toolUnitConverter }, Icons.Rounded.SwapHoriz, Color(0xFF0EA5E9), ToolCategory.EXTRA_UTILITIES, AppRoute.UnitConverter),
        ToolDescriptor("flashlight", { it.toolFlashlight }, Icons.Rounded.FlashlightOn, AmberAccent, ToolCategory.EXTRA_UTILITIES, null)
    )

    fun byId(id: String): ToolDescriptor? = allTools.find { it.id == id }
}
