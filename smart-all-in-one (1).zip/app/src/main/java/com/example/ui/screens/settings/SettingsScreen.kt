package com.example.ui.screens.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.FolderShared
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.calendar.ReminderScheduler
import com.example.data.local.AppSettings
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.navigation.ToolCatalog
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.ThemeMode

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetLanguage: (AppLanguage) -> Unit,
    onSetHijriOffset: (Int) -> Unit,
    onSetNotifications: (Boolean) -> Unit,
    onToggleShortcut: (String) -> Unit,
    onAddFolderUri: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) onAddFolderUri(uri)
    }

    val notificationPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onSetNotifications(true)
            ReminderScheduler.showImmediateNotification(
                context,
                "Smart All-in-One",
                "Notifications are active for reminders & timers."
            )
        }
    }

    var expandShortcuts by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        Surface(color = NavyPrimary, contentColor = PureWhite) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Text(
                    text = strings.settingsTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Theme Mode
            item {
                SettingsCard(title = strings.appearanceSection, icon = Icons.Rounded.DarkMode) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            ThemeMode.SYSTEM to strings.themeSystem,
                            ThemeMode.LIGHT to strings.themeLight,
                            ThemeMode.DARK to strings.themeDark
                        ).forEach { (mode, label) ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { onSetThemeMode(mode) },
                                label = { Text(label) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("theme_${mode.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // 2. Language (English / Bengali)
            item {
                SettingsCard(title = strings.languageSection, icon = Icons.Rounded.Language) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = settings.language == lang,
                                onClick = { onSetLanguage(lang) },
                                label = { Text(lang.displayName) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("lang_${lang.code}")
                            )
                        }
                    }
                }
            }

            // 3. Hijri Date Adjustment
            item {
                SettingsCard(title = strings.hijriAdjustment, icon = Icons.Rounded.Notifications) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${if (settings.hijriOffsetDays > 0) "+" else ""}${settings.hijriOffsetDays} ${strings.daysUnit}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { onSetHijriOffset(settings.hijriOffsetDays - 1) },
                                enabled = settings.hijriOffsetDays > -2
                            ) {
                                Icon(Icons.Rounded.Remove, contentDescription = "Decrease Hijri offset")
                            }
                            IconButton(
                                onClick = { onSetHijriOffset(settings.hijriOffsetDays + 1) },
                                enabled = settings.hijriOffsetDays < 2
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = "Increase Hijri offset")
                            }
                        }
                    }
                }
            }

            // 4. Notification Settings
            item {
                SettingsCard(title = strings.notificationsPref, icon = Icons.Rounded.Notifications) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Calendar & Timer Alerts", modifier = Modifier.weight(1f))
                        Switch(
                            checked = settings.notificationsEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    val granted = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (!granted) {
                                        notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        return@Switch
                                    }
                                }
                                onSetNotifications(enabled)
                            },
                            modifier = Modifier.testTag("notifications_switch")
                        )
                    }
                }
            }

            // 5. Customize Dashboard Shortcuts
            item {
                SettingsCard(title = strings.dashboardShortcuts, icon = Icons.Rounded.FolderShared) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandShortcuts = !expandShortcuts },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${settings.pinnedShortcuts.size} pinned on Home")
                        Text(
                            if (expandShortcuts) "Hide" else "Edit",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (expandShortcuts) {
                        Spacer(Modifier.height(8.dp))
                        ToolCatalog.allTools.forEach { tool ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onToggleShortcut(tool.id) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(tool.icon, contentDescription = null, tint = tool.accentColor)
                                Spacer(Modifier.width(10.dp))
                                Text(tool.title(strings), modifier = Modifier.weight(1f))
                                Checkbox(
                                    checked = settings.pinnedShortcuts.contains(tool.id),
                                    onCheckedChange = { onToggleShortcut(tool.id) }
                                )
                            }
                        }
                    }
                }
            }

            // 6. Storage & Privacy Permissions
            item {
                SettingsCard(title = strings.permissionsPrivacy, icon = Icons.Rounded.Security) {
                    val camGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                    val contactsGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
                    val locGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

                    Text("Camera: ${if (camGranted) "Granted" else "Not requested"}")
                    Text("Contacts: ${if (contactsGranted) "Granted" else "Not requested"}")
                    Text("Location: ${if (locGranted) "Granted" else "Not requested"}")
                    Text("SAF Mounted Folders: ${settings.persistedTreeUris.size}")
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { folderPicker.launch(null) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(strings.grantFolderAccess)
                        }
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", context.packageName, null)
                                )
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("App Permissions")
                        }
                    }
                }
            }

            // 7. About & Version Info
            item {
                SettingsCard(title = strings.aboutApp, icon = Icons.Rounded.Info) {
                    Text(strings.appName, fontWeight = FontWeight.Bold)
                    Text(strings.versionLabel, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    Text(
                        "Combines File Manager, Gallery, Contacts, Trilingual Calendar (Bengali/English/Hijri), Advanced PDF Reader, CameraX Document Scanner with OCR, Media3 Audio/Video Player, Calculator, Notes, To-do, QR Scanner, Maps, YouTube, Search, Gmail, and AI Assistant.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}
