package com.example.ui.screens.web

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.speech.RecognizerIntent
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.TrendingUp
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Directions
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.PureWhite
import com.google.android.gms.location.LocationServices

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun InAppWebView(
    url: String,
    onUrlChanged: (String) -> Unit = {},
    onProgressChanged: (Int) -> Unit = {},
    onWebViewReady: (WebView) -> Unit = {},
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.setGeolocationEnabled(true)
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val reqUrl = request?.url?.toString() ?: return false
                        return if (reqUrl.startsWith("http://") || reqUrl.startsWith("https://")) {
                            false
                        } else {
                            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(reqUrl))) }
                            true
                        }
                    }

                    override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                        if (loadedUrl != null) onUrlChanged(loadedUrl)
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        onProgressChanged(newProgress)
                    }

                    override fun onGeolocationPermissionsShowPrompt(
                        origin: String?,
                        callback: GeolocationPermissions.Callback?
                    ) {
                        callback?.invoke(origin, true, false)
                    }
                }
                loadUrl(url)
                onWebViewReady(this)
            }
        },
        onRelease = { webView ->
            webView.stopLoading()
            webView.destroy()
        },
        modifier = modifier
    )
}

@Composable
fun YouTubeScreen(onBack: () -> Unit) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var currentUrl by remember { mutableStateOf("https://m.youtube.com") }
    var progress by remember { mutableIntStateOf(100) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    fun load(target: String) {
        currentUrl = target
        webViewRef?.loadUrl(target)
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolYouTube,
                subtitle = "Official YouTube Experience",
                onBack = {
                    if (webViewRef?.canGoBack() == true) webViewRef?.goBack() else onBack()
                },
                actions = {
                    IconButton(onClick = {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl)))
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, "Open in YouTube App", tint = PureWhite)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search YouTube videos...") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                )
                Button(onClick = {
                    if (searchQuery.isNotBlank()) {
                        load("https://m.youtube.com/results?search_query=${Uri.encode(searchQuery)}")
                    }
                }) {
                    Icon(Icons.Rounded.Search, null)
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = currentUrl == "https://m.youtube.com",
                        onClick = { load("https://m.youtube.com") },
                        label = { Text("Home") },
                        leadingIcon = { Icon(Icons.Rounded.Home, null, Modifier.size(16.dp)) }
                    )
                }
                item {
                    FilterChip(
                        selected = currentUrl.contains("trending"),
                        onClick = { load("https://m.youtube.com/feed/trending") },
                        label = { Text("Trending") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Rounded.TrendingUp, null, Modifier.size(16.dp)) }
                    )
                }
                item {
                    FilterChip(
                        selected = currentUrl.contains("explore"),
                        onClick = { load("https://m.youtube.com/feed/explore") },
                        label = { Text("Channels") },
                        leadingIcon = { Icon(Icons.Rounded.Explore, null, Modifier.size(16.dp)) }
                    )
                }
            }

            if (progress in 1..99) {
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            }

            InAppWebView(
                url = "https://m.youtube.com",
                onUrlChanged = { currentUrl = it },
                onProgressChanged = { progress = it },
                onWebViewReady = { webViewRef = it },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        }
    }
}

@Composable
fun MapsScreen(onBack: () -> Unit) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val fusedClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    var searchQuery by remember { mutableStateOf("") }
    var satelliteMode by remember { mutableStateOf(false) }
    var zoomLevel by remember { mutableIntStateOf(15) }
    var lat by remember { mutableDoubleStateOf(23.8103) } // Default Dhaka; updated by live GPS
    var lng by remember { mutableDoubleStateOf(90.4125) }
    var hasLocation by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(100) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    fun mapUrl(query: String? = null): String {
        val layer = if (satelliteMode) "k" else "m"
        return if (!query.isNullOrBlank()) {
            "https://maps.google.com/maps?q=${Uri.encode(query)}&t=$layer&z=$zoomLevel"
        } else {
            "https://maps.google.com/maps?q=$lat,$lng&t=$layer&z=$zoomLevel"
        }
    }

    fun fetchCurrentLocation() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) return
        fusedClient.lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                lat = loc.latitude
                lng = loc.longitude
                hasLocation = true
                webViewRef?.loadUrl(mapUrl())
            }
        }
    }

    val locPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true || res[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            fetchCurrentLocation()
        }
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolMaps,
                subtitle = if (hasLocation) "%.4f, %.4f".format(lat, lng) else "Interactive Maps & Navigation",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        satelliteMode = !satelliteMode
                        webViewRef?.loadUrl(mapUrl(searchQuery.ifBlank { null }))
                    }) {
                        Icon(Icons.Rounded.Layers, "Toggle Satellite View", tint = PureWhite)
                    }
                    IconButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "https://maps.google.com/?q=$lat,$lng")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Location"))
                    }) {
                        Icon(Icons.Rounded.Share, "Share Location", tint = PureWhite)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search places, restaurants...") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                )
                Button(onClick = { webViewRef?.loadUrl(mapUrl(searchQuery)) }) {
                    Icon(Icons.Rounded.Search, null)
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = hasLocation,
                        onClick = {
                            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            if (granted) fetchCurrentLocation()
                            else locPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        },
                        label = { Text("My Location") },
                        leadingIcon = { Icon(Icons.Rounded.MyLocation, null, Modifier.size(16.dp)) }
                    )
                }
                item {
                    FilterChip(
                        selected = false,
                        onClick = {
                            val dest = searchQuery.ifBlank { "$lat,$lng" }
                            val navUri = Uri.parse("google.navigation:q=${Uri.encode(dest)}")
                            val navIntent = Intent(Intent.ACTION_VIEW, navUri).setPackage("com.google.android.apps.maps")
                            runCatching { context.startActivity(navIntent) }.onFailure {
                                webViewRef?.loadUrl("https://maps.google.com/maps?daddr=${Uri.encode(dest)}")
                            }
                        },
                        label = { Text("Directions") },
                        leadingIcon = { Icon(Icons.Rounded.Directions, null, Modifier.size(16.dp)) }
                    )
                }
                items(listOf("Restaurants", "Hospitals", "ATMs", "Fuel", "Mosques")) { nearby ->
                    FilterChip(
                        selected = searchQuery == nearby,
                        onClick = {
                            searchQuery = nearby
                            webViewRef?.loadUrl("https://maps.google.com/maps?q=${Uri.encode("$nearby near $lat,$lng")}")
                        },
                        label = { Text(nearby) }
                    )
                }
            }

            if (progress in 1..99) {
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                InAppWebView(
                    url = mapUrl(),
                    onProgressChanged = { progress = it },
                    onWebViewReady = { webViewRef = it },
                    modifier = Modifier.fillMaxSize()
                )
                Column(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        onClick = {
                            zoomLevel = (zoomLevel + 1).coerceAtMost(20)
                            webViewRef?.loadUrl(mapUrl(searchQuery.ifBlank { null }))
                        },
                        shape = RoundedCornerShape(12.dp),
                        tonalElevation = 4.dp
                    ) { Icon(Icons.Rounded.ZoomIn, "Zoom In", modifier = Modifier.padding(10.dp)) }
                    Surface(
                        onClick = {
                            zoomLevel = (zoomLevel - 1).coerceAtLeast(3)
                            webViewRef?.loadUrl(mapUrl(searchQuery.ifBlank { null }))
                        },
                        shape = RoundedCornerShape(12.dp),
                        tonalElevation = 4.dp
                    ) { Icon(Icons.Rounded.ZoomOut, "Zoom Out", modifier = Modifier.padding(10.dp)) }
                }
            }
        }
    }
}

private enum class SearchMode(val label: String, val param: String) {
    WEB("Web", ""),
    IMAGES("Images", "&tbm=isch"),
    NEWS("News", "&tbm=nws")
}

@Composable
fun GoogleSearchScreen(onBack: () -> Unit) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(SearchMode.WEB) }
    var currentUrl by remember { mutableStateOf("https://www.google.com") }
    var progress by remember { mutableIntStateOf(100) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    fun runSearch(q: String, m: SearchMode = mode) {
        val url = if (q.isBlank()) "https://www.google.com"
        else "https://www.google.com/search?q=${Uri.encode(q)}${m.param}"
        currentUrl = url
        webViewRef?.loadUrl(url)
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                query = spoken
                runSearch(spoken)
            }
        }
    }

    val suggestions = listOf("Weather today", "Tech news", "Currency USD to BDT", "Translate English to Bengali")

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolGoogleSearch,
                subtitle = "Web, Images, News & Voice",
                onBack = { if (webViewRef?.canGoBack() == true) webViewRef?.goBack() else onBack() },
                actions = {
                    IconButton(onClick = {
                        runCatching { CustomTabsIntent.Builder().build().launchUrl(context, Uri.parse(currentUrl)) }
                    }) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, "Open in Browser", tint = PureWhite)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search Google...") },
                    trailingIcon = {
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            }
                            runCatching { voiceLauncher.launch(intent) }
                                .onFailure { Toast.makeText(context, "Voice search unavailable", Toast.LENGTH_SHORT).show() }
                        }) {
                            Icon(Icons.Rounded.Mic, "Voice Search")
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).testTag("google_search_input")
                )
                Button(onClick = { runSearch(query) }) {
                    Icon(Icons.Rounded.Search, null)
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(SearchMode.entries) { m ->
                    FilterChip(
                        selected = mode == m,
                        onClick = { mode = m; runSearch(query, m) },
                        label = { Text(m.label) }
                    )
                }
                items(suggestions) { s ->
                    FilterChip(
                        selected = false,
                        onClick = { query = s; runSearch(s) },
                        label = { Text(s) }
                    )
                }
            }

            if (progress in 1..99) {
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            }

            InAppWebView(
                url = "https://www.google.com",
                onUrlChanged = { currentUrl = it },
                onProgressChanged = { progress = it },
                onWebViewReady = { webViewRef = it },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        }
    }
}

@Composable
fun GmailScreen(onBack: () -> Unit) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var progress by remember { mutableIntStateOf(100) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showComposeDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolGmail,
                subtitle = "Official Google Mail & Compose",
                onBack = { if (webViewRef?.canGoBack() == true) webViewRef?.goBack() else onBack() },
                actions = {
                    IconButton(onClick = { webViewRef?.loadUrl("https://mail.google.com/mail/mu/mp/#tl/Inbox") }) {
                        Icon(Icons.Rounded.Inbox, "Inbox", tint = PureWhite)
                    }
                    IconButton(onClick = { webViewRef?.loadUrl("https://mail.google.com/mail/mu/mp/#tl/Sent") }) {
                        Icon(Icons.AutoMirrored.Rounded.Send, "Sent", tint = PureWhite)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showComposeDialog = true },
                modifier = Modifier.testTag("gmail_compose_fab")
            ) {
                Icon(Icons.Rounded.Edit, "Compose Email")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (progress in 1..99) {
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            }
            InAppWebView(
                url = "https://mail.google.com",
                onProgressChanged = { progress = it },
                onWebViewReady = { webViewRef = it },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        }
    }

    if (showComposeDialog) {
        var to by remember { mutableStateOf("") }
        var subject by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        var attachmentUri by remember { mutableStateOf<Uri?>(null) }

        val attachLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument()
        ) { uri -> attachmentUri = uri }

        AlertDialog(
            onDismissRequest = { showComposeDialog = false },
            title = { Text("Compose Email") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = to, onValueChange = { to = it }, label = { Text("To") }, singleLine = true)
                    OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject") }, singleLine = true)
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Message") }, minLines = 3)
                    OutlinedButton(onClick = { attachLauncher.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Rounded.AttachFile, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (attachmentUri != null) "Attachment Added" else "Attach File")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = if (attachmentUri != null) "*/*" else "message/rfc822"
                        if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to.trim()))
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, body)
                        attachmentUri?.let {
                            putExtra(Intent.EXTRA_STREAM, it)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                    }
                    runCatching { context.startActivity(Intent.createChooser(intent, "Send with Gmail")) }
                        .onFailure { Toast.makeText(context, "No email app available", Toast.LENGTH_SHORT).show() }
                    showComposeDialog = false
                }) { Text("Send") }
            },
            dismissButton = {
                TextButton(onClick = { showComposeDialog = false }) { Text("Cancel") }
            }
        )
    }
}
