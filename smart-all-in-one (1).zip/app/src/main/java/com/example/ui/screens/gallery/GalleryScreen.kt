package com.example.ui.screens.gallery

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayCircleFilled
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.files.FileCategory
import com.example.data.files.FileRepository
import com.example.data.files.ManagedFileItem
import com.example.data.local.AppSettings
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.navigation.AppRoute
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class GalleryTab { ALL, ALBUMS, RECENT }

@Composable
fun GalleryScreen(
    settings: AppSettings,
    fileRepository: FileRepository,
    onAddPickedUris: (Collection<String>) -> Unit,
    onRemovePickedUri: (String) -> Unit,
    onRecordView: (String) -> Unit,
    onNavigate: (AppRoute) -> Unit,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by remember { mutableStateOf(GalleryTab.ALL) }
    var selectedAlbum by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var sortNewest by remember { mutableStateOf(true) }
    var mediaItems by remember { mutableStateOf<List<ManagedFileItem>>(emptyList()) }
    var viewerStartIndex by remember { mutableStateOf<Int?>(null) }

    fun loadGallery() {
        scope.launch {
            val workspaceImages = fileRepository.collectCategoryFiles(FileCategory.IMAGES, settings.persistedTreeUris)
            val workspaceVideos = fileRepository.collectCategoryFiles(FileCategory.VIDEOS, settings.persistedTreeUris)
            val pickedItems = settings.pickedMediaUris.mapNotNull { uriStr ->
                runCatching {
                    val uri = Uri.parse(uriStr)
                    val name = FileRepository.queryDisplayName(context.contentResolver, uri) ?: "Media"
                    val mime = context.contentResolver.getType(uri) ?: FileRepository.guessMimeType(name)
                    ManagedFileItem(
                        id = uriStr,
                        name = name,
                        uri = uri,
                        sizeBytes = 0L,
                        lastModified = System.currentTimeMillis(),
                        mimeType = mime,
                        locationLabel = "Photo Picker"
                    )
                }.getOrNull()
            }
            mediaItems = (workspaceImages + workspaceVideos + pickedItems).distinctBy { it.uri.toString() }
        }
    }

    LaunchedEffect(settings.pickedMediaUris, settings.persistedTreeUris) {
        loadGallery()
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(25)
    ) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { fileRepository.takePersistablePermission(it) }
            onAddPickedUris(uris.map { it.toString() })
        }
    }

    val filtered = remember(mediaItems, tab, selectedAlbum, searchQuery, sortNewest, settings.recentGalleryUris) {
        val base = when (tab) {
            GalleryTab.ALL -> mediaItems
            GalleryTab.ALBUMS -> if (selectedAlbum == null) mediaItems else mediaItems.filter { it.locationLabel == selectedAlbum }
            GalleryTab.RECENT -> settings.recentGalleryUris.mapNotNull { recentUri ->
                mediaItems.find { it.uri.toString() == recentUri }
            }
        }
        val searched = if (searchQuery.isBlank()) base else base.filter { it.name.contains(searchQuery, true) }
        if (sortNewest) searched.sortedByDescending { it.lastModified } else searched.sortedBy { it.name.lowercase() }
    }

    val imageOnlyList = remember(filtered) { filtered.filter { !it.mimeType.startsWith("video/") } }

    if (viewerStartIndex != null && imageOnlyList.isNotEmpty()) {
        val startIdx = viewerStartIndex!!.coerceIn(0, imageOnlyList.lastIndex)
        FullScreenPhotoViewer(
            images = imageOnlyList,
            initialIndex = startIdx,
            fileRepository = fileRepository,
            onRecordView = onRecordView,
            onDelete = { item ->
                scope.launch {
                    if (item.localFile != null || item.isSafDocument) {
                        fileRepository.deleteItem(item)
                    } else {
                        onRemovePickedUri(item.uri.toString())
                    }
                    viewerStartIndex = null
                    loadGallery()
                }
            },
            onClose = { viewerStartIndex = null }
        )
        return
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolGallery,
                subtitle = "${filtered.size} photos & videos",
                onBack = onBack,
                actions = {
                    TextButton(onClick = { sortNewest = !sortNewest }) {
                        Text(if (sortNewest) "Newest" else "A–Z", color = PureWhite)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("gallery_pick_media_button")
                ) {
                    Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.pickPhotosVideos)
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search photos & videos...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(GalleryTab.entries) { t ->
                    FilterChip(
                        selected = tab == t,
                        onClick = { tab = t; selectedAlbum = null },
                        label = { Text(t.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
                if (tab == GalleryTab.ALBUMS) {
                    val albums = mediaItems.map { it.locationLabel }.distinct()
                    items(albums) { album ->
                        FilterChip(
                            selected = selectedAlbum == album,
                            onClick = { selectedAlbum = if (selectedAlbum == album) null else album },
                            label = { Text(album) }
                        )
                    }
                }
            }

            if (filtered.isEmpty()) {
                EmptyStatePanel(
                    icon = Icons.Rounded.PhotoLibrary,
                    title = "No Photos or Videos Yet",
                    subtitle = "Tap '${strings.pickPhotosVideos}' to import from your device via Android Photo Picker, or scan documents with the Document Scanner."
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(110.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(filtered, key = { _, item -> item.id }) { _, item ->
                        val isVideo = item.mimeType.startsWith("video/")
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    onRecordView(item.uri.toString())
                                    if (isVideo) {
                                        onNavigate(AppRoute.Media(initialTab = 1, initialUri = item.uri.toString()))
                                    } else {
                                        val imgIdx = imageOnlyList.indexOfFirst { it.id == item.id }
                                        if (imgIdx >= 0) viewerStartIndex = imgIdx
                                    }
                                }
                        ) {
                            AsyncImage(
                                model = item.uri,
                                contentDescription = item.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            if (isVideo) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.55f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Rounded.PlayCircleFilled,
                                        contentDescription = "Play video",
                                        tint = PureWhite,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FullScreenPhotoViewer(
    images: List<ManagedFileItem>,
    initialIndex: Int,
    fileRepository: FileRepository,
    onRecordView: (String) -> Unit,
    onDelete: (ManagedFileItem) -> Unit,
    onClose: () -> Unit
) {
    BackHandler { onClose() }
    val context = LocalContext.current
    val pagerState = rememberPagerState(initialPage = initialIndex) { images.size }
    var showDetails by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val currentItem = images.getOrNull(pagerState.currentPage)
    LaunchedEffect(currentItem?.id) {
        currentItem?.let { onRecordView(it.uri.toString()) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val item = images[page]
            var scale by remember { mutableFloatStateOf(1f) }
            var offset by remember { mutableStateOf(Offset.Zero) }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(page) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (scale * zoom).coerceIn(1f, 4f)
                            scale = newScale
                            offset = if (newScale > 1f) offset + pan else Offset.Zero
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = item.uri,
                    contentDescription = item.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        }
                )
            }
        }

        // Top Overlay Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .background(Color.Black.copy(alpha = 0.45f))
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Close", tint = PureWhite)
            }
            Text(
                text = currentItem?.name ?: "",
                color = PureWhite,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
                maxLines = 1
            )
            IconButton(onClick = { showDetails = true }) {
                Icon(Icons.Rounded.Info, contentDescription = "Details", tint = PureWhite)
            }
            IconButton(onClick = {
                currentItem?.let { item ->
                    val shareUri = fileRepository.getShareUri(item)
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = item.mimeType
                        putExtra(Intent.EXTRA_STREAM, shareUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Share Image"))
                }
            }) {
                Icon(Icons.Rounded.Share, contentDescription = "Share", tint = PureWhite)
            }
            IconButton(onClick = { showDeleteConfirm = true }) {
                Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = PureWhite)
            }
        }
    }

    if (showDetails && currentItem != null) {
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(currentItem.lastModified))
        AlertDialog(
            onDismissRequest = { showDetails = false },
            title = { Text("Image Details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Name: ${currentItem.name}")
                    Text("Folder: ${currentItem.locationLabel}")
                    Text("MIME: ${currentItem.mimeType}")
                    if (currentItem.sizeBytes > 0L) Text("Size: ${FileRepository.formatSize(currentItem.sizeBytes)}")
                    Text("Modified: $dateStr")
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetails = false }) { Text("Close") }
            }
        )
    }

    if (showDeleteConfirm && currentItem != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Remove image?") },
            text = { Text("Remove ${currentItem.name} from Gallery?") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    onDelete(currentItem)
                }) { Text("Delete", color = RoseAccent) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}
