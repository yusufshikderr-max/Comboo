package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.calendar.SimpleGregorianDate
import com.example.data.calendar.TrilingualCalendar
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalAppLanguage
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.LightBlueSoft
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyBlueAccent
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TrilingualDateClockCard(
    hijriOffsetDays: Int,
    onOpenCalendar: () -> Unit,
    onOpenClock: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current

    var nowMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val date = remember(nowMillis / 60_000L) { SimpleGregorianDate.today() }
    val trilingual = remember(date, hijriOffsetDays) {
        TrilingualCalendar.getTrilingualDate(date, hijriOffsetDays)
    }

    val timeStr = remember(nowMillis) {
        SimpleDateFormat("hh:mm", Locale.US).format(Date(nowMillis))
    }
    val secondsStr = remember(nowMillis) {
        SimpleDateFormat("ss", Locale.US).format(Date(nowMillis))
    }
    val amPmStr = remember(nowMillis) {
        SimpleDateFormat("a", Locale.US).format(Date(nowMillis))
    }

    Surface(
        shape = RoundedCornerShape(24.dp),
        shadowElevation = 6.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("trilingual_clock_card")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(NavyDeep, NavyPrimary, NavyContainer, Color(0xFF1D4ED8))
                    )
                )
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Digital Clock Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onOpenClock)
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = timeStr,
                            style = MaterialTheme.typography.displaySmall.copy(fontFamily = MonoFontFamily),
                            color = PureWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = ":$secondsStr",
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = MonoFontFamily),
                            color = SkyBlueAccent,
                            modifier = Modifier.padding(bottom = 5.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SkyBlueAccent.copy(alpha = 0.2f),
                            modifier = Modifier.padding(bottom = 5.dp)
                        ) {
                            Text(
                                text = amPmStr,
                                style = MaterialTheme.typography.labelMedium,
                                color = LightBlueSoft,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PureWhite.copy(alpha = 0.14f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(onClick = onOpenCalendar)
                            .testTag("open_calendar_badge")
                    ) {
                        Text(
                            text = if (language == AppLanguage.BN) trilingual.bengali.weekdayBn else trilingual.gregorianWeekdayEn,
                            style = MaterialTheme.typography.labelLarge,
                            color = PureWhite,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                // Three Simultaneous Calendar Dates (Bengali, English, Arabic/Hijri)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onOpenCalendar),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 1. Bengali Date
                    DateSystemPill(
                        badge = strings.bengaliCalTitle,
                        dateMain = "${TrilingualCalendar.toBengaliDigits(trilingual.bengali.day)} ${trilingual.bengali.monthNameBn}",
                        dateSub = "${TrilingualCalendar.toBengaliDigits(trilingual.bengali.year)} বঙ্গাব্দ • ${trilingual.bengali.weekdayBn}",
                        accentColor = Color(0xFF34D399),
                        modifier = Modifier.weight(1f)
                    )

                    // 2. English (Gregorian) Date
                    DateSystemPill(
                        badge = strings.englishCalTitle,
                        dateMain = "${trilingual.gregorian.day} ${trilingual.gregorianMonthEn.take(3)} ${trilingual.gregorian.year}",
                        dateSub = trilingual.gregorianWeekdayEn,
                        accentColor = SkyBlueAccent,
                        modifier = Modifier.weight(1f)
                    )

                    // 3. Arabic / Hijri Date
                    DateSystemPill(
                        badge = strings.hijriCalTitle,
                        dateMain = "${TrilingualCalendar.toArabicDigits(trilingual.hijri.day)} ${trilingual.hijri.monthNameAr}",
                        dateSub = "${TrilingualCalendar.toArabicDigits(trilingual.hijri.year)} هـ • ${trilingual.hijri.weekdayAr}",
                        accentColor = Color(0xFFFBBF24),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun DateSystemPill(
    badge: String,
    dateMain: String,
    dateSub: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = PureWhite.copy(alpha = 0.11f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 9.dp)
        ) {
            Text(
                text = badge.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = dateMain,
                style = MaterialTheme.typography.labelLarge,
                color = PureWhite,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = dateSub,
                style = MaterialTheme.typography.labelSmall,
                color = PureWhite.copy(alpha = 0.80f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
