package com.example.ui.screens.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.NavigateBefore
import androidx.compose.material.icons.automirrored.rounded.NavigateNext
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.data.local.PdfMetaDao
import com.example.data.local.PdfMetaEntity
import com.example.ui.components.ModuleTopBar
import com.example.ui.theme.PureWhite
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

private enum class PdfFitMode { FIT_WIDTH, FIT_SCREEN }

@Composable
fun PdfViewerScreen(
    uriString: String,
    title: String,
    pdfMetaDao: PdfMetaDao,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pfd by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var totalPages by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var needsPassword by remember { mutableStateOf(false) }

    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var fitMode by remember { mutableStateOf(PdfFitMode.FIT_WIDTH) }

    var showGoToDialog by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var searchStatus by remember { mutableStateOf<String?>(null) }

    fun openRenderer(password: String? = null) {
        scope.launch {
            isLoading = true
            errorMsg = null
            needsPassword = false
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val uri = Uri.parse(uriString)
                    val descriptor = if (uri.scheme == "file") {
                        ParcelFileDescriptor.open(File(uri.path!!), ParcelFileDescriptor.MODE_READ_ONLY)
                    } else {
                        context.contentResolver.openFileDescriptor(uri, "r")
                    } ?: throw IllegalStateException("Cannot open PDF file descriptor")

                    val pdfRenderer = openPdfRendererCompat(descriptor, password)
                    val savedMeta = pdfMetaDao.getByUri(uriString)
                    val startPage = (savedMeta?.lastPage ?: 0).coerceIn(0, (pdfRenderer.pageCount - 1).coerceAtLeast(0))
                    Triple(descriptor, pdfRenderer, startPage)
                }
            }
            result.onSuccess { (descriptor, pdfRenderer, startPage) ->
                runCatching { renderer?.close() }
                runCatching { pfd?.close() }
                pfd = descriptor
                renderer = pdfRenderer
                totalPages = pdfRenderer.pageCount
                currentPage = startPage
                isLoading = false
            }.onFailure { err ->
                isLoading = false
                if (err is SecurityException || err.message?.contains("password", true) == true) {
                    needsPassword = true
                } else {
                    errorMsg = err.localizedMessage ?: "Failed to open PDF"
                }
            }
        }
    }

    LaunchedEffect(uriString) {
        openRenderer(null)
    }

    DisposableEffect(uriString) {
        onDispose {
            runCatching { renderer?.close() }
            runCatching { pfd?.close() }
        }
    }

    // Render active page + persist last reading page
    LaunchedEffect(renderer, currentPage) {
        val r = renderer ?: return@LaunchedEffect
        if (currentPage !in 0 until r.pageCount) return@LaunchedEffect
        val bmp = withContext(Dispatchers.IO) {
            r.openPage(currentPage).use { page ->
                val targetW = (page.width * 2).coerceIn(720, 1800)
                val targetH = (page.height.toFloat() / page.width.toFloat() * targetW).toInt().coerceAtLeast(100)
                Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888).apply {
                    eraseColor(android.graphics.Color.WHITE)
                    page.render(this, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                }
            }
        }
        pageBitmap = bmp
        zoomScale = 1f
        panOffset = Offset.Zero

        val existing = pdfMetaDao.getByUri(uriString)
        pdfMetaDao.upsert(
            (existing ?: PdfMetaEntity(uriString, title)).copy(
                displayName = title,
                lastPage = currentPage,
                totalPages = r.pageCount,
                lastOpenedAt = System.currentTimeMillis()
            )
        )
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = title,
                subtitle = if (totalPages > 0) "Page ${currentPage + 1} of $totalPages" else "PDF Reader",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { showSearchDialog = true }) {
                        Icon(Icons.Rounded.Search, contentDescription = "Search text in PDF", tint = PureWhite)
                    }
                    IconButton(onClick = {
                        fitMode = if (fitMode == PdfFitMode.FIT_WIDTH) PdfFitMode.FIT_SCREEN else PdfFitMode.FIT_WIDTH
                        zoomScale = 1f
                        panOffset = Offset.Zero
                    }) {
                        Icon(
                            if (fitMode == PdfFitMode.FIT_WIDTH) Icons.Rounded.FitScreen else Icons.Rounded.Fullscreen,
                            contentDescription = "Toggle Fit Mode",
                            tint = PureWhite
                        )
                    }
                    IconButton(onClick = { showGoToDialog = true }) {
                        Text(
                            text = "${currentPage + 1}/$totalPages",
                            color = PureWhite,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                }
            )
        },
        bottomBar = {
            if (totalPages > 0) {
                Surface(tonalElevation = 4.dp, shadowElevation = 6.dp) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        if (totalPages > 1) {
                            Slider(
                                value = currentPage.toFloat(),
                                onValueChange = { currentPage = it.toInt().coerceIn(0, totalPages - 1) },
                                valueRange = 0f..(totalPages - 1).toFloat(),
                                steps = (totalPages - 2).coerceAtLeast(0)
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row {
                                IconButton(
                                    onClick = { if (currentPage > 0) currentPage-- },
                                    enabled = currentPage > 0,
                                    modifier = Modifier.testTag("pdf_prev_page")
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.NavigateBefore, contentDescription = "Previous Page")
                                }
                                IconButton(
                                    onClick = { if (currentPage < totalPages - 1) currentPage++ },
                                    enabled = currentPage < totalPages - 1,
                                    modifier = Modifier.testTag("pdf_next_page")
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.NavigateNext, contentDescription = "Next Page")
                                }
                            }
                            Text(
                                text = "${(zoomScale * 100).toInt()}% • ${if (fitMode == PdfFitMode.FIT_WIDTH) "Fit Width" else "Fit Screen"}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row {
                                IconButton(onClick = { zoomScale = (zoomScale - 0.3f).coerceAtLeast(1f) }) {
                                    Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom Out")
                                }
                                IconButton(onClick = { zoomScale = (zoomScale + 0.3f).coerceAtMost(4f) }) {
                                    Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom In")
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF1E293B)),
            contentAlignment = Alignment.Center
        ) {
            when {
                isLoading -> CircularProgressIndicator(color = PureWhite)
                needsPassword -> {
                    var passwordInput by remember { mutableStateOf("") }
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.padding(8.dp))
                            Text("Password Protected PDF", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text("Enter PDF Password") },
                                singleLine = true
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { openRenderer(passwordInput) }) {
                                    Text("Unlock")
                                }
                                OutlinedButton(onClick = {
                                    val parsed = Uri.parse(uriString)
                                    val shareUri = if (parsed.scheme == "file" && parsed.path != null) {
                                        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(parsed.path!!))
                                    } else parsed
                                    val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(shareUri, "application/pdf")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    runCatching { context.startActivity(viewIntent) }
                                }) {
                                    Text("System Viewer")
                                }
                            }
                        }
                    }
                }
                errorMsg != null -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                        Text(errorMsg!!, color = PureWhite)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { openRenderer(null) }) { Text("Retry") }
                    }
                }
                pageBitmap != null -> {
                    val bmp = pageBitmap!!
                    val scrollState = rememberScrollState()
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(currentPage) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val newScale = (zoomScale * zoom).coerceIn(1f, 4f)
                                    zoomScale = newScale
                                    panOffset = if (newScale > 1f) panOffset + pan else Offset.Zero
                                }
                            }
                            .let { mod ->
                                if (fitMode == PdfFitMode.FIT_WIDTH && zoomScale == 1f) {
                                    mod.verticalScroll(scrollState)
                                } else mod
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "PDF Page ${currentPage + 1}",
                            contentScale = if (fitMode == PdfFitMode.FIT_WIDTH) ContentScale.FillWidth else ContentScale.Fit,
                            modifier = Modifier
                                .let { if (fitMode == PdfFitMode.FIT_WIDTH) it.fillMaxWidth() else it.fillMaxSize() }
                                .padding(8.dp)
                                .graphicsLayer {
                                    scaleX = zoomScale
                                    scaleY = zoomScale
                                    translationX = panOffset.x
                                    translationY = panOffset.y
                                }
                        )
                    }
                }
            }
        }
    }

    if (showGoToDialog) {
        var pageInput by remember { mutableStateOf((currentPage + 1).toString()) }
        AlertDialog(
            onDismissRequest = { showGoToDialog = false },
            title = { Text("Go to Page (1–$totalPages)") },
            text = {
                OutlinedTextField(
                    value = pageInput,
                    onValueChange = { pageInput = it.filter { c -> c.isDigit() } },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val target = pageInput.toIntOrNull()
                    if (target != null && target in 1..totalPages) {
                        currentPage = target - 1
                    }
                    showGoToDialog = false
                }) { Text("Go") }
            },
            dismissButton = {
                TextButton(onClick = { showGoToDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showSearchDialog) {
        var query by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            title = { Text("Search PDF Text") },
            text = {
                Column {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Keyword") },
                        singleLine = true
                    )
                    if (searchStatus != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(searchStatus!!, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val r = renderer ?: return@TextButton
                    if (query.isBlank()) return@TextButton
                    scope.launch {
                        searchStatus = "Scanning pages..."
                        val foundPage = searchPdfTextWithMlKit(r, query.trim(), currentPage)
                        if (foundPage != null) {
                            currentPage = foundPage
                            showSearchDialog = false
                            searchStatus = null
                            Toast.makeText(context, "Found on page ${foundPage + 1}", Toast.LENGTH_SHORT).show()
                        } else {
                            searchStatus = "No match found for \"$query\""
                        }
                    }
                }) { Text("Find") }
            },
            dismissButton = {
                TextButton(onClick = { showSearchDialog = false; searchStatus = null }) { Text("Close") }
            }
        )
    }
}

private fun openPdfRendererCompat(pfd: ParcelFileDescriptor, password: String?): PdfRenderer {
    if (password != null && Build.VERSION.SDK_INT >= 35) {
        // Use LoadParams reflectively/directly when available on Android 15+ (API 35+)
        val loadParamsClass = Class.forName("android.graphics.pdf.LoadParams")
        val builderClass = Class.forName("android.graphics.pdf.LoadParams\$Builder")
        val builder = builderClass.getDeclaredConstructor().newInstance()
        builderClass.getMethod("setPassword", String::class.java).invoke(builder, password)
        val params = builderClass.getMethod("build").invoke(builder)
        val ctor = PdfRenderer::class.java.getConstructor(ParcelFileDescriptor::class.java, loadParamsClass)
        return ctor.newInstance(pfd, params)
    }
    return PdfRenderer(pfd)
}

private suspend fun searchPdfTextWithMlKit(
    renderer: PdfRenderer,
    query: String,
    startPage: Int
): Int? = withContext(Dispatchers.IO) {
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    val total = renderer.pageCount
    val order = (startPage until total) + (0 until startPage)
    for (idx in order) {
        val bmp = renderer.openPage(idx).use { page ->
            val w = 900
            val h = (page.height.toFloat() / page.width.toFloat() * w).toInt().coerceAtLeast(100)
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
                eraseColor(android.graphics.Color.WHITE)
                page.render(this, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            }
        }
        val text = suspendCancellableCoroutine<String> { cont ->
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { visionText -> cont.resume(visionText.text) }
                .addOnFailureListener { cont.resume("") }
        }
        if (text.contains(query, ignoreCase = true)) {
            return@withContext idx
        }
    }
    null
}
