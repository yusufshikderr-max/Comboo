package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class ThemeMode {
    SYSTEM, LIGHT, DARK
}

private val LightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = PureWhite,
    primaryContainer = LightBlueSoft,
    onPrimaryContainer = NavyDeep,
    secondary = Color(0xFF1D4ED8),
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFDBEAFE),
    onSecondaryContainer = NavyDeep,
    tertiary = SkyBlueAccent,
    onTertiary = NavyDeep,
    tertiaryContainer = Color(0xFFE0F7FA),
    onTertiaryContainer = NavyDeep,
    background = IceBlueSurface,
    onBackground = NavyDeep,
    surface = PureWhite,
    onSurface = NavyDeep,
    surfaceVariant = Color(0xFFE8F0FE),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = RoseAccent,
    onError = PureWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = SkyBlueAccent,
    onPrimary = NavyDeep,
    primaryContainer = NavyContainer,
    onPrimaryContainer = LightBlueSoft,
    secondary = LightBlueBright,
    onSecondary = NavyDeep,
    secondaryContainer = NavyDarkElevated,
    onSecondaryContainer = PureWhite,
    tertiary = CyanAccent,
    onTertiary = NavyDeep,
    background = NavyDeep,
    onBackground = PureWhite,
    surface = NavyDarkSurface,
    onSurface = PureWhite,
    surfaceVariant = NavyDarkCard,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF334155),
    error = Color(0xFFFB7185),
    onError = NavyDeep
)

val SmartShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SmartAllInOneTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    MaterialTheme(
        colorScheme = if (isDark) DarkColorScheme else LightColorScheme,
        typography = SmartTypography,
        shapes = SmartShapes,
        content = content
    )
}
