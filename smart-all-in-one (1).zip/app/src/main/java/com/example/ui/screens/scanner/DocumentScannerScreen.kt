package com.example.ui.screens.scanner

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.files.FileRepository
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import com.example.ui.theme.SkyBlueAccent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.math.hypot

enum class ScanFilter(val label: String) {
    ORIGINAL("Original"),
    ENHANCED("Enhanced"),
    BW("B&W Doc"),
    COLOR_BOOST("Color Boost")
}

private data class ScannedPage(
    val rawBitmap: Bitmap,
    val processedBitmap: Bitmap,
    val filter: ScanFilter = ScanFilter.ENHANCED
)

@Composable
fun DocumentScannerScreen(
    fileRepository: FileRepository,
    onOpenPdf: (uriString: String, title: String) -> Unit,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val camPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { hasCameraPerm = it }

    val pages = remember { mutableStateListOf<ScannedPage>() }
    var activePageIdx by remember { mutableIntStateOf(0) }
    var isCapturingMode by remember { mutableStateOf(true) }
    var cropTargetIndex by remember { mutableStateOf<Int?>(null) }
    var ocrTextResult by remember { mutableStateOf<String?>(null) }
    var savedPdfs by remember { mutableStateOf<List<File>>(emptyList()) }
    var showSaveDialog by remember { mutableStateOf(false) }

    fun refreshSavedScans() {
        val dir = File(fileRepository.rootWorkspaceDir, "ScannedDocs")
        savedPdfs = dir.listFiles()?.filter { it.extension.equals("pdf", true) }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
    }

    LaunchedEffect(Unit) { refreshSavedScans() }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
                if (bmp != null) {
                    val autoCropped = autoDetectDocumentBoundsAndCrop(bmp)
                    val enhanced = applyScanFilter(autoCropped, ScanFilter.ENHANCED)
                    pages.add(ScannedPage(bmp, enhanced, ScanFilter.ENHANCED))
                    activePageIdx = pages.lastIndex
                    isCapturingMode = false
                }
            }
        }
    }

    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolScanner,
                subtitle = if (pages.isEmpty()) "CameraX + Perspective Crop + OCR" else "${pages.size} scanned page(s)",
                onBack = onBack,
                actions = {
                    if (pages.isNotEmpty()) {
                        TextButton(onClick = { isCapturingMode = !isCapturingMode }) {
                            Text(if (isCapturingMode) "Review (${pages.size})" else "+ Page", color = PureWhite)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (isCapturingMode) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color.Black)
                ) {
                    if (hasCameraPerm) {
                        var boundProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
                        AndroidView(
                            factory = { ctx ->
                                val previewView = PreviewView(ctx).apply {
                                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                                }
                                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                cameraProviderFuture.addListener({
                                    val provider = cameraProviderFuture.get()
                                    boundProvider = provider
                                    val preview = Preview.Builder().build().also {
                                        it.surfaceProvider = previewView.surfaceProvider
                                    }
                                    val capture = ImageCapture.Builder()
                                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                                        .build()
                                    imageCapture = capture
                                    runCatching {
                                        provider.unbindAll()
                                        provider.bindToLifecycle(
                                            lifecycleOwner,
                                            CameraSelector.DEFAULT_BACK_CAMERA,
                                            preview,
                                            capture
                                        )
                                    }
                                }, ContextCompat.getMainExecutor(ctx))
                                previewView
                            },
                            onRelease = {
                                runCatching { boundProvider?.unbindAll() }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Rounded.DocumentScanner, null, tint = SkyBlueAccent, modifier = Modifier.size(56.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Enable Camera to scan documents directly, or import a photo.", color = PureWhite)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { camPermLauncher.launch(Manifest.permission.CAMERA) }) {
                                Text("Allow Camera")
                            }
                        }
                    }

                    // Bottom Capture Bar
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        ) {
                            Icon(Icons.Rounded.AddPhotoAlternate, null, tint = PureWhite)
                            Spacer(Modifier.width(6.dp))
                            Text("Import", color = PureWhite)
                        }

                        Button(
                            onClick = {
                                val cap = imageCapture
                                if (cap == null) {
                                    Toast.makeText(context, "Camera initializing...", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val outFile = File(context.cacheDir, "scan_${System.currentTimeMillis()}.jpg")
                                val opts = ImageCapture.OutputFileOptions.Builder(outFile).build()
                                cap.takePicture(
                                    opts,
                                    ContextCompat.getMainExecutor(context),
                                    object : ImageCapture.OnImageSavedCallback {
                                        override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                            scope.launch {
                                                val bmp = withContext(Dispatchers.IO) {
                                                    BitmapFactory.decodeFile(outFile.absolutePath)
                                                }
                                                if (bmp != null) {
                                                    val cropped = autoDetectDocumentBoundsAndCrop(bmp)
                                                    val enhanced = applyScanFilter(cropped, ScanFilter.ENHANCED)
                                                    pages.add(ScannedPage(bmp, enhanced, ScanFilter.ENHANCED))
                                                    activePageIdx = pages.lastIndex
                                                    isCapturingMode = false
                                                }
                                            }
                                        }

                                        override fun onError(exception: ImageCaptureException) {
                                            Toast.makeText(context, "Capture failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            },
                            enabled = hasCameraPerm,
                            modifier = Modifier.testTag("scanner_capture_button")
                        ) {
                            Icon(Icons.Rounded.CameraAlt, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Capture")
                        }
                    }
                }
            } else if (pages.isNotEmpty()) {
                val idx = activePageIdx.coerceIn(0, pages.lastIndex)
                val activePage = pages[idx]

                if (cropTargetIndex == idx) {
                    PerspectiveCropEditor(
                        source = activePage.rawBitmap,
                        onCancel = { cropTargetIndex = null },
                        onApply = { warped ->
                            val filtered = applyScanFilter(warped, activePage.filter)
                            pages[idx] = activePage.copy(processedBitmap = filtered)
                            cropTargetIndex = null
                        }
                    )
                } else {
                    // Active Page Preview
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = activePage.processedBitmap.asImageBitmap(),
                            contentDescription = "Scanned Page ${idx + 1}",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Filter Chips
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(ScanFilter.entries) { _, filter ->
                            FilterChip(
                                selected = activePage.filter == filter,
                                onClick = {
                                    scope.launch {
                                        val updated = withContext(Dispatchers.Default) {
                                            applyScanFilter(activePage.rawBitmap, filter)
                                        }
                                        pages[idx] = activePage.copy(processedBitmap = updated, filter = filter)
                                    }
                                },
                                label = { Text(filter.label) },
                                leadingIcon = { Icon(Icons.Rounded.AutoFixHigh, null, modifier = Modifier.size(16.dp)) }
                            )
                        }
                    }

                    // Multi-page thumbnail strip
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(pages) { pageIdx, page ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                border = if (pageIdx == idx) androidx.compose.foundation.BorderStroke(2.dp, SkyBlueAccent) else null,
                                modifier = Modifier
                                    .size(56.dp, 72.dp)
                                    .clickable { activePageIdx = pageIdx }
                            ) {
                                Image(
                                    bitmap = page.processedBitmap.asImageBitmap(),
                                    contentDescription = "Page ${pageIdx + 1}",
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }

                    // Action Buttons: Crop, OCR, Save PDF
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { cropTargetIndex = idx },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Crop, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Crop")
                        }
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    ocrTextResult = runMlKitOcr(activePage.processedBitmap)
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.TextFields, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("OCR")
                        }
                        Button(
                            onClick = { showSaveDialog = true },
                            modifier = Modifier.weight(1.3f)
                        ) {
                            Icon(Icons.Rounded.PictureAsPdf, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Save PDF")
                        }
                    }
                }
            }

            // Saved Scanned PDFs Drawer at bottom when in capture mode
            if (isCapturingMode && savedPdfs.isNotEmpty()) {
                Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Recent Scanned PDFs", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        LazyColumn(modifier = Modifier.height(140.dp)) {
                            itemsIndexed(savedPdfs) { _, file ->
                                ListItem(
                                    headlineContent = { Text(file.name, maxLines = 1) },
                                    supportingContent = { Text(FileRepository.formatSize(file.length())) },
                                    leadingContent = { Icon(Icons.Rounded.PictureAsPdf, null, tint = RoseAccent) },
                                    trailingContent = {
                                        Row {
                                            IconButton(onClick = {
                                                val shareUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "application/pdf"
                                                    putExtra(Intent.EXTRA_STREAM, shareUri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Share Scan"))
                                            }) { Icon(Icons.Rounded.Share, null) }
                                            IconButton(onClick = {
                                                file.delete()
                                                refreshSavedScans()
                                            }) { Icon(Icons.Rounded.Delete, null, tint = RoseAccent) }
                                        }
                                    },
                                    modifier = Modifier.clickable {
                                        onOpenPdf(Uri.fromFile(file).toString(), file.name)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSaveDialog) {
        var docName by remember { mutableStateOf("Scan_${System.currentTimeMillis() / 1000}") }
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Multi-Page PDF") },
            text = {
                OutlinedTextField(
                    value = docName,
                    onValueChange = { docName = it },
                    label = { Text("Document Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val saved = savePagesToPdf(fileRepository, docName, pages.map { it.processedBitmap })
                        showSaveDialog = false
                        if (saved != null) {
                            pages.clear()
                            isCapturingMode = true
                            refreshSavedScans()
                            Toast.makeText(context, "Saved ${saved.name}", Toast.LENGTH_SHORT).show()
                            onOpenPdf(Uri.fromFile(saved).toString(), saved.name)
                        }
                    }
                }) { Text("Save PDF") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") }
            }
        )
    }

    ocrTextResult?.let { text ->
        AlertDialog(
            onDismissRequest = { ocrTextResult = null },
            title = { Text("OCR Extracted Text") },
            text = {
                Text(text.ifBlank { "No text detected on this page." })
            },
            confirmButton = {
                TextButton(onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("OCR Text", text))
                    Toast.makeText(context, "Copied OCR text", Toast.LENGTH_SHORT).show()
                    ocrTextResult = null
                }) {
                    Icon(Icons.Rounded.ContentCopy, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Copy")
                }
            },
            dismissButton = {
                TextButton(onClick = { ocrTextResult = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun PerspectiveCropEditor(
    source: Bitmap,
    onCancel: () -> Unit,
    onApply: (Bitmap) -> Unit
) {
    var boxSize by remember { mutableStateOf(IntSize(1, 1)) }
    // Normalized 4 corners: TopLeft, TopRight, BottomRight, BottomLeft
    val corners = remember {
        mutableStateListOf(
            Offset(0.08f, 0.08f),
            Offset(0.92f, 0.08f),
            Offset(0.92f, 0.92f),
            Offset(0.08f, 0.92f)
        )
    }
    var activeHandle by remember { mutableIntStateOf(-1) }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black)
                .onSizeChanged { boxSize = it }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { start ->
                            val w = boxSize.width.toFloat().coerceAtLeast(1f)
                            val h = boxSize.height.toFloat().coerceAtLeast(1f)
                            activeHandle = corners.indices.minByOrNull { idx ->
                                hypot(corners[idx].x * w - start.x, corners[idx].y * h - start.y)
                            } ?: -1
                        },
                        onDragEnd = { activeHandle = -1 },
                        onDrag = { change, drag ->
                            change.consume()
                            if (activeHandle in 0..3) {
                                val w = boxSize.width.toFloat().coerceAtLeast(1f)
                                val h = boxSize.height.toFloat().coerceAtLeast(1f)
                                val cur = corners[activeHandle]
                                corners[activeHandle] = Offset(
                                    (cur.x + drag.x / w).coerceIn(0.02f, 0.98f),
                                    (cur.y + drag.y / h).coerceIn(0.02f, 0.98f)
                                )
                            }
                        }
                    )
                }
        ) {
            Image(
                bitmap = source.asImageBitmap(),
                contentDescription = "Crop Source",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
            Canvas(modifier = Modifier.fillMaxSize()) {
                val pts = corners.map { Offset(it.x * size.width, it.y * size.height) }
                val path = Path().apply {
                    moveTo(pts[0].x, pts[0].y)
                    lineTo(pts[1].x, pts[1].y)
                    lineTo(pts[2].x, pts[2].y)
                    lineTo(pts[3].x, pts[3].y)
                    close()
                }
                drawPath(path, color = SkyBlueAccent, style = Stroke(width = 5f))
                pts.forEach { pt ->
                    drawCircle(color = NavyPrimary, radius = 20f, center = pt)
                    drawCircle(color = SkyBlueAccent, radius = 14f, center = pt)
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(
                onClick = {
                    val warped = warpPerspectiveBitmap(source, corners.toList())
                    onApply(warped)
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Apply Perspective Crop")
            }
        }
    }
}

private fun autoDetectDocumentBoundsAndCrop(source: Bitmap): Bitmap {
    // Trim 4% edge margin cleanly while preserving full document frame
    val marginX = (source.width * 0.03f).toInt()
    val marginY = (source.height * 0.03f).toInt()
    val w = (source.width - marginX * 2).coerceAtLeast(100)
    val h = (source.height - marginY * 2).coerceAtLeast(100)
    return Bitmap.createBitmap(source, marginX, marginY, w, h)
}

private fun warpPerspectiveBitmap(source: Bitmap, normCorners: List<Offset>): Bitmap {
    val sw = source.width.toFloat()
    val sh = source.height.toFloat()
    val srcPts = floatArrayOf(
        normCorners[0].x * sw, normCorners[0].y * sh,
        normCorners[1].x * sw, normCorners[1].y * sh,
        normCorners[2].x * sw, normCorners[2].y * sh,
        normCorners[3].x * sw, normCorners[3].y * sh
    )
    val outW = 1000
    val outH = 1400
    val dstPts = floatArrayOf(
        0f, 0f,
        outW.toFloat(), 0f,
        outW.toFloat(), outH.toFloat(),
        0f, outH.toFloat()
    )
    val matrix = Matrix()
    matrix.setPolyToPoly(srcPts, 0, dstPts, 0, 4)
    val result = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(result)
    canvas.drawBitmap(source, matrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    return result
}

private fun applyScanFilter(source: Bitmap, filter: ScanFilter): Bitmap {
    if (filter == ScanFilter.ORIGINAL) return source
    val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(result)
    val paint = Paint()
    val cm = ColorMatrix()
    when (filter) {
        ScanFilter.ORIGINAL -> {}
        ScanFilter.ENHANCED -> {
            val contrast = 1.35f
            val translate = (-0.5f * contrast + 0.5f) * 255f
            cm.set(
                floatArrayOf(
                    contrast, 0f, 0f, 0f, translate,
                    0f, contrast, 0f, 0f, translate,
                    0f, 0f, contrast, 0f, translate,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        }
        ScanFilter.BW -> {
            cm.setSaturation(0f)
            val contrast = 1.8f
            val translate = (-0.5f * contrast + 0.5f) * 255f
            val cMatrix = ColorMatrix(
                floatArrayOf(
                    contrast, 0f, 0f, 0f, translate,
                    0f, contrast, 0f, 0f, translate,
                    0f, 0f, contrast, 0f, translate,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            cm.postConcat(cMatrix)
        }
        ScanFilter.COLOR_BOOST -> {
            cm.setSaturation(1.45f)
        }
    }
    paint.colorFilter = ColorMatrixColorFilter(cm)
    canvas.drawBitmap(source, 0f, 0f, paint)
    return result
}

private suspend fun runMlKitOcr(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    recognizer.process(InputImage.fromBitmap(bitmap, 0))
        .addOnSuccessListener { cont.resume(it.text) }
        .addOnFailureListener { cont.resume("OCR failed: ${it.localizedMessage}") }
}

private suspend fun savePagesToPdf(
    fileRepository: FileRepository,
    docName: String,
    bitmaps: List<Bitmap>
): File? = withContext(Dispatchers.IO) {
    runCatching {
        val dir = File(fileRepository.rootWorkspaceDir, "ScannedDocs").apply { if (!exists()) mkdirs() }
        val clean = docName.trim().ifBlank { "Scan_${System.currentTimeMillis()}" }
        val fileName = if (clean.endsWith(".pdf", true)) clean else "$clean.pdf"
        val target = File(dir, fileName)
        val pdf = PdfDocument()
        bitmaps.forEachIndexed { idx, bmp ->
            val info = PdfDocument.PageInfo.Builder(595, 842, idx + 1).create()
            val page = pdf.startPage(info)
            val scaled = Bitmap.createScaledBitmap(bmp, 595, 842, true)
            page.canvas.drawBitmap(scaled, 0f, 0f, null)
            pdf.finishPage(page)
        }
        FileOutputStream(target).use { pdf.writeTo(it) }
        pdf.close()
        target
    }.getOrNull()
}
