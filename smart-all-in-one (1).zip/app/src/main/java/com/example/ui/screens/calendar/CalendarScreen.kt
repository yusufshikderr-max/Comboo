package com.example.ui.screens.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.NavigateBefore
import androidx.compose.material.icons.automirrored.rounded.NavigateNext
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.CalendarViewMonth
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.calendar.ReminderScheduler
import com.example.data.calendar.SimpleGregorianDate
import com.example.data.calendar.TrilingualCalendar
import com.example.data.local.CalendarEventDao
import com.example.data.local.CalendarEventEntity
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalAppLanguage
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import com.example.ui.theme.SkyBlueAccent
import kotlinx.coroutines.launch

@Composable
fun CalendarScreen(
    hijriOffsetDays: Int,
    eventDao: CalendarEventDao,
    allEvents: List<CalendarEventEntity>,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val today = remember { SimpleGregorianDate.today() }
    var viewYear by remember { mutableIntStateOf(today.year) }
    var viewMonth by remember { mutableIntStateOf(today.month) }
    var selectedDate by remember { mutableStateOf(today) }
    var yearlyView by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var showCreateEvent by remember { mutableStateOf(false) }

    val selectedInfo = remember(selectedDate, hijriOffsetDays) {
        TrilingualCalendar.getTrilingualDate(selectedDate, hijriOffsetDays)
    }

    val eventsByDay = remember(allEvents) { allEvents.groupBy { it.epochDay } }
    val selectedDayEvents = eventsByDay[selectedDate.epochDay].orEmpty()

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateEvent = true },
                modifier = Modifier.testTag("calendar_add_event_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Add Event")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Header
            Surface(color = NavyPrimary, contentColor = PureWhite) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${TrilingualCalendar.gregorianMonthName(viewMonth, language == AppLanguage.BN)} $viewYear",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                        Row {
                            IconButton(onClick = {
                                if (viewMonth == 1) { viewMonth = 12; viewYear-- } else viewMonth--
                            }) {
                                Icon(Icons.AutoMirrored.Rounded.NavigateBefore, "Previous Month", tint = PureWhite)
                            }
                            IconButton(onClick = {
                                if (viewMonth == 12) { viewMonth = 1; viewYear++ } else viewMonth++
                            }) {
                                Icon(Icons.AutoMirrored.Rounded.NavigateNext, "Next Month", tint = PureWhite)
                            }
                            IconButton(onClick = { yearlyView = !yearlyView }) {
                                Icon(Icons.Rounded.CalendarViewMonth, "Toggle Yearly View", tint = SkyBlueAccent)
                            }
                            IconButton(onClick = { showSearch = !showSearch }) {
                                Icon(Icons.Rounded.Search, "Search Events", tint = PureWhite)
                            }
                        }
                    }

                    // Trilingual Selected Date Summary
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = PureWhite.copy(alpha = 0.12f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "${selectedInfo.gregorian.day} ${selectedInfo.gregorianMonthEn} ${selectedInfo.gregorian.year} • ${selectedInfo.gregorianWeekdayEn}",
                                style = MaterialTheme.typography.titleSmall,
                                color = PureWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "বাংলা: ${TrilingualCalendar.toBengaliDigits(selectedInfo.bengali.day)} ${selectedInfo.bengali.monthNameBn} ${TrilingualCalendar.toBengaliDigits(selectedInfo.bengali.year)} (${selectedInfo.bengali.weekdayBn})",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF6EE7B7)
                            )
                            Text(
                                text = "Hijri: ${TrilingualCalendar.toArabicDigits(selectedInfo.hijri.day)} ${selectedInfo.hijri.monthNameAr} (${selectedInfo.hijri.monthNameEn}) ${selectedInfo.hijri.year} AH • ${selectedInfo.hijri.weekdayAr}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFFDE68A)
                            )
                        }
                    }
                }
            }

            if (showSearch) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search events or reminders...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            if (yearlyView) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(12) { mIdx ->
                        val monthNum = mIdx + 1
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (monthNum == viewMonth) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            tonalElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewMonth = monthNum
                                    yearlyView = false
                                }
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = TrilingualCalendar.gregorianMonthName(monthNum, language == AppLanguage.BN),
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "$viewYear",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            } else {
                // Monthly Grid
                val firstDay = SimpleGregorianDate.of(viewYear, viewMonth, 1)
                val leadingEmpty = (firstDay.dayOfWeek - 1).coerceIn(0, 6)
                val totalDays = TrilingualCalendar.daysInGregorianMonth(viewYear, viewMonth)
                val weekdayLabels = TrilingualCalendar.weekdayShortLabels(language == AppLanguage.BN)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    weekdayLabels.forEach { lbl ->
                        Text(
                            text = lbl,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                val totalCells = leadingEmpty + totalDays
                val rows = (totalCells + 6) / 7
                Column(modifier = Modifier.padding(horizontal = 8.dp)) {
                    for (r in 0 until rows) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (c in 0..6) {
                                val cellIdx = r * 7 + c
                                val dayNum = cellIdx - leadingEmpty + 1
                                if (dayNum in 1..totalDays) {
                                    val cellDate = SimpleGregorianDate.of(viewYear, viewMonth, dayNum)
                                    val bn = remember(cellDate) { TrilingualCalendar.toBengaliDate(cellDate) }
                                    val hj = remember(cellDate, hijriOffsetDays) { TrilingualCalendar.toHijriDate(cellDate, hijriOffsetDays) }
                                    val isToday = cellDate.epochDay == today.epochDay
                                    val isSelected = cellDate.epochDay == selectedDate.epochDay
                                    val dayEvents = eventsByDay[cellDate.epochDay].orEmpty()

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = when {
                                            isSelected -> NavyPrimary
                                            isToday -> SkyBlueAccent.copy(alpha = 0.25f)
                                            else -> Color.Transparent
                                        },
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(2.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { selectedDate = cellDate }
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(vertical = 4.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = dayNum.toString(),
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) PureWhite else MaterialTheme.colorScheme.onBackground
                                            )
                                            Text(
                                                text = "${TrilingualCalendar.toBengaliDigits(bn.day)}/${TrilingualCalendar.toArabicDigits(hj.day)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isSelected) SkyBlueAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (dayEvents.isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            if (dayEvents.any { it.isImportant }) RoseAccent else EmeraldAccent
                                                        )
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                // Events List for Selected Date (or Search Results)
                val listToShow = if (searchQuery.isNotBlank()) {
                    allEvents.filter {
                        it.title.contains(searchQuery, true) || it.description.contains(searchQuery, true)
                    }
                } else selectedDayEvents

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            text = if (searchQuery.isNotBlank()) "Search Results (${listToShow.size})"
                            else "Events on ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (listToShow.isEmpty()) {
                        item {
                            Text(
                                text = "No events scheduled. Tap + to create an event or reminder.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(listToShow, key = { it.id }) { ev ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                tonalElevation = 2.dp
                            ) {
                                ListItem(
                                    headlineContent = { Text(ev.title, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = {
                                        Text("${"%02d:%02d".format(ev.hour, ev.minute)}${if (ev.description.isNotBlank()) " • ${ev.description}" else ""}")
                                    },
                                    leadingContent = {
                                        Icon(
                                            if (ev.isImportant) Icons.Rounded.Star else Icons.Rounded.Alarm,
                                            contentDescription = null,
                                            tint = if (ev.isImportant) AmberAccent else MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    trailingContent = {
                                        IconButton(onClick = { scope.launch { eventDao.delete(ev) } }) {
                                            Icon(Icons.Rounded.Delete, contentDescription = "Delete Event", tint = RoseAccent)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateEvent) {
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var hourInput by remember { mutableStateOf("09") }
        var minInput by remember { mutableStateOf("00") }
        var isImportant by remember { mutableStateOf(false) }
        var hasReminder by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showCreateEvent = false },
            title = { Text("Add Calendar Event") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Event Title") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Notes / Details") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = hourInput,
                            onValueChange = { hourInput = it.filter { c -> c.isDigit() }.take(2) },
                            label = { Text("Hour (0-23)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = minInput,
                            onValueChange = { minInput = it.filter { c -> c.isDigit() }.take(2) },
                            label = { Text("Min (0-59)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isImportant, onCheckedChange = { isImportant = it })
                        Text("Mark as Important Date")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Schedule Alarm Reminder")
                        Switch(checked = hasReminder, onCheckedChange = { hasReminder = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isBlank()) return@TextButton
                    val h = (hourInput.toIntOrNull() ?: 9).coerceIn(0, 23)
                    val m = (minInput.toIntOrNull() ?: 0).coerceIn(0, 59)
                    scope.launch {
                        val id = eventDao.upsert(
                            CalendarEventEntity(
                                title = title.trim(),
                                description = desc.trim(),
                                epochDay = selectedDate.epochDay,
                                hour = h,
                                minute = m,
                                isImportant = isImportant,
                                hasReminder = hasReminder
                            )
                        )
                        if (hasReminder) {
                            ReminderScheduler.scheduleEventReminder(
                                context, id, title.trim(), desc.trim(), selectedDate.epochDay, h, m
                            )
                        }
                        showCreateEvent = false
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateEvent = false }) { Text(strings.cancel) }
            }
        )
    }
}
