package com.example.ui.screens.utilities

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object FlashlightController {
    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    fun toggle(context: Context) {
        val next = !_isTorchOn.value
        setTorch(context, next)
    }

    fun setTorch(context: Context, enabled: Boolean) {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return
        runCatching {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, enabled)
                _isTorchOn.value = enabled
            } else {
                Toast.makeText(context, "Flashlight hardware unavailable", Toast.LENGTH_SHORT).show()
            }
        }.onFailure {
            Toast.makeText(context, "Unable to toggle flashlight: ${it.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
