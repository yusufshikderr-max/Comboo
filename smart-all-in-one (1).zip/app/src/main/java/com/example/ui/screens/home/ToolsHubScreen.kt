package com.example.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ToolAppCard
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.navigation.AppRoute
import com.example.ui.navigation.ToolCatalog
import com.example.ui.screens.utilities.FlashlightController
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite

@Composable
fun ToolsHubScreen(
    onNavigate: (AppRoute) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val isTorchOn by FlashlightController.isTorchOn.collectAsStateWithLifecycle()
    var filterQuery by remember { mutableStateOf("") }

    val filtered = remember(filterQuery, strings) {
        if (filterQuery.isBlank()) ToolCatalog.allTools
        else ToolCatalog.allTools.filter {
            it.title(strings).contains(filterQuery, ignoreCase = true)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Surface(color = NavyPrimary, contentColor = PureWhite) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Text(
                    text = strings.navTools,
                    style = MaterialTheme.typography.headlineMedium,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = filterQuery,
                    onValueChange = { filterQuery = it },
                    placeholder = { Text(strings.searchPlaceholder) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = PureWhite,
                        focusedTextColor = NavyPrimary,
                        unfocusedTextColor = NavyPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tools_hub_search")
                )
            }
        }

        val rows = filtered.chunked(3)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(rows.size) { index ->
                val rowTools = rows[index]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowTools.forEach { tool ->
                        ToolAppCard(
                            tool = tool,
                            isActive = tool.id == "flashlight" && isTorchOn,
                            onClick = {
                                if (tool.route != null) onNavigate(tool.route)
                                else if (tool.id == "flashlight") FlashlightController.toggle(context)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    repeat(3 - rowTools.size) {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
