package com.example.ui.screens.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.calendar.SimpleGregorianDate
import com.example.data.local.AppSettings
import com.example.data.local.CalendarEventEntity
import com.example.data.local.TodoEntity
import com.example.ui.components.MainDashboardHeader
import com.example.ui.components.ToolAppCard
import com.example.ui.components.TrilingualDateClockCard
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.navigation.AppRoute
import com.example.ui.navigation.ToolCatalog
import com.example.ui.navigation.ToolCategory
import com.example.ui.navigation.ToolDescriptor
import com.example.ui.screens.utilities.FlashlightController
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyBlueAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    settings: AppSettings,
    upcomingEvents: List<CalendarEventEntity>,
    pendingTodos: List<TodoEntity>,
    onNavigate: (AppRoute) -> Unit,
    onToggleShortcut: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val isTorchOn by FlashlightController.isTorchOn.collectAsStateWithLifecycle()

    var showSearchSheet by remember { mutableStateOf(false) }
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showCustomizeShortcuts by remember { mutableStateOf(false) }

    val handleToolClick: (ToolDescriptor) -> Unit = { tool ->
        if (tool.route != null) {
            onNavigate(tool.route)
        } else if (tool.id == "flashlight") {
            FlashlightController.toggle(context)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        MainDashboardHeader(
            onSearchClick = { showSearchSheet = true },
            onNotificationsClick = { showNotificationsSheet = true },
            onSettingsClick = { onNavigate(AppRoute.Settings) },
            onChatGptClick = { onNavigate(AppRoute.AiAssistant) }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Trilingual Calendar + Digital Clock Hero Card
            item {
                TrilingualDateClockCard(
                    hijriOffsetDays = settings.hijriOffsetDays,
                    onOpenCalendar = { onNavigate(AppRoute.Calendar) },
                    onOpenClock = { onNavigate(AppRoute.ClockTools(0)) }
                )
            }

            // Customizable Quick Shortcuts Strip
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.pinnedShortcuts,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(
                            onClick = { showCustomizeShortcuts = true },
                            modifier = Modifier.testTag("customize_shortcuts_button")
                        ) {
                            Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.customize)
                        }
                    }

                    val pinned = settings.pinnedShortcuts.mapNotNull { ToolCatalog.byId(it) }
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(pinned, key = { "pin_${it.id}" }) { tool ->
                            Box(modifier = Modifier.width(98.dp)) {
                                ToolAppCard(
                                    tool = tool,
                                    isActive = tool.id == "flashlight" && isTorchOn,
                                    onClick = { handleToolClick(tool) }
                                )
                            }
                        }
                    }
                }
            }

            // Organized Categories (Section 17)
            val categories = listOf(
                ToolCategory.ESSENTIAL to strings.catEssential,
                ToolCategory.PRODUCTIVITY to strings.catProductivity,
                ToolCategory.ENTERTAINMENT to strings.catEntertainment,
                ToolCategory.NAV_SEARCH to strings.catNavSearch,
                ToolCategory.AI_ASSISTANT to strings.catAiAssistant,
                ToolCategory.EXTRA_UTILITIES to strings.catExtraUtilities
            )

            categories.forEach { (category, label) ->
                val tools = ToolCatalog.allTools.filter { it.category == category }
                item(key = category.name) {
                    CategoryGridSection(
                        title = label,
                        tools = tools,
                        isTorchOn = isTorchOn,
                        onToolClick = handleToolClick
                    )
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    // Global Search Bottom Sheet
    if (showSearchSheet) {
        var query by remember { mutableStateOf("") }
        val filtered = remember(query, strings) {
            if (query.isBlank()) ToolCatalog.allTools
            else ToolCatalog.allTools.filter {
                it.title(strings).contains(query, ignoreCase = true) ||
                    it.id.contains(query, ignoreCase = true)
            }
        }
        ModalBottomSheet(onDismissRequest = { showSearchSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(strings.searchPlaceholder) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("global_search_input")
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(modifier = Modifier.height(340.dp)) {
                    items(filtered, key = { it.id }) { tool ->
                        ListItem(
                            headlineContent = { Text(tool.title(strings), fontWeight = FontWeight.SemiBold) },
                            leadingContent = {
                                Icon(tool.icon, contentDescription = null, tint = tool.accentColor)
                            },
                            modifier = Modifier.clickable {
                                showSearchSheet = false
                                handleToolClick(tool)
                            }
                        )
                    }
                }
            }
        }
    }

    // Notifications & Reminders Bottom Sheet
    if (showNotificationsSheet) {
        ModalBottomSheet(onDismissRequest = { showNotificationsSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = NavyPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.notificationsTitle, style = MaterialTheme.typography.titleLarge)
                }
                Spacer(Modifier.height(12.dp))
                if (upcomingEvents.isEmpty() && pendingTodos.isEmpty()) {
                    Text(
                        text = "No active reminders or pending tasks right now.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    upcomingEvents.take(5).forEach { ev ->
                        val d = SimpleGregorianDate.fromEpochDay(ev.epochDay)
                        ListItem(
                            headlineContent = { Text(ev.title, fontWeight = FontWeight.SemiBold) },
                            supportingContent = {
                                Text("${d.day}/${d.month}/${d.year} • ${"%02d:%02d".format(ev.hour, ev.minute)}")
                            },
                            leadingContent = {
                                Icon(Icons.Rounded.EventAvailable, contentDescription = null, tint = SkyBlueAccent)
                            },
                            modifier = Modifier.clickable {
                                showNotificationsSheet = false
                                onNavigate(AppRoute.Calendar)
                            }
                        )
                        HorizontalDivider()
                    }
                    pendingTodos.take(5).forEach { todo ->
                        ListItem(
                            headlineContent = { Text(todo.title) },
                            supportingContent = { Text("Task • ${todo.category}") },
                            modifier = Modifier.clickable {
                                showNotificationsSheet = false
                                onNavigate(AppRoute.Todo)
                            }
                        )
                    }
                }
            }
        }
    }

    // Customize Shortcuts Dialog
    if (showCustomizeShortcuts) {
        AlertDialog(
            onDismissRequest = { showCustomizeShortcuts = false },
            title = { Text(strings.dashboardShortcuts) },
            text = {
                LazyColumn(modifier = Modifier.height(340.dp)) {
                    items(ToolCatalog.allTools, key = { it.id }) { tool ->
                        val checked = settings.pinnedShortcuts.contains(tool.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleShortcut(tool.id) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(tool.icon, contentDescription = null, tint = tool.accentColor)
                            Spacer(Modifier.width(12.dp))
                            Text(tool.title(strings), modifier = Modifier.weight(1f))
                            androidx.compose.material3.Checkbox(
                                checked = checked,
                                onCheckedChange = { onToggleShortcut(tool.id) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCustomizeShortcuts = false }) {
                    Text(strings.save)
                }
            }
        )
    }
}

@Composable
private fun CategoryGridSection(
    title: String,
    tools: List<ToolDescriptor>,
    isTorchOn: Boolean,
    onToolClick: (ToolDescriptor) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .width(4.dp)
                    .height(18.dp)
            ) {}
            Spacer(Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        if (tools.size == 1 && tools.first().id == "chatgpt") {
            val aiTool = tools.first()
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NavyPrimary,
                contentColor = PureWhite,
                shadowElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToolClick(aiTool) }
                    .testTag("tool_card_chatgpt_banner")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = SkyBlueAccent,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                text = aiTool.title(LocalAppStrings.current),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PureWhite
                            )
                            Text(
                                text = "Bengali & English Q&A, Translation, Summary & Writing",
                                style = MaterialTheme.typography.bodyMedium,
                                color = PureWhite.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        } else {
            val rows = tools.chunked(3)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                rows.forEach { rowTools ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowTools.forEach { tool ->
                            ToolAppCard(
                                tool = tool,
                                isActive = tool.id == "flashlight" && isTorchOn,
                                onClick = { onToolClick(tool) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(3 - rowTools.size) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
