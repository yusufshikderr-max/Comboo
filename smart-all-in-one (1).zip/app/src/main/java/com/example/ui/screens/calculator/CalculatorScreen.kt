package com.example.ui.screens.calculator

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CalcHistoryDao
import com.example.data.local.CalcHistoryEntity
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import com.example.ui.theme.SkyBlueAccent
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    historyDao: CalcHistoryDao,
    history: List<CalcHistoryEntity>,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val scope = rememberCoroutineScope()

    var expression by remember { mutableStateOf("") }
    var displayResult by remember { mutableStateOf("0") }
    var memoryValue by remember { mutableDoubleStateOf(0.0) }
    var scientificMode by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }

    fun evaluateAndFormat(expr: String): String {
        return runCatching {
            val v = evaluateMathExpression(expr)
            if (v.isNaN() || v.isInfinite()) "Error"
            else if (v == v.toLong().toDouble()) v.toLong().toString()
            else "%.8f".format(v).trimEnd('0').trimEnd('.')
        }.getOrElse { "Error" }
    }

    fun onEqual() {
        if (expression.isBlank()) return
        val res = evaluateAndFormat(expression)
        displayResult = res
        if (res != "Error") {
            scope.launch {
                historyDao.insert(CalcHistoryEntity(expression = expression, result = res))
            }
        }
    }

    fun appendToken(tok: String) {
        expression += tok
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolCalculator,
                subtitle = if (scientificMode) "Scientific Mode" else "Standard Mode",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { scientificMode = !scientificMode }) {
                        Icon(Icons.Rounded.Science, contentDescription = "Toggle Scientific", tint = PureWhite)
                    }
                    IconButton(onClick = { showHistory = true }) {
                        Icon(Icons.Rounded.History, contentDescription = "History", tint = PureWhite)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Display Panel
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = NavyPrimary,
                contentColor = PureWhite,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.End
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (memoryValue != 0.0) "M = $memoryValue" else "",
                            color = SkyBlueAccent,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Text(
                            text = if (scientificMode) "SCI (DEG)" else "BASIC",
                            color = PureWhite.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = expression.ifEmpty { "0" },
                            fontFamily = MonoFontFamily,
                            fontSize = 22.sp,
                            color = PureWhite.copy(alpha = 0.85f),
                            textAlign = TextAlign.End,
                            maxLines = 2
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = displayResult,
                            fontFamily = MonoFontFamily,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite,
                            textAlign = TextAlign.End,
                            maxLines = 1,
                            modifier = Modifier.testTag("calc_result_text")
                        )
                    }
                }
            }

            // Memory Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("MC", "MR", "M+", "M-").forEach { memKey ->
                    CalcKeyButton(
                        label = memKey,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            val currentVal = displayResult.toDoubleOrNull() ?: 0.0
                            when (memKey) {
                                "MC" -> memoryValue = 0.0
                                "MR" -> expression += if (memoryValue == memoryValue.toLong().toDouble()) memoryValue.toLong().toString() else memoryValue.toString()
                                "M+" -> memoryValue += currentVal
                                "M-" -> memoryValue -= currentVal
                            }
                        }
                    )
                }
            }

            // Scientific Pad
            if (scientificMode) {
                val sciRows = listOf(
                    listOf("sin(", "cos(", "tan(", "√(", "^"),
                    listOf("log(", "ln(", "(", ")", "π")
                )
                sciRows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row.forEach { key ->
                            CalcKeyButton(
                                label = key.removeSuffix("("),
                                containerColor = NavyContainer,
                                contentColor = PureWhite,
                                modifier = Modifier.weight(1f).height(46.dp),
                                onClick = { appendToken(key) }
                            )
                        }
                    }
                }
            }

            // Standard Pad
            val padRows = listOf(
                listOf("AC", "⌫", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "-"),
                listOf("1", "2", "3", "+"),
                listOf("0", ".", "√", "=")
            )

            padRows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { key ->
                        val isOp = key in listOf("÷", "×", "-", "+", "=")
                        val isClear = key in listOf("AC", "⌫")
                        val bg = when {
                            key == "=" -> SkyBlueAccent
                            isOp -> NavyPrimary
                            isClear -> RoseAccent.copy(alpha = 0.16f)
                            else -> MaterialTheme.colorScheme.surface
                        }
                        val fg = when {
                            key == "=" -> NavyPrimary
                            isOp -> PureWhite
                            isClear -> RoseAccent
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                        CalcKeyButton(
                            label = key,
                            containerColor = bg,
                            contentColor = fg,
                            modifier = Modifier
                                .weight(1f)
                                .height(58.dp)
                                .testTag("calc_key_$key"),
                            onClick = {
                                when (key) {
                                    "AC" -> {
                                        expression = ""
                                        displayResult = "0"
                                    }
                                    "⌫" -> {
                                        if (expression.isNotEmpty()) expression = expression.dropLast(1)
                                    }
                                    "=" -> onEqual()
                                    "√" -> appendToken("√(")
                                    else -> appendToken(key)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showHistory) {
        ModalBottomSheet(onDismissRequest = { showHistory = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Calculation History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { scope.launch { historyDao.clearAll() } }) {
                        Icon(Icons.Rounded.DeleteSweep, null)
                        Text("Clear")
                    }
                }
                LazyColumn(modifier = Modifier.height(320.dp)) {
                    items(history, key = { it.id }) { item ->
                        ListItem(
                            headlineContent = { Text(item.result, fontWeight = FontWeight.Bold, fontFamily = MonoFontFamily) },
                            supportingContent = { Text(item.expression, fontFamily = MonoFontFamily) },
                            modifier = Modifier.clickable {
                                expression = item.result
                                displayResult = item.result
                                showHistory = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalcKeyButton(
    label: String,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = containerColor,
        contentColor = contentColor,
        tonalElevation = 2.dp,
        shadowElevation = 1.dp,
        modifier = modifier
    ) {
        androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = MonoFontFamily
            )
        }
    }
}

private fun evaluateMathExpression(raw: String): Double {
    val sanitized = raw
        .replace("×", "*")
        .replace("÷", "/")
        .replace("π", PI.toString())
        .replace("√(", "sqrt(")
        .replace("%", "/100.0")
        .replace(" ", "")

    return object {
        var pos = -1
        var ch = 0

        fun nextChar() {
            ch = if (++pos < sanitized.length) sanitized[pos].code else -1
        }

        fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < sanitized.length) throw IllegalArgumentException("Unexpected: ${ch.toChar()}")
            return x
        }

        fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                x = when {
                    eat('+'.code) -> x + parseTerm()
                    eat('-'.code) -> x - parseTerm()
                    else -> return x
                }
            }
        }

        fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                x = when {
                    eat('*'.code) -> x * parseFactor()
                    eat('/'.code) -> x / parseFactor()
                    else -> return x
                }
            }
        }

        fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()
            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                eat(')'.code)
            } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                x = sanitized.substring(startPos, pos).toDouble()
            } else if (ch in 'a'.code..'z'.code) {
                while (ch in 'a'.code..'z'.code) nextChar()
                val func = sanitized.substring(startPos, pos)
                x = parseFactor()
                x = when (func) {
                    "sqrt" -> sqrt(x)
                    "sin" -> sin(Math.toRadians(x))
                    "cos" -> cos(Math.toRadians(x))
                    "tan" -> tan(Math.toRadians(x))
                    "log" -> log10(x)
                    "ln" -> ln(x)
                    "exp" -> exp(x)
                    else -> throw IllegalArgumentException("Unknown function: $func")
                }
            } else {
                throw IllegalArgumentException("Unexpected char: ${ch.toChar()}")
            }
            if (eat('^'.code)) x = x.pow(parseFactor())
            return x
        }
    }.parse()
}
