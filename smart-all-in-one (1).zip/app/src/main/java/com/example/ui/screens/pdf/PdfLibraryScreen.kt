package com.example.ui.screens.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.files.FileCategory
import com.example.data.files.FileRepository
import com.example.data.files.ManagedFileItem
import com.example.data.local.AppSettings
import com.example.data.local.PdfMetaDao
import com.example.data.local.PdfMetaEntity
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class PdfTab { ALL, RECENT, FAVORITES }

private data class PdfThumbInfo(
    val bitmap: Bitmap?,
    val pageCount: Int
)

@Composable
fun PdfLibraryScreen(
    settings: AppSettings,
    fileRepository: FileRepository,
    pdfMetaDao: PdfMetaDao,
    pdfMetaList: List<PdfMetaEntity>,
    onAddTreeUri: (Uri) -> Unit,
    onOpenPdf: (uriString: String, title: String) -> Unit,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by remember { mutableStateOf(PdfTab.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var pdfFiles by remember { mutableStateOf<List<ManagedFileItem>>(emptyList()) }
    var renameTarget by remember { mutableStateOf<ManagedFileItem?>(null) }
    var deleteTarget by remember { mutableStateOf<ManagedFileItem?>(null) }

    fun refreshLibrary() {
        scope.launch {
            pdfFiles = fileRepository.collectCategoryFiles(FileCategory.PDF, settings.persistedTreeUris)
        }
    }

    LaunchedEffect(settings.persistedTreeUris) {
        refreshLibrary()
    }

    val openPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            fileRepository.takePersistablePermission(uri)
            scope.launch {
                val imported = fileRepository.importUriToWorkspace(uri, "PDFs")
                val targetUri = imported?.uri ?: uri
                val name = imported?.name ?: FileRepository.queryDisplayName(context.contentResolver, uri) ?: "Document.pdf"
                refreshLibrary()
                onOpenPdf(targetUri.toString(), name)
            }
        }
    }

    val folderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            onAddTreeUri(uri)
        }
    }

    val metaByUri = remember(pdfMetaList) { pdfMetaList.associateBy { it.uriString } }

    val displayed = remember(pdfFiles, metaByUri, tab, searchQuery) {
        val base = when (tab) {
            PdfTab.ALL -> pdfFiles
            PdfTab.RECENT -> pdfFiles.filter { (metaByUri[it.uri.toString()]?.lastOpenedAt ?: 0L) > 0L }
                .sortedByDescending { metaByUri[it.uri.toString()]?.lastOpenedAt ?: 0L }
            PdfTab.FAVORITES -> pdfFiles.filter { metaByUri[it.uri.toString()]?.isFavorite == true }
        }
        if (searchQuery.isBlank()) base else base.filter { it.name.contains(searchQuery, true) }
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolPdfReader,
                subtitle = "${pdfFiles.size} PDF documents detected",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { refreshLibrary() }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "Refresh PDFs", tint = PureWhite)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { openPdfLauncher.launch(arrayOf("application/pdf")) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("open_device_pdf_button")
                ) {
                    Icon(Icons.Rounded.PictureAsPdf, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.openPdfFile, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                OutlinedButton(
                    onClick = { folderLauncher.launch(null) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.FolderOpen, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.grantFolderAccess, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search PDF files by name...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("pdf_search_input")
            )

            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PdfTab.entries.forEach { t ->
                    FilterChip(
                        selected = tab == t,
                        onClick = { tab = t },
                        label = { Text(t.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            if (displayed.isEmpty()) {
                EmptyStatePanel(
                    icon = Icons.Rounded.PictureAsPdf,
                    title = "No PDFs Found",
                    subtitle = "Tap '${strings.openPdfFile}' to open any PDF, or '${strings.grantFolderAccess}' to auto-index device folders."
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(displayed, key = { it.id }) { item ->
                        val meta = metaByUri[item.uri.toString()]
                        PdfCardItem(
                            item = item,
                            meta = meta,
                            context = context,
                            onClick = { onOpenPdf(item.uri.toString(), item.name) },
                            onToggleFav = {
                                scope.launch {
                                    val current = pdfMetaDao.getByUri(item.uri.toString())
                                    pdfMetaDao.upsert(
                                        (current ?: PdfMetaEntity(item.uri.toString(), item.name))
                                            .copy(isFavorite = !(current?.isFavorite ?: false))
                                    )
                                }
                            },
                            onRename = { renameTarget = item },
                            onShare = {
                                val shareUri = fileRepository.getShareUri(item)
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, shareUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share ${item.name}"))
                            },
                            onDelete = { deleteTarget = item }
                        )
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        var newName by remember(target) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(strings.rename) },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val finalName = if (newName.lowercase().endsWith(".pdf")) newName else "$newName.pdf"
                        fileRepository.renameItem(target, finalName)
                        renameTarget = null
                        refreshLibrary()
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text(strings.cancel) }
            }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete ${target.name}?") },
            text = { Text("This PDF will be permanently deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        fileRepository.deleteItem(target)
                        pdfMetaDao.deleteByUri(target.uri.toString())
                        deleteTarget = null
                        refreshLibrary()
                    }
                }) { Text(strings.delete, color = RoseAccent) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
private fun PdfCardItem(
    item: ManagedFileItem,
    meta: PdfMetaEntity?,
    context: Context,
    onClick: () -> Unit,
    onToggleFav: () -> Unit,
    onRename: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val thumbInfo by produceState<PdfThumbInfo?>(initialValue = null, item.uri) {
        value = withContext(Dispatchers.IO) {
            renderPdfThumbnail(context, item)
        }
    }

    val dateStr = remember(item.lastModified) {
        if (item.lastModified > 0L) SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(item.lastModified)) else ""
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("pdf_item_${item.name}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PDF Thumbnail
            Box(
                modifier = Modifier
                    .size(width = 56.dp, height = 74.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFF1F5F9)),
                contentAlignment = Alignment.Center
            ) {
                val bmp = thumbInfo?.bitmap
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, tint = RoseAccent, modifier = Modifier.size(30.dp))
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                val pagesCount = thumbInfo?.pageCount ?: meta?.totalPages ?: 0
                val sizeLabel = FileRepository.formatSize(item.sizeBytes)
                Text(
                    text = buildString {
                        if (pagesCount > 0) append("$pagesCount pages • ")
                        append(sizeLabel)
                        if (dateStr.isNotEmpty()) append(" • $dateStr")
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Folder: ${item.locationLabel}" + if ((meta?.lastPage ?: 0) > 0) " • Resume p.${meta!!.lastPage + 1}" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Row {
                    IconButton(onClick = onToggleFav) {
                        Icon(
                            if (meta?.isFavorite == true) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = "Favorite PDF",
                            tint = if (meta?.isFavorite == true) RoseAccent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onShare) {
                        Icon(Icons.Rounded.Share, contentDescription = "Share PDF")
                    }
                }
                Row {
                    IconButton(onClick = onRename) {
                        Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = "Rename PDF")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Delete PDF", tint = RoseAccent)
                    }
                }
            }
        }
    }
}

private fun renderPdfThumbnail(context: Context, item: ManagedFileItem): PdfThumbInfo? {
    return runCatching {
        val pfd: ParcelFileDescriptor? = if (item.localFile != null) {
            ParcelFileDescriptor.open(item.localFile, ParcelFileDescriptor.MODE_READ_ONLY)
        } else {
            context.contentResolver.openFileDescriptor(item.uri, "r")
        }
        pfd?.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                val count = renderer.pageCount
                if (count <= 0) return@use null
                val page = renderer.openPage(0)
                val bmp = Bitmap.createBitmap(160, 220, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                PdfThumbInfo(bmp, count)
            }
        }
    }.getOrNull()
}
