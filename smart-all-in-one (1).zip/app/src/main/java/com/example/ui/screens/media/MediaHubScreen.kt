package com.example.ui.screens.media

import android.app.Activity
import android.content.ComponentName
import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.example.data.files.FileCategory
import com.example.data.files.FileRepository
import com.example.data.files.ManagedFileItem
import com.example.data.local.AppSettings
import com.example.data.local.RecentMediaDao
import com.example.data.local.RecentMediaEntity
import com.example.media.PlaybackService
import com.example.ui.components.EmptyStatePanel
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyBlueAccent
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun MediaHubScreen(
    initialTab: Int,
    initialUri: String?,
    settings: AppSettings,
    fileRepository: FileRepository,
    recentMediaDao: RecentMediaDao,
    recentMedia: List<RecentMediaEntity>,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(initialTab.coerceIn(0, 1)) }
    var audioList by remember { mutableStateOf<List<ManagedFileItem>>(emptyList()) }
    var videoList by remember { mutableStateOf<List<ManagedFileItem>>(emptyList()) }

    fun refreshMediaLists() {
        scope.launch {
            audioList = fileRepository.collectCategoryFiles(FileCategory.AUDIO, settings.persistedTreeUris)
            videoList = fileRepository.collectCategoryFiles(FileCategory.VIDEOS, settings.persistedTreeUris)
        }
    }

    LaunchedEffect(settings.persistedTreeUris) {
        refreshMediaLists()
    }

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            fileRepository.takePersistablePermission(uri)
            val name = FileRepository.queryDisplayName(context.contentResolver, uri) ?: "Audio Track"
            val item = ManagedFileItem(uri.toString(), name, uri, mimeType = "audio/*")
            audioList = (listOf(item) + audioList).distinctBy { it.uri.toString() }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            fileRepository.takePersistablePermission(uri)
            val name = FileRepository.queryDisplayName(context.contentResolver, uri) ?: "Video"
            val item = ManagedFileItem(uri.toString(), name, uri, mimeType = "video/*")
            videoList = (listOf(item) + videoList).distinctBy { it.uri.toString() }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Surface(color = NavyPrimary, contentColor = PureWhite) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Text(
                    text = strings.navMedia,
                    style = MaterialTheme.typography.headlineMedium,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                )
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = NavyPrimary,
                    contentColor = PureWhite
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text(strings.toolAudioPlayer) },
                        icon = { Icon(Icons.Rounded.MusicNote, null) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text(strings.toolVideoPlayer) },
                        icon = { Icon(Icons.Rounded.VideoLibrary, null) }
                    )
                }
            }
        }

        if (selectedTab == 0) {
            AudioPlayerPanel(
                tracks = audioList,
                recentAudio = recentMedia.filter { !it.isVideo },
                initialUri = if (initialTab == 0) initialUri else null,
                onPickAudio = { audioPicker.launch(arrayOf("audio/*")) },
                onRecordPlayed = { uri, title ->
                    scope.launch {
                        recentMediaDao.upsert(RecentMediaEntity(uri, title, "audio/*", isVideo = false))
                    }
                }
            )
        } else {
            VideoPlayerPanel(
                videos = videoList,
                initialUri = if (initialTab == 1) initialUri else null,
                onPickVideo = { videoPicker.launch(arrayOf("video/*")) },
                onRecordPlayed = { uri, title ->
                    scope.launch {
                        recentMediaDao.upsert(RecentMediaEntity(uri, title, "video/*", isVideo = true))
                    }
                }
            )
        }
    }
}

@Composable
private fun AudioPlayerPanel(
    tracks: List<ManagedFileItem>,
    recentAudio: List<RecentMediaEntity>,
    initialUri: String?,
    onPickAudio: () -> Unit,
    onRecordPlayed: (String, String) -> Unit
) {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var currentPos by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var currentTitle by remember { mutableStateOf("No audio selected") }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            runCatching {
                val ctrl = future.get()
                controller = ctrl
                isPlaying = ctrl.isPlaying
                currentTitle = ctrl.currentMediaItem?.mediaMetadata?.title?.toString() ?: "Ready to Play"
            }
        }, MoreExecutors.directExecutor())

        onDispose {
            MediaController.releaseFuture(future)
        }
    }

    LaunchedEffect(controller) {
        val ctrl = controller ?: return@LaunchedEffect
        while (true) {
            isPlaying = ctrl.isPlaying
            currentPos = ctrl.currentPosition.coerceAtLeast(0L)
            duration = ctrl.duration.coerceAtLeast(0L)
            currentTitle = ctrl.currentMediaItem?.mediaMetadata?.title?.toString() ?: currentTitle
            delay(500L)
        }
    }

    fun playPlaylistAt(list: List<ManagedFileItem>, index: Int) {
        val ctrl = controller ?: return
        val items = list.map { track ->
            MediaItem.Builder()
                .setUri(track.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(track.name).build())
                .build()
        }
        ctrl.setMediaItems(items, index, 0L)
        ctrl.prepare()
        ctrl.play()
        val chosen = list[index]
        currentTitle = chosen.name
        onRecordPlayed(chosen.uri.toString(), chosen.name)
    }

    LaunchedEffect(initialUri, controller) {
        if (initialUri != null && controller != null) {
            val ctrl = controller!!
            val name = FileRepository.queryDisplayName(context.contentResolver, Uri.parse(initialUri)) ?: "Audio"
            ctrl.setMediaItem(
                MediaItem.Builder().setUri(initialUri)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build())
                    .build()
            )
            ctrl.prepare()
            ctrl.play()
            currentTitle = name
            onRecordPlayed(initialUri, name)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Now Playing Card (MediaSessionService background playback + lockscreen controls)
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = NavyPrimary,
            contentColor = PureWhite,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Background Audio Player", style = MaterialTheme.typography.labelMedium, color = SkyBlueAccent)
                Spacer(Modifier.height(4.dp))
                Text(currentTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Slider(
                    value = if (duration > 0L) currentPos.toFloat() / duration.toFloat() else 0f,
                    onValueChange = { frac ->
                        if (duration > 0L) controller?.seekTo((frac * duration).toLong())
                    }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        shuffleEnabled = !shuffleEnabled
                        controller?.shuffleModeEnabled = shuffleEnabled
                    }) {
                        Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (shuffleEnabled) SkyBlueAccent else PureWhite.copy(alpha = 0.6f))
                    }
                    IconButton(onClick = { controller?.seekToPreviousMediaItem() }) {
                        Icon(Icons.Rounded.SkipPrevious, "Previous", tint = PureWhite)
                    }
                    Surface(
                        onClick = {
                            controller?.let { if (it.isPlaying) it.pause() else it.play() }
                        },
                        shape = RoundedCornerShape(50),
                        color = SkyBlueAccent,
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("audio_play_pause_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                "Play or Pause",
                                tint = NavyPrimary
                            )
                        }
                    }
                    IconButton(onClick = { controller?.seekToNextMediaItem() }) {
                        Icon(Icons.Rounded.SkipNext, "Next", tint = PureWhite)
                    }
                    IconButton(onClick = {
                        repeatMode = when (repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        controller?.repeatMode = repeatMode
                    }) {
                        Icon(
                            if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                            "Repeat",
                            tint = if (repeatMode != Player.REPEAT_MODE_OFF) SkyBlueAccent else PureWhite.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = onPickAudio,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Rounded.FolderOpen, null)
            Spacer(Modifier.width(8.dp))
            Text("Open Audio File (MP3, WAV, AAC)")
        }

        Spacer(Modifier.height(10.dp))

        if (tracks.isEmpty() && recentAudio.isEmpty()) {
            EmptyStatePanel(
                icon = Icons.Rounded.AudioFile,
                title = "Audio Playlist Empty",
                subtitle = "Open any MP3, WAV, or AAC file from your device or add a Storage Folder in File Manager."
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                if (tracks.isNotEmpty()) {
                    item {
                        Text("Playlist (${tracks.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    itemsIndexed(tracks, key = { _, it -> it.id }) { idx, track ->
                        ListItem(
                            headlineContent = { Text(track.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(track.locationLabel) },
                            leadingContent = { Icon(Icons.Rounded.AudioFile, null, tint = MaterialTheme.colorScheme.primary) },
                            modifier = Modifier.clickable { playPlaylistAt(tracks, idx) }
                        )
                    }
                }
                if (recentAudio.isNotEmpty()) {
                    item {
                        Spacer(Modifier.height(8.dp))
                        Text("Recently Played", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    itemsIndexed(recentAudio, key = { _, it -> "rec_${it.uriString}" }) { _, rec ->
                        ListItem(
                            headlineContent = { Text(rec.title, maxLines = 1) },
                            leadingContent = { Icon(Icons.Rounded.MusicNote, null) },
                            modifier = Modifier.clickable {
                                val item = ManagedFileItem(rec.uriString, rec.title, Uri.parse(rec.uriString), mimeType = rec.mimeType)
                                playPlaylistAt(listOf(item), 0)
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPlayerPanel(
    videos: List<ManagedFileItem>,
    initialUri: String?,
    onPickVideo: () -> Unit,
    onRecordPlayed: (String, String) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val exoPlayer = remember { ExoPlayer.Builder(context).build() }
    var currentIdx by remember { mutableIntStateOf(0) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var volume by remember { mutableFloatStateOf(1f) }
    var brightness by remember { mutableFloatStateOf(0.6f) }
    var isFullscreen by remember { mutableStateOf(false) }

    val subtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { subUri ->
        val cur = exoPlayer.currentMediaItem ?: return@rememberLauncherForActivityResult
        if (subUri != null) {
            val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                .setLanguage("en")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            val updated = cur.buildUpon().setSubtitleConfigurations(listOf(subtitleConfig)).build()
            val pos = exoPlayer.currentPosition
            exoPlayer.setMediaItem(updated)
            exoPlayer.prepare()
            exoPlayer.seekTo(pos)
            exoPlayer.play()
        }
    }

    LaunchedEffect(initialUri) {
        if (initialUri != null) {
            val name = FileRepository.queryDisplayName(context.contentResolver, Uri.parse(initialUri)) ?: "Video"
            exoPlayer.setMediaItem(MediaItem.fromUri(initialUri))
            exoPlayer.prepare()
            exoPlayer.play()
            onRecordPlayed(initialUri, name)
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .let { if (isFullscreen) it.weight(1f) else it.aspectRatio(16f / 9f) }
                .background(Color.Black)
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = true
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            IconButton(
                onClick = { isFullscreen = !isFullscreen },
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
            ) {
                Icon(
                    if (isFullscreen) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                    contentDescription = "Fullscreen",
                    tint = PureWhite
                )
            }
        }

        if (!isFullscreen) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Speed & Subtitles Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                        FilterChip(
                            selected = playbackSpeed == spd,
                            onClick = {
                                playbackSpeed = spd
                                exoPlayer.setPlaybackSpeed(spd)
                            },
                            label = { Text("${spd}x") }
                        )
                    }
                }

                // Volume & Brightness Sliders
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Rounded.VolumeUp, null, modifier = Modifier.size(20.dp))
                    Slider(
                        value = volume,
                        onValueChange = {
                            volume = it
                            exoPlayer.volume = it
                        },
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    Icon(Icons.Rounded.BrightnessMedium, null, modifier = Modifier.size(20.dp))
                    Slider(
                        value = brightness,
                        onValueChange = { b ->
                            brightness = b
                            activity?.window?.let { win ->
                                val lp = win.attributes
                                lp.screenBrightness = b.coerceIn(0.05f, 1f)
                                win.attributes = lp
                            }
                        },
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPickVideo, modifier = Modifier.weight(1f)) {
                        Text("Open Video (MP4/MKV)")
                    }
                    Button(
                        onClick = { subtitlePicker.launch(arrayOf("*/*")) },
                        enabled = exoPlayer.currentMediaItem != null
                    ) {
                        Icon(Icons.Rounded.Subtitles, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Subtitle")
                    }
                }

                if (videos.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Video Library (${videos.size})", fontWeight = FontWeight.Bold)
                        Row {
                            IconButton(
                                onClick = {
                                    if (currentIdx > 0) {
                                        currentIdx--
                                        val v = videos[currentIdx]
                                        exoPlayer.setMediaItem(MediaItem.fromUri(v.uri))
                                        exoPlayer.prepare(); exoPlayer.play()
                                        onRecordPlayed(v.uri.toString(), v.name)
                                    }
                                }
                            ) { Icon(Icons.Rounded.SkipPrevious, "Previous Video") }
                            IconButton(
                                onClick = {
                                    if (currentIdx < videos.lastIndex) {
                                        currentIdx++
                                        val v = videos[currentIdx]
                                        exoPlayer.setMediaItem(MediaItem.fromUri(v.uri))
                                        exoPlayer.prepare(); exoPlayer.play()
                                        onRecordPlayed(v.uri.toString(), v.name)
                                    }
                                }
                            ) { Icon(Icons.Rounded.SkipNext, "Next Video") }
                        }
                    }

                    LazyColumn {
                        itemsIndexed(videos, key = { _, it -> it.id }) { idx, vid ->
                            ListItem(
                                headlineContent = { Text(vid.name, maxLines = 1) },
                                supportingContent = { Text(vid.locationLabel) },
                                leadingContent = { Icon(Icons.Rounded.VideoLibrary, null) },
                                modifier = Modifier.clickable {
                                    currentIdx = idx
                                    exoPlayer.setMediaItem(MediaItem.fromUri(vid.uri))
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                    onRecordPlayed(vid.uri.toString(), vid.name)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
