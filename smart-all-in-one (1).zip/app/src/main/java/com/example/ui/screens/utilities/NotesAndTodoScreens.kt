package com.example.ui.screens.utilities

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.NoteDao
import com.example.data.local.NoteEntity
import com.example.data.local.TodoDao
import com.example.data.local.TodoEntity
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import kotlinx.coroutines.launch

@Composable
fun NotesScreen(
    noteDao: NoteDao,
    notes: List<NoteEntity>,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<NoteEntity?>(null) }

    val filtered = remember(notes, searchQuery) {
        if (searchQuery.isBlank()) notes
        else notes.filter { it.title.contains(searchQuery, true) || it.content.contains(searchQuery, true) }
    }

    val noteColors = listOf(
        MaterialTheme.colorScheme.surface,
        Color(0xFFE0F2FE),
        Color(0xFFFEF3C7),
        Color(0xFFDCFCE7)
    )

    Scaffold(
        topBar = {
            ModuleTopBar(title = strings.toolNotes, subtitle = "${notes.size} notes", onBack = onBack)
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editingNote = NoteEntity(title = "", content = "") },
                modifier = Modifier.testTag("add_note_fab")
            ) {
                Icon(Icons.Rounded.Add, "Add Note")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search notes...") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )

            if (filtered.isEmpty()) {
                EmptyStatePanel(
                    icon = Icons.Rounded.EditNote,
                    title = "No Notes Yet",
                    subtitle = "Tap + to jot down quick ideas, meeting notes, or study reminders."
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { note ->
                        val bg = noteColors[note.colorIndex.coerceIn(0, noteColors.lastIndex)]
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = bg,
                            tonalElevation = 2.dp,
                            shadowElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth().clickable { editingNote = note }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = note.title.ifBlank { "Untitled Note" },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Row {
                                        IconButton(onClick = {
                                            scope.launch { noteDao.upsert(note.copy(isPinned = !note.isPinned)) }
                                        }) {
                                            Icon(
                                                Icons.Rounded.PushPin,
                                                "Pin Note",
                                                tint = if (note.isPinned) AmberAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = {
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, "${note.title}\n\n${note.content}")
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Share Note"))
                                        }) { Icon(Icons.Rounded.Share, "Share Note") }
                                        IconButton(onClick = { scope.launch { noteDao.delete(note) } }) {
                                            Icon(Icons.Rounded.Delete, "Delete Note", tint = RoseAccent)
                                        }
                                    }
                                }
                                if (note.content.isNotBlank()) {
                                    Text(
                                        text = note.content,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 4,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editingNote?.let { target ->
        var title by remember(target) { mutableStateOf(target.title) }
        var content by remember(target) { mutableStateOf(target.content) }
        var colorIdx by remember(target) { mutableIntStateOf(target.colorIndex) }

        AlertDialog(
            onDismissRequest = { editingNote = null },
            title = { Text(if (target.id == 0L) "New Note" else "Edit Note") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Content") }, minLines = 4)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Default", "Blue", "Amber", "Green").forEachIndexed { idx, label ->
                            FilterChip(selected = colorIdx == idx, onClick = { colorIdx = idx }, label = { Text(label) })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isBlank() && content.isBlank()) { editingNote = null; return@TextButton }
                    scope.launch {
                        noteDao.upsert(
                            target.copy(
                                title = title.trim(),
                                content = content.trim(),
                                colorIndex = colorIdx,
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                        editingNote = null
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { editingNote = null }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
fun TodoScreen(
    todoDao: TodoDao,
    todos: List<TodoEntity>,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val scope = rememberCoroutineScope()
    var filterMode by remember { mutableIntStateOf(0) } // 0=All, 1=Pending, 2=Done
    var showAddDialog by remember { mutableStateOf(false) }

    val displayed = remember(todos, filterMode) {
        when (filterMode) {
            1 -> todos.filter { !it.isDone }
            2 -> todos.filter { it.isDone }
            else -> todos
        }
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolTodo,
                subtitle = "${todos.count { !it.isDone }} pending",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { scope.launch { todoDao.deleteCompleted() } }) {
                        Icon(Icons.Rounded.DeleteSweep, "Clear Completed", tint = PureWhite)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                modifier = Modifier.testTag("add_todo_fab")
            ) {
                Icon(Icons.Rounded.Add, "Add Task")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = filterMode == 0, onClick = { filterMode = 0 }, label = { Text("All (${todos.size})") })
                FilterChip(selected = filterMode == 1, onClick = { filterMode = 1 }, label = { Text("Pending") })
                FilterChip(selected = filterMode == 2, onClick = { filterMode = 2 }, label = { Text("Done") })
            }

            if (displayed.isEmpty()) {
                EmptyStatePanel(
                    icon = Icons.Rounded.Checklist,
                    title = "No Tasks Here",
                    subtitle = "Tap + to add a task with priority and category."
                )
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 84.dp)) {
                    items(displayed, key = { it.id }) { task ->
                        ListItem(
                            headlineContent = {
                                Text(
                                    text = task.title,
                                    textDecoration = if (task.isDone) TextDecoration.LineThrough else TextDecoration.None,
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            supportingContent = {
                                val pLabel = when (task.priority) {
                                    2 -> "High Priority"
                                    0 -> "Low Priority"
                                    else -> "Normal"
                                }
                                Text("${task.category} • $pLabel")
                            },
                            leadingContent = {
                                Checkbox(
                                    checked = task.isDone,
                                    onCheckedChange = { checked ->
                                        scope.launch { todoDao.upsert(task.copy(isDone = checked)) }
                                    }
                                )
                            },
                            trailingContent = {
                                IconButton(onClick = { scope.launch { todoDao.delete(task) } }) {
                                    Icon(Icons.Rounded.Delete, "Delete Task", tint = RoseAccent)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Personal") }
        var priority by remember { mutableIntStateOf(1) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("New Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Personal", "Work", "Study").forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0 to "Low", 1 to "Normal", 2 to "High").forEach { (p, lbl) ->
                            FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(lbl) })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isBlank()) return@TextButton
                    scope.launch {
                        todoDao.upsert(TodoEntity(title = title.trim(), category = category, priority = priority))
                        showAddDialog = false
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}
