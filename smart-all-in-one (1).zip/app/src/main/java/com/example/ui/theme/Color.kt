package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Navy Blue, White & Light Blue Palette
val NavyDeep = Color(0xFF07152B)
val NavyPrimary = Color(0xFF0D254C)
val NavyContainer = Color(0xFF173A73)
val SkyBlueAccent = Color(0xFF38BDF8)
val LightBlueBright = Color(0xFF60A5FA)
val LightBlueSoft = Color(0xFFE0F2FE)
val IceBlueSurface = Color(0xFFF4F8FF)
val PureWhite = Color(0xFFFFFFFF)

val NavyDarkSurface = Color(0xFF0A192F)
val NavyDarkCard = Color(0xFF112240)
val NavyDarkElevated = Color(0xFF1A3158)

val EmeraldAccent = Color(0xFF10B981)
val AmberAccent = Color(0xFFF59E0B)
val RoseAccent = Color(0xFFF43F5E)
val IndigoAccent = Color(0xFF6366F1)
val CyanAccent = Color(0xFF06B6D4)
val VioletAccent = Color(0xFF8B5CF6)
