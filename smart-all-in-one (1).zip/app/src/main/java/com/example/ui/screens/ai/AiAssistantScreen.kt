package com.example.ui.screens.ai

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.AiAssistantMode
import com.example.data.ai.AiRepository
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalAppLanguage
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import com.example.ui.theme.SkyBlueAccent
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
    aiRepository: AiRepository,
    chatDao: ChatDao,
    sessions: List<ChatSessionEntity>,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var currentSessionId by remember { mutableLongStateOf(sessions.firstOrNull()?.id ?: 0L) }
    var selectedMode by remember { mutableStateOf(AiAssistantMode.CHAT) }
    var promptInput by remember { mutableStateOf("") }
    var streamingReply by remember { mutableStateOf<String?>(null) }
    var showHistorySheet by remember { mutableStateOf(false) }

    LaunchedEffect(sessions) {
        if (currentSessionId == 0L && sessions.isNotEmpty()) {
            currentSessionId = sessions.first().id
        }
    }

    val messages by remember(currentSessionId) {
        chatDao.observeMessages(currentSessionId)
    }.collectAsStateWithLifecycle(initialValue = emptyList())

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, streamingReply) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) promptInput = spoken
        }
    }

    fun sendMessage(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || streamingReply != null) return
        promptInput = ""
        scope.launch {
            var sid = currentSessionId
            if (sid == 0L) {
                sid = chatDao.insertSession(ChatSessionEntity(title = clean.take(36)))
                currentSessionId = sid
            } else {
                chatDao.updateSession(ChatSessionEntity(id = sid, title = clean.take(36)))
            }
            chatDao.insertMessage(ChatMessageEntity(sessionId = sid, isUser = true, text = clean))

            var finalText = ""
            streamingReply = "..."
            aiRepository.sendPromptStream(clean, selectedMode, language.code).collectLatest { partial ->
                finalText = partial
                streamingReply = partial
            }
            streamingReply = null
            if (finalText.isNotBlank()) {
                chatDao.insertMessage(ChatMessageEntity(sessionId = sid, isUser = false, text = finalText))
            }
        }
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolChatGpt,
                subtitle = "Bengali & English Assistant",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        scope.launch {
                            val newId = chatDao.insertSession(ChatSessionEntity(title = "New Chat"))
                            currentSessionId = newId
                        }
                    }) {
                        Icon(Icons.Rounded.AddComment, "New Conversation", tint = PureWhite)
                    }
                    IconButton(onClick = { showHistorySheet = true }) {
                        Icon(Icons.Rounded.History, "Chat History", tint = PureWhite)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // In-app notice + Official ChatGPT Launch Banner
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (aiRepository.isLiveAiEnabled) "Connected to Firebase AI Logic"
                            else "Sample offline AI responses (live Gemini requires Firebase).",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    TextButton(onClick = {
                        runCatching {
                            CustomTabsIntent.Builder().build().launchUrl(context, Uri.parse("https://chatgpt.com"))
                        }.onFailure {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com")))
                        }
                    }) {
                        Text("Open ChatGPT")
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, null, modifier = Modifier.size(15.dp))
                    }
                }
            }

            // Mode Chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(AiAssistantMode.entries) { mode ->
                    FilterChip(
                        selected = selectedMode == mode,
                        onClick = { selectedMode = mode },
                        label = { Text(if (language == AppLanguage.BN) mode.labelBn else mode.labelEn) }
                    )
                }
            }

            // Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty() && streamingReply == null) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = SkyBlueAccent, modifier = Modifier.size(44.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = if (language == AppLanguage.BN) "বাংলা বা ইংরেজিতে যেকোনো প্রশ্ন করুন" else "Ask anything in Bengali or English",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(10.dp))
                            listOf(
                                "Write a professional email requesting leave",
                                "বাংলায় অনুবাদ করো: Knowledge is power",
                                "Summarize the benefits of daily planning"
                            ).forEach { suggestion ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    tonalElevation = 2.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable { sendMessage(suggestion) }
                                ) {
                                    Text(suggestion, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }

                items(messages, key = { it.id }) { msg ->
                    ChatBubble(
                        text = msg.text,
                        isUser = msg.isUser,
                        onCopy = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("AI Response", msg.text))
                            Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                        },
                        onShare = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, msg.text)
                            }
                            context.startActivity(Intent.createChooser(intent, "Share Response"))
                        }
                    )
                }

                streamingReply?.let { partial ->
                    item {
                        ChatBubble(text = partial, isUser = false, onCopy = {}, onShare = {})
                    }
                }
            }

            // Input Bar
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    placeholder = { Text("Ask in English or বাংলা...") },
                    trailingIcon = {
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            }
                            runCatching { voiceLauncher.launch(intent) }
                        }) {
                            Icon(Icons.Rounded.Mic, "Voice Input")
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    maxLines = 3,
                    modifier = Modifier.weight(1f).testTag("ai_prompt_input")
                )
                Surface(
                    onClick = { sendMessage(promptInput) },
                    shape = RoundedCornerShape(16.dp),
                    color = NavyPrimary,
                    contentColor = PureWhite,
                    modifier = Modifier.size(50.dp).testTag("ai_send_button")
                ) {
                    androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.Send, "Send")
                    }
                }
            }
        }
    }

    if (showHistorySheet) {
        ModalBottomSheet(onDismissRequest = { showHistorySheet = false }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 24.dp)
            ) {
                Text("Chat History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                LazyColumn(modifier = Modifier.height(300.dp)) {
                    items(sessions, key = { it.id }) { session ->
                        ListItem(
                            headlineContent = { Text(session.title, maxLines = 1) },
                            trailingContent = {
                                IconButton(onClick = {
                                    scope.launch {
                                        chatDao.deleteMessagesForSession(session.id)
                                        chatDao.deleteSession(session.id)
                                        if (currentSessionId == session.id) currentSessionId = 0L
                                    }
                                }) {
                                    Icon(Icons.Rounded.Delete, "Delete Chat", tint = RoseAccent)
                                }
                            },
                            modifier = Modifier.clickable {
                                currentSessionId = session.id
                                showHistorySheet = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(
    text: String,
    isUser: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (isUser) NavyPrimary else MaterialTheme.colorScheme.surface,
            contentColor = if (isUser) PureWhite else MaterialTheme.colorScheme.onSurface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth(0.88f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = text, style = MaterialTheme.typography.bodyLarge)
                if (!isUser) {
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Rounded.ContentCopy, "Copy", modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Rounded.Share, "Share", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
