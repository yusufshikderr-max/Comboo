package com.example.ui.screens.contacts

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.contacts.ContactsRepository
import com.example.data.contacts.DeviceContact
import com.example.data.local.FavoriteContactDao
import com.example.data.local.FavoriteContactEntity
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.ModuleTopBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseAccent
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(
    contactsRepository: ContactsRepository,
    favoriteDao: FavoriteContactDao,
    favoriteIds: Set<String>,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasPermission = result[Manifest.permission.READ_CONTACTS] == true
    }

    var contacts by remember { mutableStateOf<List<DeviceContact>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var selectedContact by remember { mutableStateOf<DeviceContact?>(null) }
    var showAddEditDialog by remember { mutableStateOf<DeviceContact?>(null) }
    var isAddingNew by remember { mutableStateOf(false) }
    var deleteConfirmContact by remember { mutableStateOf<DeviceContact?>(null) }

    fun reload() {
        if (!hasPermission) return
        scope.launch { contacts = contactsRepository.loadContacts() }
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) reload()
    }

    val displayed = remember(contacts, searchQuery, favoritesOnly, favoriteIds) {
        val base = if (favoritesOnly) contacts.filter { favoriteIds.contains(it.id) } else contacts
        if (searchQuery.isBlank()) base
        else base.filter {
            it.displayName.contains(searchQuery, true) || it.phoneNumber.contains(searchQuery, true)
        }
    }

    Scaffold(
        topBar = {
            ModuleTopBar(
                title = strings.toolContacts,
                subtitle = "${displayed.size} contacts",
                onBack = onBack
            )
        },
        floatingActionButton = {
            if (hasPermission) {
                FloatingActionButton(
                    onClick = {
                        isAddingNew = true
                        showAddEditDialog = DeviceContact("", "", "", "", null)
                    },
                    modifier = Modifier.testTag("add_contact_fab")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Add Contact")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!hasPermission) {
                EmptyStatePanel(
                    icon = Icons.Rounded.AccountCircle,
                    title = "Contacts Permission Required",
                    subtitle = "Grant Contacts access to view, call, SMS, add, edit, and manage phone contacts.",
                    actionLabel = "Grant Contacts Permission",
                    onAction = {
                        permLauncher.launch(
                            arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)
                        )
                    }
                )
            } else {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search name or phone number...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )

                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(selected = !favoritesOnly, onClick = { favoritesOnly = false }, label = { Text("All (${contacts.size})") })
                    FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = true }, label = { Text("Favorites (${favoriteIds.size})") })
                }

                if (displayed.isEmpty()) {
                    EmptyStatePanel(
                        icon = Icons.Rounded.AccountCircle,
                        title = "No contacts found",
                        subtitle = "Tap + to create a new contact on this device."
                    )
                } else {
                    LazyColumn(contentPadding = PaddingValues(bottom = 84.dp)) {
                        items(displayed, key = { it.id }) { contact ->
                            val isFav = favoriteIds.contains(contact.id)
                            ListItem(
                                headlineContent = { Text(contact.displayName, fontWeight = FontWeight.SemiBold) },
                                supportingContent = {
                                    Text(
                                        buildString {
                                            append(contact.phoneNumber)
                                            if (contact.email.isNotBlank()) append(" • ${contact.email}")
                                        }
                                    )
                                },
                                leadingContent = { ContactAvatar(contact) },
                                trailingContent = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = {
                                            scope.launch {
                                                if (isFav) favoriteDao.deleteById(contact.id)
                                                else favoriteDao.insert(FavoriteContactEntity(contact.id, contact.displayName))
                                            }
                                        }) {
                                            Icon(
                                                if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                                contentDescription = "Favorite",
                                                tint = if (isFav) AmberAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = {
                                            val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phoneNumber}"))
                                            context.startActivity(dial)
                                        }) {
                                            Icon(Icons.Rounded.Call, contentDescription = "Call", tint = EmeraldAccent)
                                        }
                                    }
                                },
                                modifier = Modifier.clickable { selectedContact = contact }
                            )
                        }
                    }
                }
            }
        }
    }

    selectedContact?.let { contact ->
        ModalBottomSheet(onDismissRequest = { selectedContact = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ContactAvatar(contact, size = 68)
                Spacer(Modifier.height(10.dp))
                Text(contact.displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                if (contact.phoneNumber.isNotBlank()) {
                    Text(contact.phoneNumber, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (contact.email.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Email, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(contact.email, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phoneNumber}")))
                    }) {
                        Icon(Icons.Rounded.Call, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Call")
                    }
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${contact.phoneNumber}")))
                    }) {
                        Icon(Icons.Rounded.Sms, null)
                        Spacer(Modifier.width(4.dp))
                        Text("SMS")
                    }
                    OutlinedButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "${contact.displayName}\n${contact.phoneNumber}\n${contact.email}")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Contact"))
                    }) {
                        Icon(Icons.Rounded.Share, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Share")
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            selectedContact = null
                            isAddingNew = false
                            showAddEditDialog = contact
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Edit, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Edit")
                    }
                    OutlinedButton(
                        onClick = {
                            selectedContact = null
                            deleteConfirmContact = contact
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Delete, null, tint = RoseAccent)
                        Spacer(Modifier.width(6.dp))
                        Text("Delete", color = RoseAccent)
                    }
                }
            }
        }
    }

    showAddEditDialog?.let { editing ->
        var name by remember(editing) { mutableStateOf(editing.displayName) }
        var phone by remember(editing) { mutableStateOf(editing.phoneNumber) }
        var email by remember(editing) { mutableStateOf(editing.email) }

        AlertDialog(
            onDismissRequest = { showAddEditDialog = null },
            title = { Text(if (isAddingNew) "New Contact" else "Edit Contact") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, singleLine = true)
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val ok = if (isAddingNew) {
                            contactsRepository.addContact(name, phone, email)
                        } else {
                            contactsRepository.updateContact(editing.id, name, phone, email)
                        }
                        showAddEditDialog = null
                        if (ok) reload() else Toast.makeText(context, "Contact update failed", Toast.LENGTH_SHORT).show()
                    }
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showAddEditDialog = null }) { Text(strings.cancel) }
            }
        )
    }

    deleteConfirmContact?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteConfirmContact = null },
            title = { Text("Delete ${target.displayName}?") },
            text = { Text("This removes the contact from your device.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        contactsRepository.deleteContact(target.id)
                        deleteConfirmContact = null
                        reload()
                    }
                }) { Text(strings.delete, color = RoseAccent) }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmContact = null }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
private fun ContactAvatar(contact: DeviceContact, size: Int = 44) {
    if (!contact.photoUri.isNullOrBlank()) {
        AsyncImage(
            model = Uri.parse(contact.photoUri),
            contentDescription = contact.displayName,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size.dp)
                .clip(CircleShape)
        )
    } else {
        Box(
            modifier = Modifier
                .size(size.dp)
                .clip(CircleShape)
                .background(NavyPrimary),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = contact.displayName.firstOrNull()?.uppercase() ?: "?",
                color = PureWhite,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
