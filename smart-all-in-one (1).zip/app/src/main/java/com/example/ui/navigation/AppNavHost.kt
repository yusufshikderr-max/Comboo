package com.example.ui.navigation

import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.ai.AiRepository
import com.example.data.contacts.ContactsRepository
import com.example.data.files.FileRepository
import com.example.data.local.AppDatabase
import com.example.data.local.AppSettings
import com.example.data.local.PreferencesRepository
import com.example.ui.components.SplashScreenOverlay
import com.example.ui.i18n.LocalAppLanguage
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.ai.AiAssistantScreen
import com.example.ui.screens.calculator.CalculatorScreen
import com.example.ui.screens.calendar.CalendarScreen
import com.example.ui.screens.contacts.ContactsScreen
import com.example.ui.screens.files.FileManagerScreen
import com.example.ui.screens.gallery.GalleryScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.ToolsHubScreen
import com.example.ui.screens.media.MediaHubScreen
import com.example.ui.screens.pdf.PdfLibraryScreen
import com.example.ui.screens.pdf.PdfViewerScreen
import com.example.ui.screens.scanner.DocumentScannerScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.utilities.ClockToolsScreen
import com.example.ui.screens.utilities.NotesScreen
import com.example.ui.screens.utilities.QrScannerScreen
import com.example.ui.screens.utilities.TodoScreen
import com.example.ui.screens.utilities.UnitConverterScreen
import com.example.ui.screens.web.GmailScreen
import com.example.ui.screens.web.GoogleSearchScreen
import com.example.ui.screens.web.MapsScreen
import com.example.ui.screens.web.YouTubeScreen
import com.example.ui.theme.SmartAllInOneTheme
import kotlinx.coroutines.launch

@Composable
fun SmartAllInOneApp(
    database: AppDatabase,
    preferencesRepository: PreferencesRepository,
    fileRepository: FileRepository,
    contactsRepository: ContactsRepository,
    aiRepository: AiRepository,
    incomingPdfUri: Uri?,
    onIncomingPdfHandled: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val settings by preferencesRepository.settingsFlow.collectAsStateWithLifecycle(initialValue = AppSettings())
    val notes by database.noteDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val todos by database.todoDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val calendarEvents by database.calendarEventDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val pdfMetaList by database.pdfMetaDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val calcHistory by database.calcHistoryDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val chatSessions by database.chatDao().observeSessions().collectAsStateWithLifecycle(initialValue = emptyList())
    val recentMedia by database.recentMediaDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val favoriteContacts by database.favoriteContactDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())

    val strings = remember(settings.language) { stringsFor(settings.language) }
    var showSplash by remember { mutableStateOf(true) }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination

    LaunchedEffect(Unit) {
        fileRepository.ensureStarterAssets()
    }

    LaunchedEffect(incomingPdfUri) {
        if (incomingPdfUri != null) {
            val name = FileRepository.queryDisplayName(
                navController.context.contentResolver,
                incomingPdfUri
            ) ?: "Document.pdf"
            navController.navigate(AppRoute.PdfViewer(incomingPdfUri.toString(), name))
            onIncomingPdfHandled()
        }
    }

    val showBottomBar = currentDest?.let { dest ->
        dest.hasRoute<AppRoute.Home>() ||
            dest.hasRoute<AppRoute.Tools>() ||
            dest.hasRoute<AppRoute.Media>() ||
            dest.hasRoute<AppRoute.Calendar>() ||
            dest.hasRoute<AppRoute.Settings>()
    } ?: true

    val navigateToTopTab: (AppRoute) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    SmartAllInOneTheme(themeMode = settings.themeMode) {
        CompositionLocalProvider(
            LocalAppStrings provides strings,
            LocalAppLanguage provides settings.language
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Scaffold(
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar(
                                windowInsets = WindowInsets.navigationBars,
                                containerColor = MaterialTheme.colorScheme.surface
                            ) {
                                NavigationBarItem(
                                    selected = currentDest?.hasRoute<AppRoute.Home>() == true,
                                    onClick = { navigateToTopTab(AppRoute.Home) },
                                    icon = {
                                        Icon(
                                            if (currentDest?.hasRoute<AppRoute.Home>() == true) Icons.Rounded.Home else Icons.Outlined.Home,
                                            contentDescription = strings.navHome
                                        )
                                    },
                                    label = { Text(strings.navHome) },
                                    modifier = Modifier.testTag("bottom_nav_home")
                                )
                                NavigationBarItem(
                                    selected = currentDest?.hasRoute<AppRoute.Tools>() == true,
                                    onClick = { navigateToTopTab(AppRoute.Tools) },
                                    icon = {
                                        Icon(
                                            if (currentDest?.hasRoute<AppRoute.Tools>() == true) Icons.Rounded.Apps else Icons.Outlined.Apps,
                                            contentDescription = strings.navTools
                                        )
                                    },
                                    label = { Text(strings.navTools) },
                                    modifier = Modifier.testTag("bottom_nav_tools")
                                )
                                NavigationBarItem(
                                    selected = currentDest?.hasRoute<AppRoute.Media>() == true,
                                    onClick = { navigateToTopTab(AppRoute.Media()) },
                                    icon = {
                                        Icon(
                                            if (currentDest?.hasRoute<AppRoute.Media>() == true) Icons.Rounded.PlayCircle else Icons.Outlined.PlayCircle,
                                            contentDescription = strings.navMedia
                                        )
                                    },
                                    label = { Text(strings.navMedia) },
                                    modifier = Modifier.testTag("bottom_nav_media")
                                )
                                NavigationBarItem(
                                    selected = currentDest?.hasRoute<AppRoute.Calendar>() == true,
                                    onClick = { navigateToTopTab(AppRoute.Calendar) },
                                    icon = {
                                        Icon(
                                            if (currentDest?.hasRoute<AppRoute.Calendar>() == true) Icons.Rounded.CalendarMonth else Icons.Outlined.CalendarMonth,
                                            contentDescription = strings.navCalendar
                                        )
                                    },
                                    label = { Text(strings.navCalendar) },
                                    modifier = Modifier.testTag("bottom_nav_calendar")
                                )
                                NavigationBarItem(
                                    selected = currentDest?.hasRoute<AppRoute.Settings>() == true,
                                    onClick = { navigateToTopTab(AppRoute.Settings) },
                                    icon = {
                                        Icon(
                                            if (currentDest?.hasRoute<AppRoute.Settings>() == true) Icons.Rounded.Settings else Icons.Outlined.Settings,
                                            contentDescription = strings.navSettings
                                        )
                                    },
                                    label = { Text(strings.navSettings) },
                                    modifier = Modifier.testTag("bottom_nav_settings")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = AppRoute.Home,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable<AppRoute.Home> {
                            HomeScreen(
                                settings = settings,
                                upcomingEvents = calendarEvents,
                                pendingTodos = todos.filter { !it.isDone },
                                onNavigate = { route ->
                                    if (route is AppRoute.Tools || route is AppRoute.Media || route is AppRoute.Calendar || route is AppRoute.Settings) {
                                        navigateToTopTab(route)
                                    } else {
                                        navController.navigate(route)
                                    }
                                },
                                onToggleShortcut = { id -> scope.launch { preferencesRepository.toggleShortcut(id) } }
                            )
                        }

                        composable<AppRoute.Tools> {
                            ToolsHubScreen(
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }

                        composable<AppRoute.Media> { entry ->
                            val args = entry.toRoute<AppRoute.Media>()
                            MediaHubScreen(
                                initialTab = args.initialTab,
                                initialUri = args.initialUri,
                                settings = settings,
                                fileRepository = fileRepository,
                                recentMediaDao = database.recentMediaDao(),
                                recentMedia = recentMedia
                            )
                        }

                        composable<AppRoute.Calendar> {
                            CalendarScreen(
                                hijriOffsetDays = settings.hijriOffsetDays,
                                eventDao = database.calendarEventDao(),
                                allEvents = calendarEvents
                            )
                        }

                        composable<AppRoute.Settings> {
                            SettingsScreen(
                                settings = settings,
                                onSetThemeMode = { scope.launch { preferencesRepository.setThemeMode(it) } },
                                onSetLanguage = { scope.launch { preferencesRepository.setLanguage(it) } },
                                onSetHijriOffset = { scope.launch { preferencesRepository.setHijriOffset(it) } },
                                onSetNotifications = { scope.launch { preferencesRepository.setNotificationsEnabled(it) } },
                                onToggleShortcut = { scope.launch { preferencesRepository.toggleShortcut(it) } },
                                onAddFolderUri = { uri ->
                                    fileRepository.takePersistablePermission(uri)
                                    scope.launch { preferencesRepository.addPersistedTreeUri(uri.toString()) }
                                }
                            )
                        }

                        composable<AppRoute.FileManager> { entry ->
                            val args = entry.toRoute<AppRoute.FileManager>()
                            FileManagerScreen(
                                initialCategory = args.initialCategory,
                                settings = settings,
                                fileRepository = fileRepository,
                                onAddTreeUri = { uri ->
                                    fileRepository.takePersistablePermission(uri)
                                    scope.launch { preferencesRepository.addPersistedTreeUri(uri.toString()) }
                                },
                                onNavigate = { navController.navigate(it) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.Gallery> {
                            GalleryScreen(
                                settings = settings,
                                fileRepository = fileRepository,
                                onAddPickedUris = { uris -> scope.launch { preferencesRepository.addPickedMediaUris(uris) } },
                                onRemovePickedUri = { uri -> scope.launch { preferencesRepository.removePickedMediaUri(uri) } },
                                onRecordView = { uri -> scope.launch { preferencesRepository.recordGalleryView(uri) } },
                                onNavigate = { navController.navigate(it) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.Contacts> {
                            ContactsScreen(
                                contactsRepository = contactsRepository,
                                favoriteDao = database.favoriteContactDao(),
                                favoriteIds = favoriteContacts.map { it.contactId }.toSet(),
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.Calculator> {
                            CalculatorScreen(
                                historyDao = database.calcHistoryDao(),
                                history = calcHistory,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.PdfLibrary> {
                            PdfLibraryScreen(
                                settings = settings,
                                fileRepository = fileRepository,
                                pdfMetaDao = database.pdfMetaDao(),
                                pdfMetaList = pdfMetaList,
                                onAddTreeUri = { uri ->
                                    fileRepository.takePersistablePermission(uri)
                                    scope.launch { preferencesRepository.addPersistedTreeUri(uri.toString()) }
                                },
                                onOpenPdf = { uriStr, title ->
                                    navController.navigate(AppRoute.PdfViewer(uriStr, title))
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.PdfViewer> { entry ->
                            val args = entry.toRoute<AppRoute.PdfViewer>()
                            PdfViewerScreen(
                                uriString = args.uriString,
                                title = args.title,
                                pdfMetaDao = database.pdfMetaDao(),
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.DocumentScanner> {
                            DocumentScannerScreen(
                                fileRepository = fileRepository,
                                onOpenPdf = { uriStr, title ->
                                    navController.navigate(AppRoute.PdfViewer(uriStr, title))
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.Gmail> {
                            GmailScreen(onBack = { navController.popBackStack() })
                        }

                        composable<AppRoute.Notes> {
                            NotesScreen(
                                noteDao = database.noteDao(),
                                notes = notes,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.Todo> {
                            TodoScreen(
                                todoDao = database.todoDao(),
                                todos = todos,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.YouTube> {
                            YouTubeScreen(onBack = { navController.popBackStack() })
                        }

                        composable<AppRoute.Maps> {
                            MapsScreen(onBack = { navController.popBackStack() })
                        }

                        composable<AppRoute.GoogleSearch> {
                            GoogleSearchScreen(onBack = { navController.popBackStack() })
                        }

                        composable<AppRoute.AiAssistant> {
                            AiAssistantScreen(
                                aiRepository = aiRepository,
                                chatDao = database.chatDao(),
                                sessions = chatSessions,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.QrScanner> {
                            QrScannerScreen(onBack = { navController.popBackStack() })
                        }

                        composable<AppRoute.ClockTools> { entry ->
                            val args = entry.toRoute<AppRoute.ClockTools>()
                            ClockToolsScreen(
                                initialTab = args.initialTab,
                                hijriOffsetDays = settings.hijriOffsetDays,
                                onOpenCalendar = { navigateToTopTab(AppRoute.Calendar) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<AppRoute.UnitConverter> {
                            UnitConverterScreen(onBack = { navController.popBackStack() })
                        }
                    }
                }

                SplashScreenOverlay(
                    visible = showSplash,
                    onFinished = { showSplash = false }
                )
            }
        }
    }
}
