package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: NoteEntity): Long

    @Delete
    suspend fun delete(note: NoteEntity)
}

@Dao
interface TodoDao {
    @Query("SELECT * FROM todos ORDER BY isDone ASC, priority DESC, createdAt DESC")
    fun observeAll(): Flow<List<TodoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(todo: TodoEntity): Long

    @Delete
    suspend fun delete(todo: TodoEntity)

    @Query("DELETE FROM todos WHERE isDone = 1")
    suspend fun deleteCompleted()
}

@Dao
interface CalendarEventDao {
    @Query("SELECT * FROM calendar_events ORDER BY epochDay ASC, hour ASC, minute ASC")
    fun observeAll(): Flow<List<CalendarEventEntity>>

    @Query("SELECT * FROM calendar_events WHERE epochDay = :epochDay ORDER BY hour ASC, minute ASC")
    fun observeByDay(epochDay: Long): Flow<List<CalendarEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(event: CalendarEventEntity): Long

    @Delete
    suspend fun delete(event: CalendarEventEntity)
}

@Dao
interface PdfMetaDao {
    @Query("SELECT * FROM pdf_meta ORDER BY lastOpenedAt DESC")
    fun observeAll(): Flow<List<PdfMetaEntity>>

    @Query("SELECT * FROM pdf_meta WHERE uriString = :uriString LIMIT 1")
    suspend fun getByUri(uriString: String): PdfMetaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(meta: PdfMetaEntity)

    @Query("DELETE FROM pdf_meta WHERE uriString = :uriString")
    suspend fun deleteByUri(uriString: String)
}

@Dao
interface CalcHistoryDao {
    @Query("SELECT * FROM calc_history ORDER BY timestamp DESC LIMIT 50")
    fun observeAll(): Flow<List<CalcHistoryEntity>>

    @Insert
    suspend fun insert(item: CalcHistoryEntity)

    @Query("DELETE FROM calc_history")
    suspend fun clearAll()
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_sessions ORDER BY updatedAt DESC")
    fun observeSessions(): Flow<List<ChatSessionEntity>>

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC, id ASC")
    fun observeMessages(sessionId: Long): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ChatSessionEntity): Long

    @Update
    suspend fun updateSession(session: ChatSessionEntity)

    @Insert
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_sessions WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: Long)

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId")
    suspend fun deleteMessagesForSession(sessionId: Long)
}

@Dao
interface RecentMediaDao {
    @Query("SELECT * FROM recent_media ORDER BY lastPlayedAt DESC LIMIT 30")
    fun observeAll(): Flow<List<RecentMediaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: RecentMediaEntity)
}

@Dao
interface FavoriteContactDao {
    @Query("SELECT * FROM favorite_contacts")
    fun observeAll(): Flow<List<FavoriteContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(fav: FavoriteContactEntity)

    @Query("DELETE FROM favorite_contacts WHERE contactId = :contactId")
    suspend fun deleteById(contactId: String)
}
