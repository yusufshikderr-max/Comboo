package com.example.data.ai

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

interface AiRepository {
    val isLiveAiEnabled: Boolean
    fun sendPromptStream(
        prompt: String,
        mode: AiAssistantMode,
        languageCode: String
    ): Flow<String>
}

enum class AiAssistantMode(val labelEn: String, val labelBn: String) {
    CHAT("General Chat", "সাধারণ চ্যাট"),
    WRITE("Writing Help", "লেখা সহায়তা"),
    TRANSLATE("Translate (EN ↔ BN)", "অনুবাদ (EN ↔ BN)"),
    SUMMARIZE("Summarize", "সারসংক্ষেপ")
}

/**
 * Placeholder implementation used when Firebase AI Logic is not enabled.
 * Clearly labels every sample response and guides the user to Firebase AI Logic
 * or the official ChatGPT service without embedding any API keys.
 */
class LocalPlaceholderAiRepository : AiRepository {
    override val isLiveAiEnabled: Boolean = false

    override fun sendPromptStream(
        prompt: String,
        mode: AiAssistantMode,
        languageCode: String
    ): Flow<String> = flow {
        val trimmed = prompt.trim()
        val isBanglaInput = trimmed.any { it in '\u0980'..'\u09FF' } || languageCode == "bn"

        val response = buildString {
            appendLine("[Sample Offline Response — Live AI requires Firebase]")
            appendLine()
            when (mode) {
                AiAssistantMode.TRANSLATE -> {
                    if (isBanglaInput) {
                        appendLine("English Translation Preview:")
                        appendLine("• Input detected (বাংলা): \"$trimmed\"")
                        appendLine("• Sample output: This request will be translated accurately between Bengali and English once Firebase AI Logic is enabled, or you can tap \"Open Official ChatGPT\" above.")
                    } else {
                        appendLine("বাংলা অনুবাদ প্রিভিউ:")
                        appendLine("• প্রদত্ত লেখা: \"$trimmed\"")
                        appendLine("• নমুনা অনুবাদ: লাইভ এআই সক্রিয় করতে Firebase সংযুক্ত করুন অথবা উপরের \"Open Official ChatGPT\" বাটনে ট্যাপ করুন।")
                    }
                }
                AiAssistantMode.SUMMARIZE -> {
                    if (isBanglaInput) {
                        appendLine("সারসংক্ষেপ (নমুনা):")
                        appendLine("১. মূল বিষয়: ${trimmed.take(80)}${if (trimmed.length > 80) "..." else ""}")
                        appendLine("২. লাইভ Gemini সারসংক্ষেপের জন্য অ্যাপে Firebase AI Logic সক্রিয় করা প্রয়োজন।")
                    } else {
                        appendLine("Key Summary (Sample):")
                        appendLine("• Topic: ${trimmed.take(80)}${if (trimmed.length > 80) "..." else ""}")
                        appendLine("• Note: Enable Firebase AI Logic in AI Studio to generate live AI summaries from any text or document.")
                    }
                }
                AiAssistantMode.WRITE -> {
                    if (isBanglaInput) {
                        appendLine("খসড়া লেখা (নমুনা):")
                        appendLine("প্রিয় প্রাপক,\n\n\"$trimmed\" বিষয়ের উপর ভিত্তি করে আপনার বার্তাটি পেশাদারভাবে সাজানো হয়েছে। লাইভ এআই রাইটিংয়ের জন্য Firebase AI Logic যুক্ত করুন বা অফিসিয়াল ChatGPT ব্যবহার করুন।\n\nশুভেচ্ছান্তে,\nস্মার্ট অল-ইন-ওয়ান")
                    } else {
                        appendLine("Draft Preview (Sample):")
                        appendLine("Subject: Regarding ${trimmed.take(48)}\n\nHello,\n\nHere is a structured draft template based on your prompt. Connect Firebase AI Logic for dynamic real-time composition, or tap \"Open Official ChatGPT\" for full web access.\n\nBest regards,")
                    }
                }
                AiAssistantMode.CHAT -> {
                    if (isBanglaInput) {
                        appendLine("আপনার প্রশ্ন: \"$trimmed\"")
                        appendLine()
                        appendLine("নমুনা উত্তর: এটি একটি অফলাইন নমুনা উত্তর। লাইভ Gemini এআই চ্যাট চালু করতে Firebase AI Logic সক্ষম করুন, অথবা উপরের \"Open Official ChatGPT\" বাটন ব্যবহার করে সরাসরি অফিসিয়াল ChatGPT-তে কথা বলুন।")
                    } else {
                        appendLine("You asked: \"$trimmed\"")
                        appendLine()
                        appendLine("Sample response: Live generative answers in Android apps built here are powered by Firebase AI Logic (which is currently disabled). Enable Firebase to unlock live Gemini streaming responses, or tap \"Open Official ChatGPT\" at the top to launch the official ChatGPT experience.")
                    }
                }
            }
        }

        val words = response.split(" ")
        val sb = StringBuilder()
        for ((index, word) in words.withIndex()) {
            if (index > 0) sb.append(' ')
            sb.append(word)
            emit(sb.toString())
            delay(18L)
        }
    }
}
