package com.example.data.files

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class FileCategory {
    ALL, RECENT, DOWNLOADS, DOCUMENTS, IMAGES, VIDEOS, AUDIO, PDF
}

data class ManagedFileItem(
    val id: String,
    val name: String,
    val uri: Uri,
    val localFile: File? = null,
    val isDirectory: Boolean = false,
    val sizeBytes: Long = 0L,
    val lastModified: Long = 0L,
    val mimeType: String = "*/*",
    val locationLabel: String = "App Storage",
    val isSafDocument: Boolean = false
)

data class StorageStats(
    val totalBytes: Long,
    val freeBytes: Long,
    val usedBytes: Long,
    val appStorageBytes: Long
)

class FileRepository(private val context: Context) {

    val rootWorkspaceDir: File
        get() = File(context.filesDir, "SmartWorkspace").apply {
            if (!exists()) mkdirs()
            listOf("Documents", "Downloads", "PDFs", "ScannedDocs", "Images", "Audio", "Videos").forEach { sub ->
                File(this, sub).apply { if (!exists()) mkdirs() }
            }
        }

    suspend fun ensureStarterAssets() = withContext(Dispatchers.IO) {
        val pdfDir = File(rootWorkspaceDir, "PDFs")
        val starterPdf = File(pdfDir, "Smart_All_in_One_Guide.pdf")
        if (!starterPdf.exists()) {
            createSampleGuidePdf(starterPdf)
        }
        val notesFile = File(File(rootWorkspaceDir, "Documents"), "Welcome_Notes.txt")
        if (!notesFile.exists()) {
            notesFile.writeText(
                "Smart All-in-One Workspace\n" +
                    "===========================\n\n" +
                    "Use 'Add Storage Folder' in File Manager or PDF Reader to mount Downloads, Documents, or SD Card via Android Storage Access Framework (SAF).\n" +
                    "All your scanned documents, notes exports, and saved PDFs appear here automatically."
            )
        }
    }

    private fun createSampleGuidePdf(target: File) {
        val doc = PdfDocument()
        val titlePaint = Paint().apply {
            color = Color.rgb(13, 37, 76)
            textSize = 24f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(37, 99, 235)
            textSize = 15f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 13f
            isAntiAlias = true
        }

        val pages = listOf(
            "Smart All-in-One — Quick Start Guide" to listOf(
                "Welcome to Smart All-in-One, your unified Android super app.",
                "Page 1 of 2 — Core Capabilities",
                "",
                "1. Home Dashboard & Trilingual Calendar:",
                "   View Bengali, English (Gregorian), and Arabic (Hijri) dates",
                "   simultaneously with real-time digital clock & customizable shortcuts.",
                "",
                "2. File Manager & Advanced PDF Reader:",
                "   Browse workspace folders or connect any device folder via",
                "   Android Storage Access Framework (SAF). Search, bookmark,",
                "   zoom, fit-to-width, and remember your last reading page.",
                "",
                "3. Document Scanner & OCR:",
                "   Capture pages with CameraX, apply B&W or Color enhancement,",
                "   extract text with on-device ML Kit OCR, and export multi-page PDFs."
            ),
            "Tips for Device Storage & Productivity" to listOf(
                "Page 2 of 2 — Connecting Device Folders",
                "",
                "• Tap 'Add Storage Folder' inside File Manager or PDF Reader to",
                "  grant persistent access to your Downloads or Documents folder.",
                "• Tap any PDF received from WhatsApp, Gmail, or Files to open",
                "  it directly inside the built-in Smart All-in-One PDF Reader.",
                "• Use Gallery's Photo Picker to import device photos & videos",
                "  securely with zero broad storage permissions.",
                "• Customize Light/Dark theme, Bengali/English UI, and Hijri",
                "  day adjustment (-2 to +2 days) in Settings."
            )
        )

        pages.forEachIndexed { idx, (heading, lines) ->
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, idx + 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            canvas.drawText(heading, 48f, 72f, titlePaint)
            canvas.drawText("Smart All-in-One Super App", 48f, 98f, subtitlePaint)
            var y = 140f
            for (line in lines) {
                canvas.drawText(line, 48f, y, bodyPaint)
                y += 24f
            }
            doc.finishPage(page)
        }

        FileOutputStream(target).use { out ->
            doc.writeTo(out)
        }
        doc.close()
    }

    suspend fun getStorageStats(): StorageStats = withContext(Dispatchers.IO) {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        val used = (total - free).coerceAtLeast(0L)
        val appSize = calculateDirSize(rootWorkspaceDir)
        StorageStats(total, free, used, appSize)
    }

    private fun calculateDirSize(dir: File): Long {
        if (!dir.exists()) return 0L
        var size = 0L
        dir.walkTopDown().forEach { if (it.isFile) size += it.length() }
        return size
    }

    fun getShareUri(item: ManagedFileItem): Uri {
        return if (item.localFile != null) {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                item.localFile
            )
        } else {
            item.uri
        }
    }

    suspend fun listLocalDirectory(dir: File): List<ManagedFileItem> = withContext(Dispatchers.IO) {
        ensureStarterAssets()
        val target = if (dir.exists() && dir.isDirectory) dir else rootWorkspaceDir
        target.listFiles()?.map { file ->
            val mime = if (file.isDirectory) "inode/directory" else guessMimeType(file.name)
            ManagedFileItem(
                id = file.absolutePath,
                name = file.name,
                uri = Uri.fromFile(file),
                localFile = file,
                isDirectory = file.isDirectory,
                sizeBytes = if (file.isDirectory) 0L else file.length(),
                lastModified = file.lastModified(),
                mimeType = mime,
                locationLabel = target.name
            )
        }?.sortedWith(compareByDescending<ManagedFileItem> { it.isDirectory }.thenBy { it.name.lowercase() })
            ?: emptyList()
    }

    suspend fun listSafDirectory(treeUri: Uri): List<ManagedFileItem> = withContext(Dispatchers.IO) {
        val docTree = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        val folderName = docTree.name ?: "Mounted Folder"
        docTree.listFiles().mapNotNull { doc ->
            val name = doc.name ?: return@mapNotNull null
            ManagedFileItem(
                id = doc.uri.toString(),
                name = name,
                uri = doc.uri,
                localFile = null,
                isDirectory = doc.isDirectory,
                sizeBytes = if (doc.isDirectory) 0L else doc.length(),
                lastModified = doc.lastModified(),
                mimeType = doc.type ?: guessMimeType(name),
                locationLabel = folderName,
                isSafDocument = true
            )
        }.sortedWith(compareByDescending<ManagedFileItem> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    suspend fun collectCategoryFiles(
        category: FileCategory,
        persistedTreeUris: Set<String>
    ): List<ManagedFileItem> = withContext(Dispatchers.IO) {
        ensureStarterAssets()
        val allFiles = mutableListOf<ManagedFileItem>()

        // 1. Walk app workspace & external files dir
        val searchRoots = listOfNotNull(rootWorkspaceDir, context.getExternalFilesDir(null))
        for (root in searchRoots) {
            root.walkTopDown().maxDepth(4).forEach { file ->
                if (file.isFile) {
                    allFiles += ManagedFileItem(
                        id = file.absolutePath,
                        name = file.name,
                        uri = Uri.fromFile(file),
                        localFile = file,
                        isDirectory = false,
                        sizeBytes = file.length(),
                        lastModified = file.lastModified(),
                        mimeType = guessMimeType(file.name),
                        locationLabel = file.parentFile?.name ?: "Workspace"
                    )
                }
            }
        }

        // 2. Scan persisted SAF folders (breadth-limited for fast performance)
        for (treeStr in persistedTreeUris) {
            runCatching {
                val treeUri = Uri.parse(treeStr)
                val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
                if (rootDoc != null && rootDoc.canRead()) {
                    scanDocTree(rootDoc, rootDoc.name ?: "Device Folder", allFiles, depth = 0)
                }
            }
        }

        val distinct = allFiles.distinctBy { it.uri.toString() }
        when (category) {
            FileCategory.ALL -> distinct
            FileCategory.RECENT -> distinct.sortedByDescending { it.lastModified }.take(40)
            FileCategory.DOWNLOADS -> distinct.filter {
                it.locationLabel.contains("download", ignoreCase = true)
            }
            FileCategory.DOCUMENTS -> distinct.filter {
                val lower = it.name.lowercase()
                lower.endsWith(".pdf") || lower.endsWith(".txt") || lower.endsWith(".doc") ||
                    lower.endsWith(".docx") || lower.endsWith(".csv") || lower.endsWith(".md")
            }
            FileCategory.IMAGES -> distinct.filter { it.mimeType.startsWith("image/") }
            FileCategory.VIDEOS -> distinct.filter { it.mimeType.startsWith("video/") }
            FileCategory.AUDIO -> distinct.filter { it.mimeType.startsWith("audio/") }
            FileCategory.PDF -> distinct.filter {
                it.mimeType == "application/pdf" || it.name.lowercase().endsWith(".pdf")
            }
        }
    }

    private fun scanDocTree(
        folder: DocumentFile,
        parentLabel: String,
        out: MutableList<ManagedFileItem>,
        depth: Int
    ) {
        if (depth > 2 || out.size > 400) return
        for (doc in folder.listFiles()) {
            if (doc.isDirectory) {
                scanDocTree(doc, doc.name ?: parentLabel, out, depth + 1)
            } else if (doc.isFile) {
                val name = doc.name ?: continue
                out += ManagedFileItem(
                    id = doc.uri.toString(),
                    name = name,
                    uri = doc.uri,
                    localFile = null,
                    isDirectory = false,
                    sizeBytes = doc.length(),
                    lastModified = doc.lastModified(),
                    mimeType = doc.type ?: guessMimeType(name),
                    locationLabel = parentLabel,
                    isSafDocument = true
                )
            }
        }
    }

    suspend fun createFolder(parentDir: File, name: String): Boolean = withContext(Dispatchers.IO) {
        val clean = name.trim()
        if (clean.isEmpty()) return@withContext false
        val target = File(parentDir, clean)
        if (!target.exists()) target.mkdirs() else false
    }

    suspend fun renameItem(item: ManagedFileItem, newName: String): Boolean = withContext(Dispatchers.IO) {
        val clean = newName.trim()
        if (clean.isEmpty()) return@withContext false
        if (item.localFile != null) {
            val dest = File(item.localFile.parentFile, clean)
            item.localFile.renameTo(dest)
        } else if (item.isSafDocument) {
            runCatching {
                DocumentFile.fromSingleUri(context, item.uri)?.renameTo(clean) ?: false
            }.getOrDefault(false)
        } else false
    }

    suspend fun copyLocalFile(item: ManagedFileItem, targetDir: File): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val dest = uniqueFile(targetDir, item.name)
            if (item.localFile != null) {
                item.localFile.copyTo(dest, overwrite = false)
            } else {
                context.contentResolver.openInputStream(item.uri)?.use { input ->
                    FileOutputStream(dest).use { output -> input.copyTo(output) }
                } ?: return@withContext false
            }
            true
        }.getOrDefault(false)
    }

    suspend fun moveLocalFile(item: ManagedFileItem, targetDir: File): Boolean = withContext(Dispatchers.IO) {
        val copied = copyLocalFile(item, targetDir)
        if (copied) deleteItem(item) else false
    }

    suspend fun deleteItem(item: ManagedFileItem): Boolean = withContext(Dispatchers.IO) {
        if (item.localFile != null) {
            item.localFile.deleteRecursively()
        } else if (item.isSafDocument) {
            runCatching {
                DocumentFile.fromSingleUri(context, item.uri)?.delete() ?: false
            }.getOrDefault(false)
        } else false
    }

    suspend fun importUriToWorkspace(uri: Uri, targetSubfolder: String): ManagedFileItem? = withContext(Dispatchers.IO) {
        runCatching {
            val name = queryDisplayName(context.contentResolver, uri) ?: "file_${System.currentTimeMillis()}"
            val dir = File(rootWorkspaceDir, targetSubfolder).apply { if (!exists()) mkdirs() }
            val dest = uniqueFile(dir, name)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(dest).use { output -> input.copyTo(output) }
            } ?: return@withContext null
            ManagedFileItem(
                id = dest.absolutePath,
                name = dest.name,
                uri = Uri.fromFile(dest),
                localFile = dest,
                sizeBytes = dest.length(),
                lastModified = dest.lastModified(),
                mimeType = guessMimeType(dest.name),
                locationLabel = targetSubfolder
            )
        }.getOrNull()
    }

    fun takePersistablePermission(uri: Uri) {
        runCatching {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }.onFailure {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }

    private fun uniqueFile(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var count = 1
        while (candidate.exists()) {
            candidate = File(dir, "${base}_$count$ext")
            count++
        }
        return candidate
    }

    companion object {
        fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
            if (uri.scheme == "file") return File(uri.path ?: return null).name
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return c.getString(idx)
                }
            }
            return uri.lastPathSegment
        }

        fun guessMimeType(fileName: String): String {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            if (ext == "pdf") return "application/pdf"
            if (ext == "mkv") return "video/x-matroska"
            if (ext == "mp4") return "video/mp4"
            if (ext == "mp3") return "audio/mpeg"
            if (ext == "wav") return "audio/wav"
            if (ext == "aac") return "audio/aac"
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }

        fun formatSize(bytes: Long): String {
            if (bytes < 1024L) return "$bytes B"
            val kb = bytes / 1024.0
            if (kb < 1024.0) return "%.1f KB".format(kb)
            val mb = kb / 1024.0
            if (mb < 1024.0) return "%.1f MB".format(mb)
            return "%.2f GB".format(mb / 1024.0)
        }
    }
}
