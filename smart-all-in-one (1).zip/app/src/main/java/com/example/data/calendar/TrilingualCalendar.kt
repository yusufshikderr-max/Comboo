package com.example.data.calendar

import android.icu.util.IslamicCalendar
import android.icu.util.ULocale
import java.util.Calendar
import java.util.TimeZone

data class SimpleGregorianDate(
    val year: Int,
    val month: Int, // 1..12
    val day: Int,   // 1..31
    val dayOfWeek: Int // Calendar.SUNDAY (1) .. Calendar.SATURDAY (7)
) {
    val epochDay: Long
        get() {
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                clear()
                set(year, month - 1, day, 0, 0, 0)
            }
            return cal.timeInMillis / 86_400_000L
        }

    companion object {
        fun today(): SimpleGregorianDate {
            val cal = Calendar.getInstance()
            return SimpleGregorianDate(
                year = cal.get(Calendar.YEAR),
                month = cal.get(Calendar.MONTH) + 1,
                day = cal.get(Calendar.DAY_OF_MONTH),
                dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            )
        }

        fun fromEpochDay(epochDay: Long): SimpleGregorianDate {
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                timeInMillis = epochDay * 86_400_000L
            }
            return SimpleGregorianDate(
                year = cal.get(Calendar.YEAR),
                month = cal.get(Calendar.MONTH) + 1,
                day = cal.get(Calendar.DAY_OF_MONTH),
                dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            )
        }

        fun of(year: Int, month: Int, day: Int): SimpleGregorianDate {
            val cal = Calendar.getInstance().apply {
                clear()
                set(year, month - 1, day)
            }
            return SimpleGregorianDate(
                year = cal.get(Calendar.YEAR),
                month = cal.get(Calendar.MONTH) + 1,
                day = cal.get(Calendar.DAY_OF_MONTH),
                dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            )
        }
    }
}

data class BengaliDate(
    val day: Int,
    val monthIndex: Int, // 0..11 (Boishakh..Chaitra)
    val monthNameBn: String,
    val monthNameEn: String,
    val year: Int,
    val weekdayBn: String,
    val weekdayEn: String
)

data class HijriDate(
    val day: Int,
    val monthIndex: Int, // 0..11
    val monthNameAr: String,
    val monthNameEn: String,
    val year: Int,
    val weekdayAr: String,
    val weekdayEn: String
)

data class TrilingualDateInfo(
    val gregorian: SimpleGregorianDate,
    val gregorianMonthEn: String,
    val gregorianMonthBn: String,
    val gregorianWeekdayEn: String,
    val bengali: BengaliDate,
    val hijri: HijriDate
)

object TrilingualCalendar {

    private val gregorianMonthsEn = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    private val gregorianMonthsBn = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val weekdaysEn = listOf(
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    )

    private val weekdaysBn = listOf(
        "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
    )

    private val weekdaysAr = listOf(
        "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    )

    private val bengaliMonthsBn = listOf(
        "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
        "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
    )

    private val bengaliMonthsEn = listOf(
        "Boishakh", "Joishtho", "Asharh", "Shrabon", "Bhadro", "Ashwin",
        "Kartik", "Ograhayon", "Poush", "Magh", "Falgun", "Choitro"
    )

    private val hijriMonthsAr = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الثاني",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private val hijriMonthsEn = listOf(
        "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
        "Jumada al-Ula", "Jumada al-Akhirah", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    )

    fun isGregorianLeapYear(year: Int): Boolean {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)
    }

    fun daysInGregorianMonth(year: Int, month: Int): Int {
        return when (month) {
            1, 3, 5, 7, 8, 10, 12 -> 31
            4, 6, 9, 11 -> 30
            2 -> if (isGregorianLeapYear(year)) 29 else 28
            else -> 30
        }
    }

    fun toBengaliDigits(number: Int): String {
        val digits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        return number.toString().map { ch ->
            if (ch in '0'..'9') digits[ch - '0'] else ch
        }.joinToString("")
    }

    fun toArabicDigits(number: Int): String {
        val digits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        return number.toString().map { ch ->
            if (ch in '0'..'9') digits[ch - '0'] else ch
        }.joinToString("")
    }

    /**
     * Revised Bangla Academy calendar conversion:
     * Pohela Boishakh = April 14.
     * Months 0..5 (Boishakh..Ashwin) = 31 days each.
     * Months 6..9 (Kartik..Magh) = 30 days each.
     * Month 10 (Falgun) = 30 days in Gregorian leap year (February of the year containing Falgun), else 29.
     * Month 11 (Choitro) = 30 days.
     */
    fun toBengaliDate(date: SimpleGregorianDate): BengaliDate {
        val weekdayIdx = (date.dayOfWeek - 1).coerceIn(0, 6)
        val pohelaThisYear = SimpleGregorianDate.of(date.year, 4, 14)
        val startYear: Int
        val bengaliYear: Int
        val daysElapsed: Int

        if (date.epochDay >= pohelaThisYear.epochDay) {
            startYear = date.year
            bengaliYear = date.year - 593
            daysElapsed = (date.epochDay - pohelaThisYear.epochDay).toInt()
        } else {
            startYear = date.year - 1
            bengaliYear = date.year - 594
            val pohelaPrevYear = SimpleGregorianDate.of(startYear, 4, 14)
            daysElapsed = (date.epochDay - pohelaPrevYear.epochDay).toInt()
        }

        // Falgun falls in Feb-March of (startYear + 1)
        val falgunDays = if (isGregorianLeapYear(startYear + 1)) 30 else 29
        val monthLengths = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, falgunDays, 30)

        var remaining = daysElapsed
        var monthIndex = 0
        while (monthIndex < 11 && remaining >= monthLengths[monthIndex]) {
            remaining -= monthLengths[monthIndex]
            monthIndex++
        }
        val day = remaining + 1

        return BengaliDate(
            day = day,
            monthIndex = monthIndex,
            monthNameBn = bengaliMonthsBn[monthIndex],
            monthNameEn = bengaliMonthsEn[monthIndex],
            year = bengaliYear,
            weekdayBn = weekdaysBn[weekdayIdx],
            weekdayEn = weekdaysEn[weekdayIdx]
        )
    }

    fun toHijriDate(date: SimpleGregorianDate, offsetDays: Int = 0): HijriDate {
        val weekdayIdx = (date.dayOfWeek - 1).coerceIn(0, 6)
        val gCal = Calendar.getInstance().apply {
            clear()
            set(date.year, date.month - 1, date.day, 12, 0, 0)
            add(Calendar.DAY_OF_MONTH, offsetDays)
        }
        val (hYear, hMonth, hDay) = runCatching {
            val islamic = IslamicCalendar(ULocale("@calendar=islamic-umalqura")).apply {
                timeInMillis = gCal.timeInMillis
            }
            Triple(
                islamic.get(IslamicCalendar.YEAR),
                islamic.get(IslamicCalendar.MONTH).coerceIn(0, 11),
                islamic.get(IslamicCalendar.DAY_OF_MONTH)
            )
        }.getOrElse {
            gregorianToTabularHijri(
                gCal.get(Calendar.YEAR),
                gCal.get(Calendar.MONTH) + 1,
                gCal.get(Calendar.DAY_OF_MONTH)
            )
        }

        return HijriDate(
            day = hDay,
            monthIndex = hMonth,
            monthNameAr = hijriMonthsAr[hMonth],
            monthNameEn = hijriMonthsEn[hMonth],
            year = hYear,
            weekdayAr = weekdaysAr[weekdayIdx],
            weekdayEn = weekdaysEn[weekdayIdx]
        )
    }

    private fun gregorianToTabularHijri(year: Int, month: Int, day: Int): Triple<Int, Int, Int> {
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        val jdn = day + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045
        val l = jdn - 1948440 + 10632
        val n = (l - 1) / 10631
        val l2 = l - 10631 * n + 354
        val j = ((10985 - l2) / 5316) * ((50 * l2) / 17719) + (l2 / 5670) * ((43 * l2) / 15238)
        val l3 = l2 - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29
        val hMonth = ((24 * l3) / 709) - 1
        val hDay = l3 - ((709 * (hMonth + 1)) / 24)
        val hYear = 30 * n + j - 30
        return Triple(hYear, hMonth.coerceIn(0, 11), hDay)
    }

    fun getTrilingualDate(date: SimpleGregorianDate, hijriOffsetDays: Int = 0): TrilingualDateInfo {
        val weekdayIdx = (date.dayOfWeek - 1).coerceIn(0, 6)
        val monthIdx = (date.month - 1).coerceIn(0, 11)
        return TrilingualDateInfo(
            gregorian = date,
            gregorianMonthEn = gregorianMonthsEn[monthIdx],
            gregorianMonthBn = gregorianMonthsBn[monthIdx],
            gregorianWeekdayEn = weekdaysEn[weekdayIdx],
            bengali = toBengaliDate(date),
            hijri = toHijriDate(date, hijriOffsetDays)
        )
    }

    fun gregorianMonthName(month: Int, isBengali: Boolean): String {
        val idx = (month - 1).coerceIn(0, 11)
        return if (isBengali) gregorianMonthsBn[idx] else gregorianMonthsEn[idx]
    }

    fun weekdayShortLabels(isBengali: Boolean): List<String> {
        return if (isBengali) {
            listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র", "শনি")
        } else {
            listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        }
    }
}
