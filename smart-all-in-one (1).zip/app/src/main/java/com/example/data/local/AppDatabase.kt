package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        NoteEntity::class,
        TodoEntity::class,
        CalendarEventEntity::class,
        PdfMetaEntity::class,
        CalcHistoryEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        RecentMediaEntity::class,
        FavoriteContactEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun todoDao(): TodoDao
    abstract fun calendarEventDao(): CalendarEventDao
    abstract fun pdfMetaDao(): PdfMetaDao
    abstract fun calcHistoryDao(): CalcHistoryDao
    abstract fun chatDao(): ChatDao
    abstract fun recentMediaDao(): RecentMediaDao
    abstract fun favoriteContactDao(): FavoriteContactDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_all_in_one.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
