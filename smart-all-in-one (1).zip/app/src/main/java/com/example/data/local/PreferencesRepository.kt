package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "smart_combo_prefs")

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: AppLanguage = AppLanguage.EN,
    val hijriOffsetDays: Int = 0,
    val notificationsEnabled: Boolean = true,
    val pinnedShortcuts: List<String> = DEFAULT_PINNED_SHORTCUTS,
    val persistedTreeUris: Set<String> = emptySet(),
    val pickedMediaUris: Set<String> = emptySet(),
    val recentGalleryUris: List<String> = emptyList()
)

val DEFAULT_PINNED_SHORTCUTS = listOf(
    "file_manager",
    "pdf_reader",
    "scanner",
    "gallery",
    "contacts",
    "calculator",
    "notes",
    "qr_scanner"
)

class PreferencesRepository(private val context: Context) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val HIJRI_OFFSET = intPreferencesKey("hijri_offset")
        val NOTIFICATIONS = booleanPreferencesKey("notifications_enabled")
        val PINNED_SHORTCUTS = stringPreferencesKey("pinned_shortcuts")
        val TREE_URIS = stringSetPreferencesKey("persisted_tree_uris")
        val PICKED_MEDIA_URIS = stringSetPreferencesKey("picked_media_uris")
        val RECENT_GALLERY_URIS = stringPreferencesKey("recent_gallery_uris")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val theme = prefs[Keys.THEME_MODE]?.let {
            runCatching { ThemeMode.valueOf(it) }.getOrNull()
        } ?: ThemeMode.SYSTEM

        val lang = prefs[Keys.LANGUAGE]?.let {
            runCatching { AppLanguage.valueOf(it) }.getOrNull()
        } ?: AppLanguage.EN

        val shortcutsRaw = prefs[Keys.PINNED_SHORTCUTS]
        val shortcuts = if (shortcutsRaw.isNullOrBlank()) {
            DEFAULT_PINNED_SHORTCUTS
        } else {
            shortcutsRaw.split(",").filter { it.isNotBlank() }
        }

        val recentGallery = prefs[Keys.RECENT_GALLERY_URIS]
            ?.split("|")
            ?.filter { it.isNotBlank() }
            ?: emptyList()

        AppSettings(
            themeMode = theme,
            language = lang,
            hijriOffsetDays = (prefs[Keys.HIJRI_OFFSET] ?: 0).coerceIn(-2, 2),
            notificationsEnabled = prefs[Keys.NOTIFICATIONS] ?: true,
            pinnedShortcuts = shortcuts,
            persistedTreeUris = prefs[Keys.TREE_URIS] ?: emptySet(),
            pickedMediaUris = prefs[Keys.PICKED_MEDIA_URIS] ?: emptySet(),
            recentGalleryUris = recentGallery
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    suspend fun setHijriOffset(days: Int) {
        context.dataStore.edit { it[Keys.HIJRI_OFFSET] = days.coerceIn(-2, 2) }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.NOTIFICATIONS] = enabled }
    }

    suspend fun toggleShortcut(toolId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.PINNED_SHORTCUTS]
                ?.split(",")
                ?.filter { it.isNotBlank() }
                ?.toMutableList()
                ?: DEFAULT_PINNED_SHORTCUTS.toMutableList()
            if (current.contains(toolId)) {
                if (current.size > 2) current.remove(toolId)
            } else {
                current.add(toolId)
            }
            prefs[Keys.PINNED_SHORTCUTS] = current.joinToString(",")
        }
    }

    suspend fun addPersistedTreeUri(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.TREE_URIS]?.toMutableSet() ?: mutableSetOf()
            current.add(uri)
            prefs[Keys.TREE_URIS] = current
        }
    }

    suspend fun addPickedMediaUris(uris: Collection<String>) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.PICKED_MEDIA_URIS]?.toMutableSet() ?: mutableSetOf()
            current.addAll(uris)
            prefs[Keys.PICKED_MEDIA_URIS] = current
        }
    }

    suspend fun removePickedMediaUri(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.PICKED_MEDIA_URIS]?.toMutableSet() ?: mutableSetOf()
            current.remove(uri)
            prefs[Keys.PICKED_MEDIA_URIS] = current
        }
    }

    suspend fun recordGalleryView(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.RECENT_GALLERY_URIS]
                ?.split("|")
                ?.filter { it.isNotBlank() && it != uri }
                ?.toMutableList()
                ?: mutableListOf()
            current.add(0, uri)
            prefs[Keys.RECENT_GALLERY_URIS] = current.take(15).joinToString("|")
        }
    }
}
