package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val colorIndex: Int = 0,
    val isPinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "todos")
data class TodoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "Personal",
    val priority: Int = 1, // 0 Low, 1 Normal, 2 High
    val isDone: Boolean = false,
    val dueMillis: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val epochDay: Long, // Days since 1970-01-01 UTC in local calendar date
    val hour: Int = 9,
    val minute: Int = 0,
    val isImportant: Boolean = false,
    val hasReminder: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pdf_meta")
data class PdfMetaEntity(
    @PrimaryKey val uriString: String,
    val displayName: String,
    val lastPage: Int = 0,
    val totalPages: Int = 1,
    val isFavorite: Boolean = false,
    val lastOpenedAt: Long = 0L
)

@Entity(tableName = "calc_history")
data class CalcHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_media")
data class RecentMediaEntity(
    @PrimaryKey val uriString: String,
    val title: String,
    val mimeType: String,
    val isVideo: Boolean,
    val lastPlayedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_contacts")
data class FavoriteContactEntity(
    @PrimaryKey val contactId: String,
    val displayName: String
)
