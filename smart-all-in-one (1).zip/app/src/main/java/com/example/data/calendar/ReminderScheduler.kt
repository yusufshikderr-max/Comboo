package com.example.data.calendar

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import java.util.Calendar

const val CHANNEL_REMINDERS = "smart_combo_reminders"
const val EXTRA_REMINDER_TITLE = "extra_reminder_title"
const val EXTRA_REMINDER_BODY = "extra_reminder_body"
const val EXTRA_REMINDER_ID = "extra_reminder_id"

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(EXTRA_REMINDER_TITLE) ?: "Smart All-in-One Reminder"
        val body = intent.getStringExtra(EXTRA_REMINDER_BODY) ?: "Scheduled event reminder"
        val notifId = intent.getIntExtra(EXTRA_REMINDER_ID, (System.currentTimeMillis() % 100000).toInt())

        ReminderScheduler.ensureChannel(context)

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPending = PendingIntent.getActivity(
            context,
            notifId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentPending)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notifId, notification)
    }
}

object ReminderScheduler {
    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_REMINDERS,
                "Calendar & Timer Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for calendar events, alarms, and timers"
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    fun scheduleEventReminder(
        context: Context,
        eventId: Long,
        title: String,
        body: String,
        epochDay: Long,
        hour: Int,
        minute: Int
    ) {
        ensureChannel(context)
        val date = SimpleGregorianDate.fromEpochDay(epochDay)
        val cal = Calendar.getInstance().apply {
            set(date.year, date.month - 1, date.day, hour, minute, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val triggerAt = cal.timeInMillis
        if (triggerAt <= System.currentTimeMillis()) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_REMINDER_TITLE, title)
            putExtra(EXTRA_REMINDER_BODY, body.ifBlank { "Scheduled for ${"%02d:%02d".format(hour, minute)}" })
            putExtra(EXTRA_REMINDER_ID, eventId.toInt())
        }
        val pending = PendingIntent.getBroadcast(
            context,
            eventId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
    }

    fun showImmediateNotification(context: Context, title: String, body: String, id: Int = 9001) {
        ensureChannel(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(id, notification)
    }
}
