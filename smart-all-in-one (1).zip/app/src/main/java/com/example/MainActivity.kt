package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.data.ai.LocalPlaceholderAiRepository
import com.example.data.contacts.ContactsRepository
import com.example.data.files.FileRepository
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesRepository
import com.example.ui.navigation.SmartAllInOneApp

class MainActivity : ComponentActivity() {
    private var incomingPdfUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handlePdfIntent(intent)

        val database = AppDatabase.getInstance(applicationContext)
        val preferencesRepository = PreferencesRepository(applicationContext)
        val fileRepository = FileRepository(applicationContext)
        val contactsRepository = ContactsRepository(applicationContext)
        val aiRepository = LocalPlaceholderAiRepository()

        setContent {
            SmartAllInOneApp(
                database = database,
                preferencesRepository = preferencesRepository,
                fileRepository = fileRepository,
                contactsRepository = contactsRepository,
                aiRepository = aiRepository,
                incomingPdfUri = incomingPdfUri,
                onIncomingPdfHandled = { incomingPdfUri = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handlePdfIntent(intent)
    }

    private fun handlePdfIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            incomingPdfUri = intent.data
        }
    }
}
