package com.example

import com.example.data.calendar.SimpleGregorianDate
import com.example.data.calendar.TrilingualCalendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrilingualCalendarTest {
    @Test
    fun pohelaBoishakhMapsToApril14() {
        val date = SimpleGregorianDate.of(2026, 4, 14)
        val bn = TrilingualCalendar.toBengaliDate(date)
        assertEquals(1, bn.day)
        assertEquals(0, bn.monthIndex) // Boishakh
        assertEquals(1433, bn.year)
        assertEquals("বৈশাখ", bn.monthNameBn)
    }

    @Test
    fun november18MapsCorrectlyToBengaliDate() {
        val date = SimpleGregorianDate.of(2026, 11, 18)
        val bn = TrilingualCalendar.toBengaliDate(date)
        assertEquals("অগ্রহায়ণ", bn.monthNameBn)
        assertEquals(1433, bn.year)
        assertEquals(3, bn.day)
    }

    @Test
    fun falgunHas30DaysInLeapYear() {
        // 2024 is a leap year, so Falgun 1430 (starts Feb 14, 2024) has 30 days
        val date = SimpleGregorianDate.of(2024, 3, 14)
        val bn = TrilingualCalendar.toBengaliDate(date)
        assertEquals(10, bn.monthIndex) // Falgun
        assertEquals(30, bn.day)
    }

    @Test
    fun hijriOffsetShiftsDay() {
        val date = SimpleGregorianDate.of(2026, 11, 18)
        val base = TrilingualCalendar.toHijriDate(date, 0)
        val shifted = TrilingualCalendar.toHijriDate(date, 1)
        assertTrue(base.day != shifted.day || base.monthIndex != shifted.monthIndex)
    }
}
